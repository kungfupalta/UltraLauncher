# Changelog

## 1.2 (versionCode 3)
- Nuevo modelo de cuadrícula: cada icono tiene página/fila/columna y puede haber huecos vacíos.
  Mover = soltar en una celda libre (también entre páginas y dock). Soltar sobre otra app la intercambia;
  mantener ~0,5 s encima y soltar crea una carpeta.
- Migración automática desde la lista plana de 1.1 (se ve igual que antes; datos viejos conservados).
- Widgets de Android: menú de espacio vacío > Widgets. Mantener pulsado un widget: Tamaño / Quitar / arrastrar.
- Carpetas (inicio y dock) con nombre editable y animación de apertura.
- Bloquear layout.
- El dock ahora tiene 4 huecos fijos (se puede dejar un hueco vacío).
