# Changelog

## 1.4 (versionCode 5)
- Ajustes en pantalla completa (Inicio, Dock, Cajón, Iconos, Gestos, Tema, Copia de seguridad, Acerca de). Reemplaza al diálogo Personalizar.
- Gestos configurables (doble toque, deslizar arriba/abajo, pellizco, dos dedos arriba/abajo) con acciones elegibles.
- Servicio de accesibilidad OPCIONAL solo para el gesto "Bloquear pantalla".
- Tema: modo claro/oscuro/auto, Material You, atenuado y desenfoque del fondo, fuente y tamaño de texto, animación de apertura desde el icono.
- Copia de seguridad: exportar/importar JSON y restablecer ajustes.
- Bienvenida: pide ser launcher predeterminado (RoleManager) y explica los permisos opcionales.

## 1.3 (versionCode 4)
- Atajos de apps en el menú de mantener pulsado (requiere ser el launcher predeterminado).
- Insignias de notificación (opcional: acceso a notificaciones desde Personalizar).
- Iconos: estilo temático monocromático, packs de iconos, renombrar app, icono propio.
- Cajón: scroller alfabético, orden por uso/recientes, ocultar apps, pestañas por categoría, búsqueda de contactos/ajustes/web.
- Barra de búsqueda en inicio (arriba, abajo u oculta); al tocarla abre el cajón con el teclado.
- Menú de iconos "Nombre e icono"; "Ocultar app" en el cajón; "Apps ocultas" en Personalizar.
- Permisos nuevos (todos opcionales): READ_CONTACTS (solo si activás buscar en contactos) y acceso a notificaciones.

## 1.2 (versionCode 3)
- Nuevo modelo de cuadrícula: cada icono tiene página/fila/columna y puede haber huecos vacíos.
  Mover = soltar en una celda libre (también entre páginas y dock). Soltar sobre otra app la intercambia;
  mantener ~0,5 s encima y soltar crea una carpeta.
- Migración automática desde la lista plana de 1.1 (se ve igual que antes; datos viejos conservados).
- Widgets de Android: menú de espacio vacío > Widgets. Mantener pulsado un widget: Tamaño / Quitar / arrastrar.
- Carpetas (inicio y dock) con nombre editable y animación de apertura.
- Bloquear layout.
- El dock ahora tiene 4 huecos fijos (se puede dejar un hueco vacío).
