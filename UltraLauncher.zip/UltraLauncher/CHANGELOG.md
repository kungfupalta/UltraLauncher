# Changelog

## 1.3 (versionCode 4)
- Atajos de apps al mantener pulsado un icono (si el launcher es el predeterminado).
- Insignias de notificación con número: Personalizar > "Insignias de notificación" (pide acceso a notificaciones).
- Iconos temáticos (Android 13+): Personalizar > "Iconos temáticos".
- Renombrar apps y ocultarlas del cajón (Personalizar > "Apps ocultas" para mostrarlas otra vez).
- Cajón: orden A-Z / más usadas / recientes, tira de letras, categorías, búsqueda web.
- Barra de búsqueda sobre el dock (opcional). Ojo: ocupa espacio, así que la cuadrícula puede tener una fila menos.

## 1.2 (versionCode 3)
- Nuevo modelo de cuadrícula: cada icono tiene página/fila/columna y puede haber huecos vacíos.
  Mover = soltar en una celda libre (también entre páginas y dock). Soltar sobre otra app la intercambia;
  mantener ~0,5 s encima y soltar crea una carpeta.
- Migración automática desde la lista plana de 1.1 (se ve igual que antes; datos viejos conservados).
- Widgets de Android: menú de espacio vacío > Widgets. Mantener pulsado un widget: Tamaño / Quitar / arrastrar.
- Carpetas (inicio y dock) con nombre editable y animación de apertura.
- Bloquear layout.
- El dock ahora tiene 4 huecos fijos (se puede dejar un hueco vacío).
