# Changelog

## 1.9 (versionCode 10)
- Widgets, reloj y hora de Marcos/Arianna con tamaño libre: ocupan lo que mide su contenido (ya no celdas enteras) y se pueden poner pegados entre sí.
- Redimensionar desde la esquina: mantené apretado el bloque y, con la otra mano (o sola), tocá una esquina y arrastrá; la esquina opuesta queda fija. Vista previa verde si entra; si no entra queda el último tamaño válido y se marca en rojo lo pedido. Respeta mínimos y máximos del widget.
- Al mover un bloque se pega a los bordes de la cuadrícula y a los bloques vecinos (imán de 8 dp); fuera de eso, pasos finos de 4 dp.
- Migración automática (una vez): el reloj, la hora y los widgets que tenían el tamaño por defecto se achican a su contenido sin moverse; los que ya habías agrandado se respetan.
- Reloj: tamaño inicial compacto (antes era un cuadrado de pantalla ancha). Se quitó el pellizco con dos dedos y el diálogo de tamaño por pasos.

## 1.8 (versionCode 9)
- Los widgets y bloques (reloj, hora) se redimensionan pellizcando con dos dedos después de mantener pulsado; vista previa con snap a la cuadrícula. Se quitó el botón "Tamaño".
- Mientras se edita un bloque no se disparan los gestos del inicio.
- Hora de Marcos / Arianna en una sola línea (letra ajustada) y nuevo modo "Los dos" en la misma línea.

## 1.7 (versionCode 8)
- Carpetas en el cajón de apps: arrastrá una app sobre otra (mantené medio segundo) para crear una; soltar sobre una carpeta la agrega.
- Botón de tres puntos (⋮) en el cajón: orden alfabético (A–Z / Z–A), por descarga, más usadas, últimas abiertas y manual; cambiar entre lista y páginas.
- El reloj del inicio ahora es un bloque: se mueve, se redimensiona, se quita y se vuelve a agregar desde Widgets > Ultra Launcher.
- La hora de Marcos / Arianna es un widget aparte que se activa cuando quieras.
- Migración automática del reloj fijo anterior.

## 1.6 (versionCode 7)
- Cajón de apps en páginas con deslizamiento horizontal (opción en Ajustes > Cajón). Deslizar hacia abajo lo cierra.
- Orden manual del cajón: mantené pulsado un icono y arrastralo. Al arrastrar con otro orden, pasa a Manual sin mover nada.
- Ajustes > Cajón: nuevo orden "Manual" y "Restablecer orden manual".
- El orden manual se guarda y se incluye en la copia de seguridad.

## 1.5 (versionCode 6)
- Apps de todos los perfiles (trabajo, clones) con LauncherApps; avisos de instalación/cambios por callbacks (sin BroadcastReceiver). Pestaña "Trabajo" en el cajón.
- Pantallas anchas y plegables: columnas automáticas (hasta 8 + extra), dock con ancho máximo, reloj oculto si la pantalla es baja, soporte de recortes de pantalla.
- Atrás predictivo para cerrar el cajón.
- Accesibilidad: acción "Más opciones" en iconos.
- Rendimiento: caché de iconos, carga en paralelo, menos recomposiciones.
- Con una carpeta abierta ya no se activan los gestos del inicio.

## 1.4 (versionCode 5)
- Ajustes en pantalla completa (Inicio, Dock, Cajón, Iconos, Gestos, Tema, Copia de seguridad, Acerca de). Reemplaza al diálogo Personalizar.
- Gestos configurables (doble toque, deslizar arriba/abajo, pellizco, dos dedos arriba/abajo) con acciones elegibles.
- Servicio de accesibilidad OPCIONAL solo para el gesto "Bloquear pantalla".
- Tema: modo claro/oscuro/auto, Material You, atenuado y desenfoque del fondo, fuente y tamaño de texto, animación de apertura desde el icono.
- Copia de seguridad: exportar/importar JSON y restablecer ajustes.
- Bienvenida: pide ser launcher predeterminado (RoleManager) y explica los permisos opcionales.

## 1.3 (versionCode 4)
- Atajos de apps en el menú de mantener pulsado (requiere ser el launcher predeterminado).
- Insignias de notificación (opcional: acceso a notificaciones desde Personalizar).
- Iconos: estilo temático monocromático, packs de iconos, renombrar app, icono propio.
- Cajón: scroller alfabético, orden por uso/recientes, ocultar apps, pestañas por categoría, búsqueda de contactos/ajustes/web.
- Barra de búsqueda en inicio (arriba, abajo u oculta); al tocarla abre el cajón con el teclado.
- Menú de iconos "Nombre e icono"; "Ocultar app" en el cajón; "Apps ocultas" en Personalizar.
- Permisos nuevos (todos opcionales): READ_CONTACTS (solo si activás buscar en contactos) y acceso a notificaciones.

## 1.2 (versionCode 3)
- Nuevo modelo de cuadrícula: cada icono tiene página/fila/columna y puede haber huecos vacíos.
  Mover = soltar en una celda libre (también entre páginas y dock). Soltar sobre otra app la intercambia;
  mantener ~0,5 s encima y soltar crea una carpeta.
- Migración automática desde la lista plana de 1.1 (se ve igual que antes; datos viejos conservados).
- Widgets de Android: menú de espacio vacío > Widgets. Mantener pulsado un widget: Tamaño / Quitar / arrastrar.
- Carpetas (inicio y dock) con nombre editable y animación de apertura.
- Bloquear layout.
- El dock ahora tiene 4 huecos fijos (se puede dejar un hueco vacío).
