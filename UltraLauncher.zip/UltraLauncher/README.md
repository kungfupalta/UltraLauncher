# Ultra Launcher

Launcher para Android (Kotlin + Jetpack Compose) con estética One UI del Samsung Galaxy S26 Ultra.

- Inicio con fondo de pantalla del sistema, reloj grande y fecha.
- **Línea pequeña debajo de la hora**: "Hora de Marcos · Argentina" u "Hora de Arianna · Ecuador". Tocala para elegir cuál mostrar (se guarda).
- Páginas con indicador de puntos, dock translúcido de 4 apps, iconos squircle.
- Deslizar hacia arriba: cajón de apps con buscador. Deslizar hacia abajo: notificaciones.
- Mantener pulsado un icono y **arrastrar**: reordenar (también entre inicio y dock, y de una página a otra llevándolo al borde) o soltarlo en la papelera de arriba para quitarlo de inicio/dock. Mantener pulsado sin mover: menú (quitar / info / desinstalar).
- Cajón de apps: mantener pulsado una app para añadirla a inicio o al dock.
- Mantener pulsado un espacio vacío: **Personalizar** (tamaño de iconos, columnas, forma, nombres, reloj, opacidad del dock), fondos de pantalla, elegir hora y ajustes.

Se compila con GitHub Actions (ver `.github/workflows/build.yml` en el repo).

## Novedades 1.2
- **Cuadrícula libre**: los iconos quedan donde los sueltes (con huecos). Soltar sobre otra app: intercambia; mantener medio segundo encima y soltar: crea una **carpeta**.
- **Widgets**: mantener pulsado un espacio vacío > *Widgets*. Mantener pulsado un widget para moverlo, cambiar su tamaño o quitarlo.
- **Bloquear layout**: desde el mismo menú o en *Personalizar*.
- Estado del proyecto en `ROADMAP.md` y `CHANGELOG.md`.

## Novedades 1.3
- Mantener pulsada una app: atajos de la app + Renombrar / Info / Desinstalar (y Ocultar en el cajón).
- Personalizar: orden del cajón, categorías, barra de búsqueda, iconos temáticos, insignias y apps ocultas.
- Para las insignias hay que dar "Acceso a notificaciones" a Ultra Launcher en los ajustes del sistema.
- Los atajos de apps solo los entrega Android al launcher predeterminado.
