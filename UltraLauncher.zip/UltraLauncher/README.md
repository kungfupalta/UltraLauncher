# Ultra Launcher

Launcher para Android (Kotlin + Jetpack Compose) con estética One UI del Samsung Galaxy S26 Ultra.

- Inicio con fondo de pantalla del sistema, reloj grande y fecha.
- **Línea pequeña debajo de la hora**: "Hora de Marcos · Argentina" u "Hora de Arianna · Ecuador". Tocala para elegir cuál mostrar (se guarda).
- Páginas con indicador de puntos, dock translúcido de 4 apps, iconos squircle.
- Deslizar hacia arriba: cajón de apps con buscador. Deslizar hacia abajo: notificaciones.
- Mantener pulsado un icono y **arrastrar**: reordenar (también entre inicio y dock, y de una página a otra llevándolo al borde) o soltarlo en la papelera de arriba para quitarlo de inicio/dock. Mantener pulsado sin mover: menú (quitar / info / desinstalar).
- Cajón de apps: mantener pulsado una app para añadirla a inicio o al dock.
- Mantener pulsado un espacio vacío: **Personalizar** (tamaño de iconos, columnas, forma, nombres, reloj, opacidad del dock), fondos de pantalla, elegir hora y ajustes.

Se compila con GitHub Actions (ver `.github/workflows/build.yml` en el repo).

## Novedades 1.2
- **Cuadrícula libre**: los iconos quedan donde los sueltes (con huecos). Soltar sobre otra app: intercambia; mantener medio segundo encima y soltar: crea una **carpeta**.
- **Widgets**: mantener pulsado un espacio vacío > *Widgets*. Mantener pulsado un widget para moverlo, cambiar su tamaño o quitarlo.
- **Bloquear layout**: desde el mismo menú o en *Personalizar*.
- Estado del proyecto en `ROADMAP.md` y `CHANGELOG.md`.

## Novedades 1.3
- **Mantener pulsado un icono**: atajos de la app (si Ultra Launcher es tu launcher predeterminado), *Nombre e icono*, info y desinstalar.
- **Cajón**: letras A–Z a la derecha, orden (A–Z / más usadas / recientes), pestañas por categoría y *Ocultar app*.
- **Búsqueda**: apps, contactos (opcional), ajustes del sistema y web. Barra también en el inicio.
- **Iconos**: estilo temático, packs de iconos e imagen propia por app (en *Personalizar*).
- **Insignias**: opcionales; hay que dar acceso a notificaciones (se explica en *Personalizar*).

## Novedades 1.4
- **Ajustes** en pantalla completa: mantené pulsado un espacio vacío > *Personalizar*.
- **Gestos**: Ajustes > Gestos (doble toque, deslizar, pellizco, dos dedos).
- **Tema**: claro/oscuro/auto, colores dinámicos, atenuado/desenfoque del fondo, fuente y tamaño de texto.
- **Copia de seguridad**: Ajustes > Copia de seguridad (exportar/importar JSON).
- **Bienvenida** al primer inicio (se puede repetir desde Ajustes > Acerca de).

## Novedades 1.5
- Si tenés **perfil de trabajo** o clones, sus apps aparecen en el cajón (pestaña *Trabajo*) con el maletín.
- En **tablets / plegables / horizontal** se agregan columnas solas.
- **Atrás predictivo** al cerrar el cajón (Android 13+).

## Novedades 1.6
- **Cajón en páginas**: Ajustes > Cajón > *Cajón en páginas* para deslizar de izquierda a derecha.
- **Orden manual**: en el cajón, mantené pulsado un icono y arrastralo a donde quieras.

## Novedades 1.7
- **Cajón**: carpetas, y un botón ⋮ para ordenar (A–Z, Z–A, por descarga, más usadas, últimas abiertas, manual).
- **Reloj**: mantené pulsado el reloj para moverlo, cambiarle el tamaño o quitarlo. Para volver a ponerlo (o poner la hora de Marcos/Arianna): mantené pulsado un espacio vacío > Widgets > Ultra Launcher.

## Novedades 1.8
- **Tamaño a gusto**: mantené pulsado un widget (o el reloj / la hora), tocá una esquina con la otra mano y arrastrá; soltá para aplicar. Queda pegado a lo que mide el widget y se pega a los vecinos. Arrastralo con un dedo para moverlo.
- **Hora de corrido**: Marcos / Arianna en una sola línea; tocala y elegí "Los dos" para verlos juntos.
