# ROADMAP — Ultra Launcher

Estado: **v1.6 (versionCode 7)** — Roadmap original completo (1.2 a 1.5, verificado) + Tanda 1.6 (cajón horizontal y orden manual), pendiente de compilar y probar.

## Tanda 1.2 — Base  ✅ hecha
- [x] Cuadrícula con posiciones libres (página, fila, columna) y celdas vacías (`HomeModel.kt`).
- [x] Migración de la lista plana antigua (SharedPreferences) sin borrar las claves viejas (quedan de respaldo).
- [x] Widgets de Android: selector propio, permiso de bind, pantalla de configuración, mover, redimensionar, quitar.
- [x] Reloj Marcos/Arianna intacto (cabecera fija de la página 1).
- [x] Carpetas: arrastrar app sobre app, nombre editable, apertura animada, también en el dock.
- [x] Bloquear layout (menú de espacio vacío y Personalizar).
- [ ] (Menor) Arrastrar apps fuera de una carpeta: hoy se usa "Sacar de la carpeta" en el menú.

## Tanda 1.3 — Apps e iconos  ✅ hecha
- [x] Atajos de apps (LauncherApps) en el menú de mantener pulsado (solo si este launcher es el predeterminado).
- [x] Insignias de notificación con NotificationListenerService (opcional, con explicación en Personalizar).
- [x] Iconos adaptativos (ya), temáticos monocromáticos (Android 13+), packs de iconos ADW/Nova, renombrar app, icono propio desde la galería.
- [x] Cajón: scroller A–Z, orden (A–Z / más usadas / recientes), ocultar apps, pestañas por categoría, búsqueda de apps + contactos (permiso opcional) + ajustes + web.
- [x] Barra de búsqueda en inicio (arriba / abajo / oculta).
- [ ] (Menor) Elegir icono de la app desde un pack concreto (hoy el pack se aplica a todas; el icono propio viene de la galería).
- [ ] (Menor) Atajos con icono y arrastrar un atajo al inicio.

## Tanda 1.4 — Personalización  ✅ hecha
- [x] Pantalla de ajustes completa (no diálogo) con secciones: Inicio, Dock, Cajón, Iconos, Gestos, Tema, Copia de seguridad, Acerca de.
- [x] Gestos configurables: doble toque, deslizar arriba/abajo, pellizco, dos dedos arriba/abajo. Acciones: notificaciones, ajustes rápidos, cajón, buscar, linterna, bloquear pantalla (AccessibilityService opcional), abrir app, ajustes del launcher.
- [x] Tema: claro/oscuro/auto, colores dinámicos Material You, atenuado del fondo (inicio y cajón), desenfoque del fondo con el cajón, fuente, tamaño de texto, animación de apertura desde el icono.
- [x] Exportar/importar copia de seguridad (JSON) y restablecer ajustes.
- [x] Onboarding con RoleManager (ROLE_HOME) y explicación de permisos opcionales.
- [ ] (Menor) El tema claro/oscuro/dinámico no cambia los menús del inicio que van sobre el fondo (carpetas, marco de widgets).
- [ ] (Menor) La copia no incluye widgets ni imágenes de iconos propios.

## Tanda 1.5 — Robustez  ✅ hecha
- [x] Perfil de trabajo y multiusuario con `LauncherApps` (apps de todos los perfiles, callbacks en vez de BroadcastReceiver, pestaña "Trabajo", abrir/info/desinstalar por perfil).
- [x] Pantallas anchas: columnas automáticas, dock con ancho máximo, reloj que se oculta en pantallas bajas, recortes de pantalla y barra lateral.
- [x] Edge-to-edge (ya estaba) + gesto de atrás predictivo para cerrar el cajón.
- [x] Accesibilidad: acción "Más opciones" para TalkBack en cada icono y sin etiquetas duplicadas.
- [x] Rendimiento: caché de iconos por app/estilo/pack, carga de iconos en paralelo, clases inmutables para Compose, búsqueda del cajón memorizada.
- [x] Pulido: los gestos del inicio se ignoran con una carpeta abierta.

## Tanda 1.6 — Cajón a gusto  ✅ hecha
- [x] Cajón en páginas que se deslizan en horizontal (opcional; la lista vertical sigue disponible).
- [x] Orden manual: mantener pulsado un icono y arrastrarlo (en lista y en páginas, con desplazamiento/cambio de página en los bordes).
- [x] Pasar a orden manual al primer arrastre sin cambiar lo que se ve; restablecer a A–Z.
- [x] El orden manual entra en la copia de seguridad.
- [ ] (Menor) Reordenar mientras se buscan o filtran apps con texto (hoy solo sin búsqueda).

## Deuda técnica conocida
- Layout y ajustes siguen en SharedPreferences (JSON); sin Room/DataStore.
- Arrastrar apps fuera de una carpeta (hoy: "Sacar de la carpeta" en el menú).
- La copia de seguridad no incluye widgets ni imágenes de iconos propios.
- Tema claro/oscuro/dinámico no cambia carpetas ni el marco de edición de widgets (van sobre el fondo).
- Linterna: no se sincroniza con el estado real si se enciende desde otro lado.
