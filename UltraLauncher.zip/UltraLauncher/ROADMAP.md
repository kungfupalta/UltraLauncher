# ROADMAP — Ultra Launcher

Estado: **v1.3 (versionCode 4)** — Tandas 1.2 y 1.3 implementadas (pendientes de verificar en compilación).

## Tanda 1.2 — Base  ✅ hecha
- [x] Cuadrícula con posiciones libres (página, fila, columna) y celdas vacías (`HomeModel.kt`).
- [x] Migración de la lista plana antigua (SharedPreferences) sin borrar las claves viejas (quedan de respaldo).
- [x] Widgets de Android: selector propio, permiso de bind, pantalla de configuración, mover, redimensionar, quitar.
- [x] Reloj Marcos/Arianna intacto (cabecera fija de la página 1).
- [x] Carpetas: arrastrar app sobre app, nombre editable, apertura animada, también en el dock.
- [x] Bloquear layout (menú de espacio vacío y Personalizar).
- [ ] (Menor) Arrastrar apps fuera de una carpeta: hoy se usa "Sacar de la carpeta" en el menú.

## Tanda 1.3 — Apps e iconos  ✅ hecha
- [x] Atajos de apps (LauncherApps) en el menú de mantener pulsado (solo si este launcher es el predeterminado).
- [x] Insignias de notificación con NotificationListenerService (opcional, con explicación en Personalizar).
- [x] Iconos adaptativos (ya), temáticos monocromáticos (Android 13+), packs de iconos ADW/Nova, renombrar app, icono propio desde la galería.
- [x] Cajón: scroller A–Z, orden (A–Z / más usadas / recientes), ocultar apps, pestañas por categoría, búsqueda de apps + contactos (permiso opcional) + ajustes + web.
- [x] Barra de búsqueda en inicio (arriba / abajo / oculta).
- [ ] (Menor) Elegir icono de la app desde un pack concreto (hoy el pack se aplica a todas; el icono propio viene de la galería).
- [ ] (Menor) Atajos con icono y arrastrar un atajo al inicio.

## Tanda 1.4 — Personalización  ⏳ pendiente
Pantalla de ajustes completa, gestos configurables, tema (Material You, desenfoque, fuente), exportar/importar JSON, onboarding con RoleManager.

## Tanda 1.5 — Robustez  ⏳ pendiente
Perfil de trabajo/multiusuario con callbacks de LauncherApps, tablets/plegables, atrás predictivo, accesibilidad, caché de iconos, pulido.

## Deuda técnica conocida
- `BroadcastReceiver` de paquetes (se reemplaza en 1.5 por `LauncherApps.Callback`).
- Iconos de todas las apps se cargan de una vez al iniciar (caché/async fino en 1.5).
- Preferencias en SharedPreferences (JSON para el layout); sin Room/DataStore.
- Overlay de carpeta vive dentro del Box con gestos de cajón/long-press del inicio.
