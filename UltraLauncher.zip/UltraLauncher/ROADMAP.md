# ROADMAP — Ultra Launcher

Estado: **v1.3 (versionCode 4)** — Tanda 1.3 implementada (pendiente de verificar en compilación). La 1.2 ya fue probada por el usuario y funciona.

## Tanda 1.2 — Base  ✅ hecha
- [x] Cuadrícula con posiciones libres (página, fila, columna) y celdas vacías (`HomeModel.kt`).
- [x] Migración de la lista plana antigua (SharedPreferences) sin borrar las claves viejas (quedan de respaldo).
- [x] Widgets de Android: selector propio, permiso de bind, pantalla de configuración, mover, redimensionar, quitar.
- [x] Reloj Marcos/Arianna intacto (cabecera fija de la página 1).
- [x] Carpetas: arrastrar app sobre app, nombre editable, apertura animada, también en el dock.
- [x] Bloquear layout (menú de espacio vacío y Personalizar).
- [ ] (Menor) Arrastrar apps fuera de una carpeta: hoy se usa "Sacar de la carpeta" en el menú.

## Tanda 1.3 — Apps e iconos  ✅ hecha (salvo lo marcado)
- [x] Atajos de apps (LauncherApps) en el menú de mantener pulsado (solo si es el launcher predeterminado).
- [x] Insignias de notificación con número (NotificationListenerService; opcional desde Personalizar).
- [x] Iconos temáticos monocromáticos (Android 13+, colores del sistema en Android 12+).
- [x] Renombrar app (solo en este launcher) y volver al nombre original.
- [x] Cajón: letras laterales (orden A-Z), orden A-Z / más usadas / recientes, ocultar apps (+ lista para mostrarlas), categorías, búsqueda web, Enter abre la primera coincidencia.
- [x] Barra de búsqueda sobre el dock (abre el cajón con el teclado).
- [ ] Packs de iconos (ADW/Nova) e icono personalizado por app.
- [ ] Búsqueda de contactos en el cajón (necesita permiso READ_CONTACTS).
- [ ] Barra de búsqueda arriba (hoy solo "sobre el dock" u oculta).
- [ ] Insignia (suma) en las carpetas.

## Tanda 1.4 — Personalización  ⏳ pendiente
Pantalla de ajustes completa, gestos configurables, tema (Material You, desenfoque, fuente), exportar/importar JSON, onboarding con RoleManager.

## Tanda 1.5 — Robustez  ⏳ pendiente
Perfil de trabajo/multiusuario con callbacks de LauncherApps, tablets/plegables, atrás predictivo, accesibilidad, caché de iconos, pulido.

## Deuda técnica conocida
- `BroadcastReceiver` de paquetes (se reemplaza en 1.5 por `LauncherApps.Callback`).
- Iconos de todas las apps se cargan de una vez al iniciar (caché/async fino en 1.5).
- Preferencias en SharedPreferences (JSON para el layout); sin Room/DataStore.
- Overlay de carpeta vive dentro del Box con gestos de cajón/long-press del inicio.
