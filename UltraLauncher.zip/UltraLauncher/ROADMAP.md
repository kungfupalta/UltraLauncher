# ROADMAP — Ultra Launcher

Estado: **v1.9 (versionCode 10)** — Tanda 2.0 corregida (tamaño libre y esquina), pendiente de compilar y probar. Siguiente: Tanda 2.1 (Modo Minimal) según PROMPT_UltraLauncher_v2.md.

## Tanda 1.2 — Base  ✅ hecha
- [x] Cuadrícula con posiciones libres (página, fila, columna) y celdas vacías (`HomeModel.kt`).
- [x] Migración de la lista plana antigua (SharedPreferences) sin borrar las claves viejas (quedan de respaldo).
- [x] Widgets de Android: selector propio, permiso de bind, pantalla de configuración, mover, redimensionar, quitar.
- [x] Reloj Marcos/Arianna intacto (cabecera fija de la página 1).
- [x] Carpetas: arrastrar app sobre app, nombre editable, apertura animada, también en el dock.
- [x] Bloquear layout (menú de espacio vacío y Personalizar).
- [ ] (Menor) Arrastrar apps fuera de una carpeta: hoy se usa "Sacar de la carpeta" en el menú.

## Tanda 1.3 — Apps e iconos  ✅ hecha
- [x] Atajos de apps (LauncherApps) en el menú de mantener pulsado (solo si este launcher es el predeterminado).
- [x] Insignias de notificación con NotificationListenerService (opcional, con explicación en Personalizar).
- [x] Iconos adaptativos (ya), temáticos monocromáticos (Android 13+), packs de iconos ADW/Nova, renombrar app, icono propio desde la galería.
- [x] Cajón: scroller A–Z, orden (A–Z / más usadas / recientes), ocultar apps, pestañas por categoría, búsqueda de apps + contactos (permiso opcional) + ajustes + web.
- [x] Barra de búsqueda en inicio (arriba / abajo / oculta).
- [ ] (Menor) Elegir icono de la app desde un pack concreto (hoy el pack se aplica a todas; el icono propio viene de la galería).
- [ ] (Menor) Atajos con icono y arrastrar un atajo al inicio.

## Tanda 1.4 — Personalización  ✅ hecha
- [x] Pantalla de ajustes completa (no diálogo) con secciones: Inicio, Dock, Cajón, Iconos, Gestos, Tema, Copia de seguridad, Acerca de.
- [x] Gestos configurables: doble toque, deslizar arriba/abajo, pellizco, dos dedos arriba/abajo. Acciones: notificaciones, ajustes rápidos, cajón, buscar, linterna, bloquear pantalla (AccessibilityService opcional), abrir app, ajustes del launcher.
- [x] Tema: claro/oscuro/auto, colores dinámicos Material You, atenuado del fondo (inicio y cajón), desenfoque del fondo con el cajón, fuente, tamaño de texto, animación de apertura desde el icono.
- [x] Exportar/importar copia de seguridad (JSON) y restablecer ajustes.
- [x] Onboarding con RoleManager (ROLE_HOME) y explicación de permisos opcionales.
- [ ] (Menor) El tema claro/oscuro/dinámico no cambia los menús del inicio que van sobre el fondo (carpetas, marco de widgets).
- [ ] (Menor) La copia no incluye widgets ni imágenes de iconos propios.

## Tanda 1.5 — Robustez  ✅ hecha
- [x] Perfil de trabajo y multiusuario con `LauncherApps` (apps de todos los perfiles, callbacks en vez de BroadcastReceiver, pestaña "Trabajo", abrir/info/desinstalar por perfil).
- [x] Pantallas anchas: columnas automáticas, dock con ancho máximo, reloj que se oculta en pantallas bajas, recortes de pantalla y barra lateral.
- [x] Edge-to-edge (ya estaba) + gesto de atrás predictivo para cerrar el cajón.
- [x] Accesibilidad: acción "Más opciones" para TalkBack en cada icono y sin etiquetas duplicadas.
- [x] Rendimiento: caché de iconos por app/estilo/pack, carga de iconos en paralelo, clases inmutables para Compose, búsqueda del cajón memorizada.
- [x] Pulido: los gestos del inicio se ignoran con una carpeta abierta.

## Tanda 1.6 — Cajón a gusto  ✅ hecha
- [x] Cajón en páginas que se deslizan en horizontal (opcional; la lista vertical sigue disponible).
- [x] Orden manual: mantener pulsado un icono y arrastrarlo (en lista y en páginas, con desplazamiento/cambio de página en los bordes).
- [x] Pasar a orden manual al primer arrastre sin cambiar lo que se ve; restablecer a A–Z.
- [x] El orden manual entra en la copia de seguridad.
- [ ] (Menor) Reordenar mientras se buscan o filtran apps con texto (hoy solo sin búsqueda).

## Tanda 1.7 — Carpetas del cajón, orden y reloj como widget  ✅ hecha
- [x] Carpetas en el cajón (arrastrar una app sobre otra y mantener; soltar sobre una carpeta la agrega; nombre editable; deshacer; sacar apps).
- [x] Botón ⋮ en el cajón: orden A–Z, Z–A, por descarga, más usadas, últimas abiertas y manual; ver en lista o en páginas; restablecer orden.
- [x] El reloj del inicio es un bloque: se mueve, se redimensiona (el texto se adapta), se quita y se vuelve a agregar desde Widgets.
- [x] La hora de Marcos / Arianna es un bloque aparte que se agrega cuando se quiere (Widgets > Ultra Launcher).
- [x] Migración: el reloj fijo de versiones anteriores pasa a ser un bloque sin mover tus iconos.
- [ ] (Menor) Reordenar con las pestañas por categoría activas (hoy se desactiva).

## Tanda 2.0 — Widgets a gusto + hora de corrido  ✅ hecha
- [x] Redimensionar con dos dedos (pellizco) tras mantener pulsado: separar agranda, juntar achica; horizontal = columnas, vertical = filas; vista previa con snap a la cuadrícula, verde si entra / rojo si no, háptico por paso, se aplica al soltar.
- [x] Sin botón "Tamaño": quedan arrastrar para mover y "Quitar". Para TalkBack: acciones Agrandar / Achicar / Quitar.
- [x] Hora de Marcos / Arianna en una sola línea con letra que se ajusta al ancho; modo "Los dos" en la misma línea.
- [x] Diálogo de tamaño por pasos eliminado.

## Tanda 2.0b — Tamaño libre y redimensionar por esquina  ✅ hecha (v1.9)
- [x] Bloques con rectángulo libre en dp (`fx, fy, fw, fh` en `HomeItem`); las celdas que tocan se recalculan para que las apps los esquiven. Entre bloques la colisión es en dp (pueden ir pegados).
- [x] Tamaño inicial = lo que pide el widget (minWidth/minHeight); reloj 170x96 dp, hora 280x40 dp.
- [x] Redimensionar tocando una esquina (con la otra mano mientras se mantiene apretado, o sola) y arrastrando; imán a líneas de celdas y bordes de vecinos, si no, pasos de 4 dp.
- [x] Mover con un dedo con el mismo imán; vista previa verde/roja.
- [x] Migración única `free_blocks_v1` de bloques viejos con tamaño por defecto.
- [ ] Pendiente menor: las apps no pueden usar las celdas que un bloque toca solo en parte (se cubren celdas enteras).
- [ ] Pendiente menor: la vista previa es un marco; el widget recién se redibuja al soltar.

## Deuda técnica conocida
- Layout y ajustes siguen en SharedPreferences (JSON); sin Room/DataStore.
- Arrastrar apps fuera de una carpeta (hoy: "Sacar de la carpeta" en el menú).
- La copia de seguridad no incluye widgets ni imágenes de iconos propios.
- Tema claro/oscuro/dinámico no cambia carpetas ni el marco de edición de widgets (van sobre el fondo).
- Linterna: no se sincroniza con el estado real si se enciende desde otro lado.
