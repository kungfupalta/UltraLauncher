package com.marcos.ultralauncher

import android.content.pm.ApplicationInfo

/** Categorías para las pestañas del cajón (se deducen de la categoría que declara cada app). */
enum class AppCategory(val label: String) {
    ALL("Todas"),
    GAMES("Juegos"),
    SOCIAL("Social"),
    MEDIA("Multimedia"),
    PRODUCTIVITY("Productividad"),
    OTHER("Otras");

    companion object {
        @Suppress("DEPRECATION")
        fun of(info: ApplicationInfo): AppCategory {
            if ((info.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return GAMES
            return when (info.category) {
                ApplicationInfo.CATEGORY_GAME -> GAMES
                ApplicationInfo.CATEGORY_SOCIAL -> SOCIAL
                ApplicationInfo.CATEGORY_AUDIO,
                ApplicationInfo.CATEGORY_VIDEO,
                ApplicationInfo.CATEGORY_IMAGE,
                -> MEDIA
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> PRODUCTIVITY
                else -> OTHER
            }
        }
    }
}
