package com.marcos.ultralauncher

import android.content.pm.ApplicationInfo

/** Categorías simples para filtrar el cajón (salen de la categoría que declara cada app). */
enum class AppCategory(val label: String) {
    ALL("Todas"),
    GAMES("Juegos"),
    SOCIAL("Social"),
    MEDIA("Multimedia"),
    PRODUCTIVITY("Productividad"),
    OTHER("Otras"),
}

fun AppInfo.appCategory(): AppCategory = when (category) {
    ApplicationInfo.CATEGORY_GAME -> AppCategory.GAMES
    ApplicationInfo.CATEGORY_SOCIAL, ApplicationInfo.CATEGORY_NEWS -> AppCategory.SOCIAL
    ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> AppCategory.MEDIA
    ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_MAPS -> AppCategory.PRODUCTIVITY
    else -> AppCategory.OTHER
}
