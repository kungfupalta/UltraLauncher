package com.marcos.ultralauncher

import android.content.Context
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.os.Process
import android.os.UserHandle

/** Un atajo de app (los que aparecen al mantener pulsado el icono). */
data class AppShortcut(val info: ShortcutInfo, val label: String)

/**
 * Atajos de una app. Android solo los entrega al launcher predeterminado: si este launcher
 * no lo es, la lista llega vacía (sin errores).
 */
fun Context.loadShortcuts(packageName: String, user: UserHandle? = null, max: Int = 4): List<AppShortcut> {
    return try {
        val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps ?: return emptyList()
        if (!la.hasShortcutHostPermission()) return emptyList()
        val query = LauncherApps.ShortcutQuery()
            .setPackage(packageName)
            .setQueryFlags(
                LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED,
            )
        val list = la.getShortcuts(query, user ?: Process.myUserHandle()) ?: return emptyList()
        list.filter { it.isEnabled }
            .mapNotNull { si ->
                val label = (si.shortLabel ?: si.longLabel)?.toString()
                if (label.isNullOrBlank()) null else AppShortcut(si, label)
            }
            .take(max)
    } catch (e: Exception) {
        emptyList()
    }
}

fun Context.startAppShortcut(shortcut: AppShortcut) {
    try {
        val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps ?: return
        la.startShortcut(shortcut.info, null, null)
    } catch (e: Exception) {
    }
}
