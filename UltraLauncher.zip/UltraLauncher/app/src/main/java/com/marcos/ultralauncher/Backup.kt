package com.marcos.ultralauncher

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Copia de seguridad: exporta/importa todas las preferencias del launcher (ajustes, layout,
 * carpetas, nombres, apps ocultas, gestos...) como un JSON legible.
 * No incluye widgets (dependen del dispositivo) ni imágenes de iconos propios.
 */
object LauncherBackup {

    /** Claves propias de este dispositivo que no se copian. */
    private val skip = setOf("onboarded")

    fun exportJson(prefs: SharedPreferences, versionName: String): String {
        val root = JSONObject()
        root.put("app", "UltraLauncher")
        root.put("format", 1)
        root.put("version", versionName)
        val p = JSONObject()
        for ((k, v) in prefs.all) {
            if (k in skip) continue
            val e = JSONObject()
            when (v) {
                is String -> {
                    e.put("t", "s")
                    e.put("v", v)
                }
                is Int -> {
                    e.put("t", "i")
                    e.put("v", v)
                }
                is Long -> {
                    e.put("t", "l")
                    e.put("v", v)
                }
                is Float -> {
                    e.put("t", "f")
                    e.put("v", v.toDouble())
                }
                is Boolean -> {
                    e.put("t", "b")
                    e.put("v", v)
                }
                is Set<*> -> {
                    e.put("t", "ss")
                    e.put("v", JSONArray(v.map { it.toString() }))
                }
                else -> continue
            }
            p.put(k, e)
        }
        root.put("prefs", p)
        return root.toString(2)
    }

    /** Aplica el JSON a las preferencias. Devuelve false si no es una copia válida. */
    fun importJson(prefs: SharedPreferences, text: String): Boolean {
        val root = JSONObject(text)
        if (root.optString("app") != "UltraLauncher") return false
        val p = root.getJSONObject("prefs")
        val ed = prefs.edit()
        for (k in p.keys()) {
            if (k in skip) continue
            val e = p.getJSONObject(k)
            when (e.getString("t")) {
                "s" -> ed.putString(k, e.getString("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "ss" -> {
                    val a = e.getJSONArray("v")
                    val set = HashSet<String>()
                    for (i in 0 until a.length()) set.add(a.getString(i))
                    ed.putStringSet(k, set)
                }
            }
        }
        ed.apply()
        return true
    }
}
