package com.marcos.ultralauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Cantidad de notificaciones activas por paquete (la leen los iconos para mostrar la insignia). */
object BadgeStore {
    var counts by mutableStateOf<Map<String, Int>>(emptyMap())
}

/**
 * Servicio OPCIONAL: solo funciona si el usuario le da "acceso a notificaciones".
 * Solo cuenta notificaciones por app; no guarda ni envía su contenido.
 */
class BadgeService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        recompute()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        BadgeStore.counts = emptyMap()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        recompute()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        recompute()
    }

    private fun recompute() {
        val list: Array<StatusBarNotification>? = try {
            activeNotifications
        } catch (e: Exception) {
            null
        }
        if (list == null) return
        val map = HashMap<String, Int>()
        for (n in list) {
            if (n.isOngoing) continue
            if ((n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
            map[n.packageName] = (map[n.packageName] ?: 0) + 1
        }
        BadgeStore.counts = map
    }
}
