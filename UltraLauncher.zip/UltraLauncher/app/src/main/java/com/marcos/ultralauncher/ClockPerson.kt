package com.marcos.ultralauncher

import java.time.ZoneId

/**
 * Las dos "horas" elegibles que se muestran debajo del reloj del inicio.
 */
enum class ClockPerson(
    val id: String,
    val displayName: String,
    val country: String,
    private val zoneId: String,
) {
    MARCOS("marcos", "Marcos", "Argentina", "America/Argentina/Buenos_Aires"),
    ARIANNA("arianna", "Arianna", "Ecuador", "America/Guayaquil");

    val zone: ZoneId get() = ZoneId.of(zoneId)

    companion object {
        fun fromId(id: String?): ClockPerson = entries.firstOrNull { it.id == id } ?: MARCOS
    }
}
