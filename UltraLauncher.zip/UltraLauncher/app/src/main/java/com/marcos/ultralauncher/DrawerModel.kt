package com.marcos.ultralauncher

import androidx.compose.runtime.Immutable

/** Carpeta del cajón de apps (sirve para ordenar; no cambia nada en el inicio). */
@Immutable
data class DrawerFolder(
    val id: String,
    val name: String,
    val keys: List<String>,
)

/** Lo que se muestra en el cajón: una app suelta o una carpeta. */
sealed interface DrawerEntry {
    /** Clave única: la de la app, o "f:<id>" para carpetas. */
    val key: String
    val label: String
}

@Immutable
class AppEntry(val app: AppInfo) : DrawerEntry {
    override val key: String get() = app.key
    override val label: String get() = app.label
}

@Immutable
class FolderEntry(val folder: DrawerFolder, val apps: List<AppInfo>) : DrawerEntry {
    override val key: String get() = "f:" + folder.id
    override val label: String get() = folder.name.ifBlank { "Carpeta" }
}
