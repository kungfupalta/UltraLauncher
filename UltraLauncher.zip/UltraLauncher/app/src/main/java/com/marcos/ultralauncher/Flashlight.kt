package com.marcos.ultralauncher

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager

/** Linterna: no necesita permiso de cámara. */
object Flashlight {
    private var on = false

    fun toggle(context: Context) {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            on = !on
            cm.setTorchMode(id, on)
        } catch (e: Exception) {
            on = false
        }
    }
}
