package com.marcos.ultralauncher

import org.json.JSONObject

/** Gestos configurables del inicio. */
enum class GestureType(val id: String, val label: String) {
    DOUBLE_TAP("double_tap", "Doble toque"),
    SWIPE_UP("swipe_up", "Deslizar hacia arriba"),
    SWIPE_DOWN("swipe_down", "Deslizar hacia abajo"),
    PINCH("pinch", "Pellizco (juntar dos dedos)"),
    TWO_UP("two_up", "Dos dedos hacia arriba"),
    TWO_DOWN("two_down", "Dos dedos hacia abajo"),
}

/** Lo que puede hacer un gesto. */
enum class GestureAction(val id: String, val label: String) {
    NONE("none", "Ninguna"),
    NOTIFICATIONS("notifications", "Abrir notificaciones"),
    QUICK_SETTINGS("quick_settings", "Ajustes rápidos"),
    DRAWER("drawer", "Abrir el cajón de apps"),
    SEARCH("search", "Buscar"),
    FLASHLIGHT("flashlight", "Linterna"),
    LOCK_SCREEN("lock", "Bloquear pantalla (requiere accesibilidad)"),
    OPEN_APP("open_app", "Abrir una app"),
    LAUNCHER_SETTINGS("settings", "Ajustes del launcher");

    companion object {
        fun fromId(id: String?): GestureAction = entries.firstOrNull { it.id == id } ?: NONE
    }
}

/** Acción elegida para un gesto; [appKey] solo se usa con OPEN_APP. */
data class GestureBinding(val action: GestureAction, val appKey: String = "")

fun defaultGestures(): Map<GestureType, GestureBinding> = mapOf(
    GestureType.DOUBLE_TAP to GestureBinding(GestureAction.NONE),
    GestureType.SWIPE_UP to GestureBinding(GestureAction.DRAWER),
    GestureType.SWIPE_DOWN to GestureBinding(GestureAction.NOTIFICATIONS),
    GestureType.PINCH to GestureBinding(GestureAction.NONE),
    GestureType.TWO_UP to GestureBinding(GestureAction.NONE),
    GestureType.TWO_DOWN to GestureBinding(GestureAction.NONE),
)

/** Se guarda como JSON: { "swipe_up": "drawer|", "double_tap": "open_app|com.app/Main" }. */
fun encodeGestures(map: Map<GestureType, GestureBinding>): String {
    val o = JSONObject()
    for ((g, b) in map) o.put(g.id, b.action.id + "|" + b.appKey)
    return o.toString()
}

fun decodeGestures(text: String?): Map<GestureType, GestureBinding> {
    val out = HashMap(defaultGestures())
    if (text.isNullOrEmpty()) return out
    try {
        val o = JSONObject(text)
        for (g in GestureType.entries) {
            if (!o.has(g.id)) continue
            val raw = o.getString(g.id)
            val i = raw.indexOf('|')
            val action = GestureAction.fromId(if (i >= 0) raw.substring(0, i) else raw)
            val key = if (i >= 0) raw.substring(i + 1) else ""
            out[g] = GestureBinding(action, key)
        }
    } catch (e: Exception) {
    }
    return out
}
