package com.marcos.ultralauncher

import androidx.compose.runtime.Immutable
import org.json.JSONArray
import org.json.JSONObject

/** Página especial: el dock (sus huecos van de 0 a [DOCK_SLOTS] - 1 en la columna). */
const val DOCK_PAGE = -1
const val DOCK_SLOTS = 4

/** Máximo de apps dentro de una carpeta. */
const val FOLDER_MAX = 12

/** CLOCK = reloj grande, PERSON = hora de Marcos/Arianna: bloques propios que se mueven y redimensionan como un widget. */
enum class ItemType { APP, FOLDER, WIDGET, CLOCK, PERSON }

/** Filas que ocupa por defecto el reloj en el inicio. */
const val CLOCK_ROWS = 2

/**
 * Un elemento colocado en una celda de la cuadrícula (página, fila, columna).
 * - APP: un icono ([appKey]).
 * - FOLDER: varias apps ([children]) con un nombre ([title]).
 * - WIDGET: un widget de Android ([widgetId]) que ocupa [spanRows] x [spanCols] celdas.
 * Los elementos del dock usan page = [DOCK_PAGE], row = 0 y col = número de hueco.
 */
@Immutable
data class HomeItem(
    val id: String,
    val type: ItemType,
    val page: Int,
    val row: Int,
    val col: Int,
    val spanRows: Int = 1,
    val spanCols: Int = 1,
    val appKey: String? = null,
    val title: String = "",
    val children: List<String> = emptyList(),
    val widgetId: Int = -1,
) {
    val isDock: Boolean get() = page == DOCK_PAGE

    /** Ocupa varias celdas y se mueve/redimensiona (widget de Android, reloj u hora de una persona). */
    val isBlock: Boolean get() = type == ItemType.WIDGET || type == ItemType.CLOCK || type == ItemType.PERSON

    /** ¿Esta celda (r, c) pertenece al elemento? */
    fun covers(r: Int, c: Int): Boolean =
        (r in row until (row + spanRows)) && (c in col until (col + spanCols))
}

/** Medidas de la cuadrícula visible; las informa la pantalla de inicio. */
data class GridMetrics(
    val columns: Int,
    val rowsFirst: Int,
    val rowsOther: Int,
    val cellWDp: Float,
    val cellHDp: Float,
) {
    /** La primera página tiene menos filas porque lleva el reloj arriba. */
    fun rowsOf(page: Int): Int = if (page == 0) rowsFirst else rowsOther
}

class LayoutSnapshot(val home: List<HomeItem>, val dock: List<HomeItem>)

/** ¿El rectángulo está libre en esa página? (se ignora el elemento [ignoreId]). */
fun isRectFree(
    items: List<HomeItem>,
    page: Int,
    row: Int,
    col: Int,
    sr: Int,
    sc: Int,
    ignoreId: String? = null,
): Boolean = items.none { o ->
    o.id != ignoreId &&
        o.page == page &&
        o.row < row + sr && row < o.row + o.spanRows &&
        o.col < col + sc && col < o.col + o.spanCols
}

/** Primer hueco libre (página, fila, columna) empezando en [startPage]; siempre termina. */
fun findFreeRect(
    items: List<HomeItem>,
    m: GridMetrics,
    startPage: Int,
    sr: Int,
    sc: Int,
): Triple<Int, Int, Int> {
    var p = startPage.coerceAtLeast(0)
    while (true) {
        val rows = m.rowsOf(p)
        for (r in 0..(rows - sr)) {
            for (c in 0..(m.columns - sc)) {
                if (isRectFree(items, p, r, c, sr, sc)) return Triple(p, r, c)
            }
        }
        p++
    }
}

/** Elimina páginas intermedias vacías (la página 0 se conserva siempre). */
fun compactPages(items: List<HomeItem>): List<HomeItem> {
    val pages = (items.filter { it.page >= 0 }.map { it.page } + 0).distinct().sorted()
    val map = HashMap<Int, Int>()
    pages.forEachIndexed { index, p -> map[p] = index }
    return items.map { if (it.page >= 0) it.copy(page = map[it.page] ?: it.page) else it }
}

/**
 * Calcula cómo se ve el layout con las medidas actuales: corrige elementos fuera de la
 * cuadrícula o superpuestos SIN tocar lo guardado (así girar la pantalla no desordena nada).
 * Al editar, lo que se ve pasa a ser lo guardado.
 */
fun resolveLayout(items: List<HomeItem>, m: GridMetrics?): LayoutSnapshot {
    // Dock: un elemento por hueco
    val dockOut = ArrayList<HomeItem>()
    val used = HashSet<Int>()
    val overflow = ArrayList<HomeItem>()
    val dockIn = items
        .filter { it.page == DOCK_PAGE && !it.isBlock }
        .sortedBy { it.col }
    for (d in dockIn) {
        val wanted = d.col
        val slot = if (wanted in 0 until DOCK_SLOTS && wanted !in used) {
            wanted
        } else {
            (0 until DOCK_SLOTS).firstOrNull { it !in used }
        }
        if (slot == null) {
            overflow.add(d)
        } else {
            used.add(slot)
            dockOut.add(d.copy(row = 0, col = slot, spanRows = 1, spanCols = 1))
        }
    }

    val homeIn = items.filter { it.page >= 0 } +
        overflow.map { it.copy(page = 0, row = 0, col = 0) }
    if (m == null) return LayoutSnapshot(homeIn, dockOut)

    fun inBounds(page: Int, row: Int, col: Int, sr: Int, sc: Int): Boolean =
        page >= 0 && row >= 0 && col >= 0 && row + sr <= m.rowsOf(page) && col + sc <= m.columns

    val out = ArrayList<HomeItem>()
    val order = compareBy<HomeItem>({ it.page }, { it.row }, { it.col })

    // 1) Widgets primero (ocupan más espacio)
    val widgets = homeIn.filter { it.isBlock }.sortedWith(order)
    for (w in widgets) {
        val sc = w.spanCols.coerceIn(1, m.columns)
        val sr = w.spanRows.coerceIn(1, m.rowsOf(w.page))
        val col = w.col.coerceIn(0, m.columns - sc)
        val row = w.row.coerceIn(0, m.rowsOf(w.page) - sr)
        if (isRectFree(out, w.page, row, col, sr, sc)) {
            out.add(w.copy(row = row, col = col, spanRows = sr, spanCols = sc))
        } else {
            val pos = findFreeRect(out, m, w.page, sr, sc)
            out.add(w.copy(page = pos.first, row = pos.second, col = pos.third, spanRows = sr, spanCols = sc))
        }
    }

    // 2) Apps y carpetas
    val others = homeIn.filter { !it.isBlock }.sortedWith(order)
    for (item in others) {
        val fits = inBounds(item.page, item.row, item.col, 1, 1) &&
            isRectFree(out, item.page, item.row, item.col, 1, 1)
        if (fits) {
            out.add(item.copy(spanRows = 1, spanCols = 1))
        } else {
            val pos = findFreeRect(out, m, item.page, 1, 1)
            out.add(item.copy(page = pos.first, row = pos.second, col = pos.third, spanRows = 1, spanCols = 1))
        }
    }
    return LayoutSnapshot(out, dockOut)
}

/** Guardado del layout como JSON (dentro de SharedPreferences y en la copia de seguridad). */
object LayoutJson {

    fun write(items: List<HomeItem>): String {
        val arr = JSONArray()
        for (item in items) arr.put(toJson(item))
        return JSONObject().put("version", 2).put("items", arr).toString()
    }

    fun read(text: String): List<HomeItem>? = try {
        val arr = JSONObject(text).getJSONArray("items")
        val out = ArrayList<HomeItem>()
        for (i in 0 until arr.length()) out.add(fromJson(arr.getJSONObject(i)))
        out
    } catch (e: Exception) {
        null
    }

    private fun toJson(item: HomeItem): JSONObject {
        val o = JSONObject()
        o.put("id", item.id)
        o.put("type", item.type.name)
        o.put("page", item.page)
        o.put("row", item.row)
        o.put("col", item.col)
        o.put("spanRows", item.spanRows)
        o.put("spanCols", item.spanCols)
        if (item.appKey != null) o.put("appKey", item.appKey)
        if (item.type == ItemType.FOLDER) {
            o.put("title", item.title)
            o.put("children", JSONArray(item.children))
        }
        if (item.type == ItemType.WIDGET) o.put("widgetId", item.widgetId)
        return o
    }

    private fun fromJson(o: JSONObject): HomeItem {
        val kids = ArrayList<String>()
        val arr = o.optJSONArray("children")
        if (arr != null) {
            for (i in 0 until arr.length()) kids.add(arr.getString(i))
        }
        return HomeItem(
            id = o.getString("id"),
            type = ItemType.valueOf(o.getString("type")),
            page = o.getInt("page"),
            row = o.getInt("row"),
            col = o.getInt("col"),
            spanRows = o.optInt("spanRows", 1),
            spanCols = o.optInt("spanCols", 1),
            appKey = if (o.has("appKey")) o.getString("appKey") else null,
            title = o.optString("title", ""),
            children = kids,
            widgetId = o.optInt("widgetId", -1),
        )
    }
}
