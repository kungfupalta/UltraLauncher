package com.marcos.ultralauncher

import androidx.compose.runtime.Immutable
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

/** Página especial: el dock (sus huecos van de 0 a [DOCK_SLOTS] - 1 en la columna). */
const val DOCK_PAGE = -1
const val DOCK_SLOTS = 4

/** Máximo de apps dentro de una carpeta. */
const val FOLDER_MAX = 12

/** CLOCK = reloj grande, PERSON = hora de Marcos/Arianna: bloques propios que se mueven y redimensionan como un widget. */
enum class ItemType { APP, FOLDER, WIDGET, CLOCK, PERSON }

/** Filas que ocupa por defecto el reloj en el inicio. */
const val CLOCK_ROWS = 2

/**
 * Un elemento colocado en una celda de la cuadrícula (página, fila, columna).
 * - APP: un icono ([appKey]).
 * - FOLDER: varias apps ([children]) con un nombre ([title]).
 * - WIDGET: un widget de Android ([widgetId]) que ocupa [spanRows] x [spanCols] celdas.
 * Los elementos del dock usan page = [DOCK_PAGE], row = 0 y col = número de hueco.
 */
@Immutable
data class HomeItem(
    val id: String,
    val type: ItemType,
    val page: Int,
    val row: Int,
    val col: Int,
    val spanRows: Int = 1,
    val spanCols: Int = 1,
    val appKey: String? = null,
    val title: String = "",
    val children: List<String> = emptyList(),
    val widgetId: Int = -1,
    // Rectángulo libre del bloque en dp (relativo a la cuadrícula de su página). -1 = por celdas (versiones viejas).
    val fx: Float = -1f,
    val fy: Float = -1f,
    val fw: Float = -1f,
    val fh: Float = -1f,
) {
    val isDock: Boolean get() = page == DOCK_PAGE

    /** Bloque con tamaño y posición libres (pegado a su contenido, no a las celdas). */
    val isFree: Boolean get() = isBlock && fw > 0f && fh > 0f && fx >= 0f && fy >= 0f

    /** Ocupa varias celdas y se mueve/redimensiona (widget de Android, reloj u hora de una persona). */
    val isBlock: Boolean get() = type == ItemType.WIDGET || type == ItemType.CLOCK || type == ItemType.PERSON

    /** ¿Esta celda (r, c) pertenece al elemento? */
    fun covers(r: Int, c: Int): Boolean =
        (r in row until (row + spanRows)) && (c in col until (col + spanCols))
}

/** Medidas de la cuadrícula visible; las informa la pantalla de inicio. */
data class GridMetrics(
    val columns: Int,
    val rowsFirst: Int,
    val rowsOther: Int,
    val cellWDp: Float,
    val cellHDp: Float,
) {
    /** La primera página tiene menos filas porque lleva el reloj arriba. */
    fun rowsOf(page: Int): Int = if (page == 0) rowsFirst else rowsOther
}

/** Tolerancia (dp) para considerar que dos bordes se tocan sin superponerse. */
const val RECT_EPS = 0.6f

/** Tamaño mínimo de un bloque (dp). */
const val MIN_BLOCK_DP = 24f

/** Paso de la cuadrícula fina (dp) y distancia a la que un borde se pega a una línea cercana. */
const val SNAP_DP = 4f
const val MAGNET_DP = 8f

/** Rectángulo en dp dentro de la cuadrícula de una página (origen arriba a la izquierda). */
data class RectDp(val x: Float, val y: Float, val w: Float, val h: Float) {
    val right: Float get() = x + w
    val bottom: Float get() = y + h

    fun overlaps(o: RectDp): Boolean =
        x < o.right - RECT_EPS && o.x < right - RECT_EPS &&
            y < o.bottom - RECT_EPS && o.y < bottom - RECT_EPS
}

/** Celdas que toca un rectángulo. */
data class CellSpan(val row: Int, val col: Int, val sr: Int, val sc: Int)

/** Rectángulo de un bloque: el libre si lo tiene, o el de sus celdas. */
fun blockRect(item: HomeItem, m: GridMetrics): RectDp =
    if (item.isFree) {
        RectDp(item.fx, item.fy, item.fw, item.fh)
    } else {
        RectDp(item.col * m.cellWDp, item.row * m.cellHDp, item.spanCols * m.cellWDp, item.spanRows * m.cellHDp)
    }

/** Celdas que toca [r] en la página [page] (se ignora el borde que solo roza). */
fun coverCells(r: RectDp, m: GridMetrics, page: Int): CellSpan {
    val col = floor((r.x + RECT_EPS) / m.cellWDp).toInt().coerceIn(0, m.columns - 1)
    val row = floor((r.y + RECT_EPS) / m.cellHDp).toInt().coerceIn(0, m.rowsOf(page) - 1)
    val lastCol = (ceil((r.right - RECT_EPS) / m.cellWDp).toInt() - 1).coerceIn(col, m.columns - 1)
    val lastRow = (ceil((r.bottom - RECT_EPS) / m.cellHDp).toInt() - 1).coerceIn(row, m.rowsOf(page) - 1)
    return CellSpan(row, col, lastRow - row + 1, lastCol - col + 1)
}

/** El bloque con ese rectángulo libre; fila/columna/celdas se recalculan para que las apps lo esquiven. */
fun withFreeRect(item: HomeItem, r: RectDp, m: GridMetrics): HomeItem {
    val cs = coverCells(r, m, item.page)
    return item.copy(
        row = cs.row,
        col = cs.col,
        spanRows = cs.sr,
        spanCols = cs.sc,
        fx = r.x,
        fy = r.y,
        fw = r.w,
        fh = r.h,
    )
}

/** Líneas verticales a las que se pega un bloque: bordes de las columnas y de otros bloques. */
fun snapLinesX(items: List<HomeItem>, m: GridMetrics, page: Int, ignoreId: String?): List<Float> {
    val out = ArrayList<Float>()
    for (c in 0..m.columns) out.add(c * m.cellWDp)
    for (o in items) {
        if (o.id == ignoreId || !o.isBlock || o.page != page) continue
        val r = blockRect(o, m)
        out.add(r.x)
        out.add(r.right)
    }
    return out
}

/** Líneas horizontales a las que se pega un bloque: bordes de las filas y de otros bloques. */
fun snapLinesY(items: List<HomeItem>, m: GridMetrics, page: Int, ignoreId: String?): List<Float> {
    val out = ArrayList<Float>()
    for (r in 0..m.rowsOf(page)) out.add(r * m.cellHDp)
    for (o in items) {
        if (o.id == ignoreId || !o.isBlock || o.page != page) continue
        val b = blockRect(o, m)
        out.add(b.y)
        out.add(b.bottom)
    }
    return out
}

/** Línea más cercana dentro del imán, o null. */
private fun nearestLine(v: Float, lines: List<Float>): Float? {
    var best: Float? = null
    var bestD = MAGNET_DP
    for (l in lines) {
        val d = abs(v - l)
        if (d <= bestD) {
            best = l
            bestD = d
        }
    }
    return best
}

private fun roundStep(v: Float): Float = (v / SNAP_DP).roundToInt() * SNAP_DP

/** Un borde suelto (al redimensionar): se pega a una línea cercana o va a la cuadrícula fina. */
fun snapEdge(v: Float, lines: List<Float>): Float = nearestLine(v, lines) ?: roundStep(v)

/** Posición de un bloque que se mueve: pega el borde que tenga una línea cerca; si no, cuadrícula fina. */
fun snapMoveRect(
    items: List<HomeItem>,
    m: GridMetrics,
    page: Int,
    ignoreId: String?,
    x: Float,
    y: Float,
    w: Float,
    h: Float,
): RectDp {
    val totalW = m.columns * m.cellWDp
    val totalH = m.rowsOf(page) * m.cellHDp
    val lx = snapLinesX(items, m, page, ignoreId)
    val ly = snapLinesY(items, m, page, ignoreId)

    val left = nearestLine(x, lx)
    val right = nearestLine(x + w, lx)
    val nx = when {
        left != null && (right == null || abs(left - x) <= abs(right - (x + w))) -> left
        right != null -> right - w
        else -> roundStep(x)
    }
    val top = nearestLine(y, ly)
    val bottom = nearestLine(y + h, ly)
    val ny = when {
        top != null && (bottom == null || abs(top - y) <= abs(bottom - (y + h))) -> top
        bottom != null -> bottom - h
        else -> roundStep(y)
    }
    return RectDp(
        nx.coerceIn(0f, (totalW - w).coerceAtLeast(0f)),
        ny.coerceIn(0f, (totalH - h).coerceAtLeast(0f)),
        w,
        h,
    )
}

class LayoutSnapshot(val home: List<HomeItem>, val dock: List<HomeItem>)

/** ¿El rectángulo está libre en esa página? (se ignora el elemento [ignoreId]). */
fun isRectFree(
    items: List<HomeItem>,
    page: Int,
    row: Int,
    col: Int,
    sr: Int,
    sc: Int,
    ignoreId: String? = null,
): Boolean = items.none { o ->
    o.id != ignoreId &&
        o.page == page &&
        o.row < row + sr && row < o.row + o.spanRows &&
        o.col < col + sc && col < o.col + o.spanCols
}

/** Primer hueco libre (página, fila, columna) empezando en [startPage]; siempre termina. */
fun findFreeRect(
    items: List<HomeItem>,
    m: GridMetrics,
    startPage: Int,
    sr: Int,
    sc: Int,
): Triple<Int, Int, Int> {
    var p = startPage.coerceAtLeast(0)
    while (true) {
        val rows = m.rowsOf(p)
        for (r in 0..(rows - sr)) {
            for (c in 0..(m.columns - sc)) {
                if (isRectFree(items, p, r, c, sr, sc)) return Triple(p, r, c)
            }
        }
        p++
    }
}

/** Elimina páginas intermedias vacías (la página 0 se conserva siempre). */
fun compactPages(items: List<HomeItem>): List<HomeItem> {
    val pages = (items.filter { it.page >= 0 }.map { it.page } + 0).distinct().sorted()
    val map = HashMap<Int, Int>()
    pages.forEachIndexed { index, p -> map[p] = index }
    return items.map { if (it.page >= 0) it.copy(page = map[it.page] ?: it.page) else it }
}

/**
 * Calcula cómo se ve el layout con las medidas actuales: corrige elementos fuera de la
 * cuadrícula o superpuestos SIN tocar lo guardado (así girar la pantalla no desordena nada).
 * Al editar, lo que se ve pasa a ser lo guardado.
 */
fun resolveLayout(items: List<HomeItem>, m: GridMetrics?): LayoutSnapshot {
    // Dock: un elemento por hueco
    val dockOut = ArrayList<HomeItem>()
    val used = HashSet<Int>()
    val overflow = ArrayList<HomeItem>()
    val dockIn = items
        .filter { it.page == DOCK_PAGE && !it.isBlock }
        .sortedBy { it.col }
    for (d in dockIn) {
        val wanted = d.col
        val slot = if (wanted in 0 until DOCK_SLOTS && wanted !in used) {
            wanted
        } else {
            (0 until DOCK_SLOTS).firstOrNull { it !in used }
        }
        if (slot == null) {
            overflow.add(d)
        } else {
            used.add(slot)
            dockOut.add(d.copy(row = 0, col = slot, spanRows = 1, spanCols = 1))
        }
    }

    val homeIn = items.filter { it.page >= 0 } +
        overflow.map { it.copy(page = 0, row = 0, col = 0) }
    if (m == null) return LayoutSnapshot(homeIn, dockOut)

    fun inBounds(page: Int, row: Int, col: Int, sr: Int, sc: Int): Boolean =
        page >= 0 && row >= 0 && col >= 0 && row + sr <= m.rowsOf(page) && col + sc <= m.columns

    val out = ArrayList<HomeItem>()
    val order = compareBy<HomeItem>({ it.page }, { it.row }, { it.col })

    // 1) Bloques primero. Entre bloques se compara en dp (pueden ir pegados dentro de la misma celda).
    val widgets = homeIn.filter { it.isBlock }.sortedWith(order)
    val totalW = m.columns * m.cellWDp
    for (w in widgets) {
        val totalH = m.rowsOf(w.page) * m.cellHDp
        var cand: HomeItem
        if (w.isFree) {
            val rw = w.fw.coerceIn(MIN_BLOCK_DP, totalW)
            val rh = w.fh.coerceIn(MIN_BLOCK_DP, totalH)
            val rx = w.fx.coerceIn(0f, totalW - rw)
            val ry = w.fy.coerceIn(0f, totalH - rh)
            cand = withFreeRect(w, RectDp(rx, ry, rw, rh), m)
        } else {
            val sc = w.spanCols.coerceIn(1, m.columns)
            val sr = w.spanRows.coerceIn(1, m.rowsOf(w.page))
            val col = w.col.coerceIn(0, m.columns - sc)
            val row = w.row.coerceIn(0, m.rowsOf(w.page) - sr)
            cand = w.copy(row = row, col = col, spanRows = sr, spanCols = sc)
        }
        val rect = blockRect(cand, m)
        val clash = out.any { it.isBlock && it.page == cand.page && blockRect(it, m).overlaps(rect) }
        if (clash) {
            val pos = findFreeRect(out, m, cand.page, cand.spanRows, cand.spanCols)
            cand = if (cand.isFree) {
                withFreeRect(
                    cand.copy(page = pos.first),
                    RectDp(pos.third * m.cellWDp, pos.second * m.cellHDp, rect.w, rect.h),
                    m,
                )
            } else {
                cand.copy(page = pos.first, row = pos.second, col = pos.third)
            }
        }
        out.add(cand)
    }

    // 2) Apps y carpetas
    val others = homeIn.filter { !it.isBlock }.sortedWith(order)
    for (item in others) {
        val fits = inBounds(item.page, item.row, item.col, 1, 1) &&
            isRectFree(out, item.page, item.row, item.col, 1, 1)
        if (fits) {
            out.add(item.copy(spanRows = 1, spanCols = 1))
        } else {
            val pos = findFreeRect(out, m, item.page, 1, 1)
            out.add(item.copy(page = pos.first, row = pos.second, col = pos.third, spanRows = 1, spanCols = 1))
        }
    }
    return LayoutSnapshot(out, dockOut)
}

/** Guardado del layout como JSON (dentro de SharedPreferences y en la copia de seguridad). */
object LayoutJson {

    fun write(items: List<HomeItem>): String {
        val arr = JSONArray()
        for (item in items) arr.put(toJson(item))
        return JSONObject().put("version", 2).put("items", arr).toString()
    }

    fun read(text: String): List<HomeItem>? = try {
        val arr = JSONObject(text).getJSONArray("items")
        val out = ArrayList<HomeItem>()
        for (i in 0 until arr.length()) out.add(fromJson(arr.getJSONObject(i)))
        out
    } catch (e: Exception) {
        null
    }

    private fun toJson(item: HomeItem): JSONObject {
        val o = JSONObject()
        o.put("id", item.id)
        o.put("type", item.type.name)
        o.put("page", item.page)
        o.put("row", item.row)
        o.put("col", item.col)
        o.put("spanRows", item.spanRows)
        o.put("spanCols", item.spanCols)
        if (item.appKey != null) o.put("appKey", item.appKey)
        if (item.type == ItemType.FOLDER) {
            o.put("title", item.title)
            o.put("children", JSONArray(item.children))
        }
        if (item.type == ItemType.WIDGET) o.put("widgetId", item.widgetId)
        if (item.isFree) {
            o.put("fx", item.fx.toDouble())
            o.put("fy", item.fy.toDouble())
            o.put("fw", item.fw.toDouble())
            o.put("fh", item.fh.toDouble())
        }
        return o
    }

    private fun fromJson(o: JSONObject): HomeItem {
        val kids = ArrayList<String>()
        val arr = o.optJSONArray("children")
        if (arr != null) {
            for (i in 0 until arr.length()) kids.add(arr.getString(i))
        }
        return HomeItem(
            id = o.getString("id"),
            type = ItemType.valueOf(o.getString("type")),
            page = o.getInt("page"),
            row = o.getInt("row"),
            col = o.getInt("col"),
            spanRows = o.optInt("spanRows", 1),
            spanCols = o.optInt("spanCols", 1),
            appKey = if (o.has("appKey")) o.getString("appKey") else null,
            title = o.optString("title", ""),
            children = kids,
            widgetId = o.optInt("widgetId", -1),
            fx = o.optDouble("fx", -1.0).toFloat(),
            fy = o.optDouble("fy", -1.0).toFloat(),
            fw = o.optDouble("fw", -1.0).toFloat(),
            fh = o.optDouble("fh", -1.0).toFloat(),
        )
    }
}
