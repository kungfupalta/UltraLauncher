package com.marcos.ultralauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.drawable.Drawable
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

/** Un pack de iconos instalado (formato ADW/Nova: appfilter.xml). */
data class IconPackInfo(val packageName: String, val label: String)

/** Lista los packs de iconos instalados. */
fun Context.listIconPacks(): List<IconPackInfo> {
    val actions = listOf(
        "org.adw.launcher.THEMES",
        "com.novalauncher.THEME",
        "com.anddoes.launcher.THEME",
        "com.gau.go.launcherex.theme",
        "com.fede.launcher.THEME_ICONPACK",
    )
    val pm = packageManager
    val out = LinkedHashMap<String, IconPackInfo>()
    for (action in actions) {
        try {
            val list = pm.queryIntentActivities(Intent(action), PackageManager.GET_META_DATA)
            for (ri in list) {
                val pkg = ri.activityInfo.packageName
                if (pkg !in out) out[pkg] = IconPackInfo(pkg, ri.loadLabel(pm).toString())
            }
        } catch (e: Exception) {
        }
    }
    return out.values.sortedBy { it.label.lowercase() }
}

/** Lee el appfilter.xml de un pack y entrega el icono para cada app que trae. */
class IconPack(private val context: Context, val packageName: String) {

    private val map = HashMap<String, String>()
    private var res: Resources? = null

    fun load(): Boolean {
        try {
            val r = context.packageManager.getResourcesForApplication(packageName)
            res = r
            val id = r.getIdentifier("appfilter", "xml", packageName)
            val parser: XmlPullParser = if (id != 0) {
                r.getXml(id)
            } else {
                val p = XmlPullParserFactory.newInstance().newPullParser()
                p.setInput(r.assets.open("appfilter.xml"), null)
                p
            }
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name == "item") {
                    val comp = parser.getAttributeValue(null, "component")
                    val drawable = parser.getAttributeValue(null, "drawable")
                    if (comp != null && drawable != null) {
                        val key = parseComponent(comp)
                        if (key != null) map[key] = drawable
                    }
                }
                event = parser.next()
            }
            return map.isNotEmpty()
        } catch (e: Exception) {
            return false
        }
    }

    /** "ComponentInfo{pkg/act}" -> "pkg/act" (resuelve actividades que empiezan por punto). */
    private fun parseComponent(s: String): String? {
        val start = s.indexOf('{')
        val end = s.indexOf('}')
        if (start < 0 || end < 0 || end <= start) return null
        val inner = s.substring(start + 1, end)
        val slash = inner.indexOf('/')
        if (slash < 0) return null
        val pkg = inner.substring(0, slash)
        var act = inner.substring(slash + 1)
        if (act.startsWith(".")) act = pkg + act
        return "$pkg/$act"
    }

    fun iconFor(appKey: String): Drawable? {
        val name = map[appKey] ?: return null
        val r = res ?: return null
        val id = r.getIdentifier(name, "drawable", packageName)
        if (id == 0) return null
        return try {
            r.getDrawable(id, null)
        } catch (e: Exception) {
            null
        }
    }
}
