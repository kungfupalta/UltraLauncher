package com.marcos.ultralauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable

/**
 * Convierte el icono de una app en un bitmap cuadrado listo para recortarse con forma "squircle".
 * - Iconos adaptativos: se dibujan fondo + primer plano sin la máscara del sistema.
 * - Iconos antiguos: se centran sobre una placa clara (como hace One UI).
 */
fun Drawable.toIconBitmap(sizePx: Int): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val adaptive = this as? AdaptiveIconDrawable
    if (adaptive != null) {
        // La capa mide 108dp y la zona visible son los 72dp centrales.
        val offset = (sizePx * 18f / 72f).toInt()
        val left = -offset
        val top = -offset
        val right = sizePx + offset
        val bottom = sizePx + offset
        adaptive.background?.let {
            it.setBounds(left, top, right, bottom)
            it.draw(canvas)
        }
        adaptive.foreground?.let {
            it.setBounds(left, top, right, bottom)
            it.draw(canvas)
        }
    } else {
        canvas.drawColor(0xFFF1F1F1.toInt())
        val inset = (sizePx * 0.17f).toInt()
        setBounds(inset, inset, sizePx - inset, sizePx - inset)
        draw(canvas)
    }
    return bmp
}

/** Convierte un drawable (vista previa de widget) en un bitmap de como mucho [maxPx] de lado. */
fun Drawable.toPreviewBitmap(maxPx: Int): Bitmap {
    val iw = if (intrinsicWidth > 0) intrinsicWidth else maxPx
    val ih = if (intrinsicHeight > 0) intrinsicHeight else maxPx
    val scale = minOf(maxPx.toFloat() / iw, maxPx.toFloat() / ih, 1f)
    val w = (iw * scale).toInt().coerceAtLeast(1)
    val h = (ih * scale).toInt().coerceAtLeast(1)
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    setBounds(0, 0, w, h)
    draw(Canvas(bmp))
    return bmp
}

/**
 * Icono "temático": placa oscura con el dibujo monocromático de la app en color claro.
 * Si la app no trae capa monocromática (o Android < 13) se usa su icono normal en escala de grises.
 */
fun Drawable.toThemedBitmap(sizePx: Int): Bitmap {
    val adaptive = this as? AdaptiveIconDrawable
    if (adaptive != null && Build.VERSION.SDK_INT >= 33) {
        val mono = adaptive.monochrome
        if (mono != null) {
            val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.drawColor(0xFF2B3A55.toInt())
            val offset = (sizePx * 18f / 72f).toInt()
            val layer = mono.mutate()
            layer.setTint(0xFFCFE0FF.toInt())
            layer.setBounds(-offset, -offset, sizePx + offset, sizePx + offset)
            layer.draw(canvas)
            return bmp
        }
    }
    val base = toIconBitmap(sizePx)
    val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    val matrix = ColorMatrix()
    matrix.setSaturation(0f)
    paint.colorFilter = ColorMatrixColorFilter(matrix)
    Canvas(out).drawBitmap(base, 0f, 0f, paint)
    return out
}

/** Dibuja un icono de pack de iconos ocupando todo el cuadrado. */
fun Drawable.toPackBitmap(sizePx: Int): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    setBounds(0, 0, sizePx, sizePx)
    draw(Canvas(bmp))
    return bmp
}

/** Lee una imagen elegida por el usuario y la recorta al centro como un cuadrado de [px]. */
fun decodeSquareBitmap(context: Context, uri: Uri, px: Int): Bitmap? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val minSide = minOf(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (minSide / (sample * 2) >= px) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null
        val side = minOf(raw.width, raw.height)
        val square = Bitmap.createBitmap(raw, (raw.width - side) / 2, (raw.height - side) / 2, side, side)
        Bitmap.createScaledBitmap(square, px, px, true)
    } catch (e: Exception) {
        null
    }
}
