package com.marcos.ultralauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build

/**
 * Convierte el icono de una app en un bitmap cuadrado listo para recortarse con forma "squircle".
 * - Iconos adaptativos: se dibujan fondo + primer plano sin la máscara del sistema.
 * - Iconos antiguos: se centran sobre una placa clara (como hace One UI).
 */
class ThemedColors(val background: Int, val foreground: Int)

fun Drawable.toIconBitmap(sizePx: Int, themed: ThemedColors? = null): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val adaptive = this as? AdaptiveIconDrawable
    if (adaptive != null) {
        // La capa mide 108dp y la zona visible son los 72dp centrales.
        val offset = (sizePx * 18f / 72f).toInt()
        val left = -offset
        val top = -offset
        val right = sizePx + offset
        val bottom = sizePx + offset
        val mono: Drawable? = if (themed != null && Build.VERSION.SDK_INT >= 33) adaptive.monochrome else null
        if (themed != null && mono != null) {
            // Icono temático: fondo de color del sistema y silueta monocromática encima.
            canvas.drawColor(themed.background)
            val m = mono.mutate()
            m.setTint(themed.foreground)
            m.setBounds(left, top, right, bottom)
            m.draw(canvas)
        } else {
            adaptive.background?.let {
                it.setBounds(left, top, right, bottom)
                it.draw(canvas)
            }
            adaptive.foreground?.let {
                it.setBounds(left, top, right, bottom)
                it.draw(canvas)
            }
        }
    } else {
        canvas.drawColor(0xFFF1F1F1.toInt())
        val inset = (sizePx * 0.17f).toInt()
        setBounds(inset, inset, sizePx - inset, sizePx - inset)
        draw(canvas)
    }
    return bmp
}

/** Convierte un drawable (vista previa de widget) en un bitmap de como mucho [maxPx] de lado. */
fun Drawable.toPreviewBitmap(maxPx: Int): Bitmap {
    val iw = if (intrinsicWidth > 0) intrinsicWidth else maxPx
    val ih = if (intrinsicHeight > 0) intrinsicHeight else maxPx
    val scale = minOf(maxPx.toFloat() / iw, maxPx.toFloat() / ih, 1f)
    val w = (iw * scale).toInt().coerceAtLeast(1)
    val h = (ih * scale).toInt().coerceAtLeast(1)
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    setBounds(0, 0, w, h)
    draw(Canvas(bmp))
    return bmp
}
