package com.marcos.ultralauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

fun Context.launchApp(app: AppInfo) {
    try {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        startActivity(intent)
    } catch (e: Exception) {
        // La app puede haberse desinstalado o estar deshabilitada.
    }
}

fun Context.openAppInfo(packageName: String) {
    try {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    } catch (e: Exception) {
    }
}

fun Context.uninstallApp(packageName: String) {
    try {
        val intent = Intent(
            Intent.ACTION_DELETE,
            Uri.fromParts("package", packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    } catch (e: Exception) {
    }
}

fun Context.openWallpaperPicker() {
    try {
        val chooser = Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Fondos de pantalla")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(chooser)
    } catch (e: Exception) {
    }
}

fun Context.openSystemSettings() {
    try {
        startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}

/** Desliza hacia abajo en el inicio para abrir el panel de notificaciones (como One UI). */
fun Context.expandNotifications() {
    try {
        val service = getSystemService("statusbar")
        val clazz = Class.forName("android.app.StatusBarManager")
        clazz.getMethod("expandNotificationsPanel").invoke(service)
    } catch (e: Exception) {
    }
}
