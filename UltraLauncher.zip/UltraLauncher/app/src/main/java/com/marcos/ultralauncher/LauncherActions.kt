package com.marcos.ultralauncher

import android.app.SearchManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

fun Context.launchApp(app: AppInfo) {
    try {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        startActivity(intent)
    } catch (e: Exception) {
        // La app puede haberse desinstalado o estar deshabilitada.
    }
}

fun Context.openAppInfo(packageName: String) {
    try {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    } catch (e: Exception) {
    }
}

fun Context.uninstallApp(packageName: String) {
    try {
        val intent = Intent(
            Intent.ACTION_DELETE,
            Uri.fromParts("package", packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    } catch (e: Exception) {
    }
}

fun Context.openWallpaperPicker() {
    try {
        val chooser = Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Fondos de pantalla")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(chooser)
    } catch (e: Exception) {
    }
}

fun Context.openSystemSettings() {
    try {
        startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}

/** Desliza hacia abajo en el inicio para abrir el panel de notificaciones (como One UI). */
fun Context.expandNotifications() {
    try {
        val service = getSystemService("statusbar")
        val clazz = Class.forName("android.app.StatusBarManager")
        clazz.getMethod("expandNotificationsPanel").invoke(service)
    } catch (e: Exception) {
    }
}

/** Busca [query] en la web (con el buscador/navegador del sistema). */
fun Context.webSearch(query: String) {
    try {
        val intent = Intent(Intent.ACTION_WEB_SEARCH)
            .putExtra(SearchManager.QUERY, query)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    } catch (e: Exception) {
        try {
            val url = "https://www.google.com/search?q=" + Uri.encode(query)
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) {
        }
    }
}

/** ¿Tiene el launcher acceso a las notificaciones (para las insignias)? */
fun Context.hasNotificationAccess(): Boolean =
    try {
        androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
    } catch (e: Exception) {
        false
    }

/** Abre la pantalla del sistema donde se da acceso a las notificaciones. */
fun Context.openNotificationAccessSettings() {
    try {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}
