package com.marcos.ultralauncher

import android.content.ComponentName
import android.content.Context
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.os.Process
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings

fun Context.launchApp(app: AppInfo, options: Bundle? = null) {
    // Con LauncherApps también se abren las apps de otros perfiles (trabajo, clones).
    try {
        val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        la.startMainActivity(
            ComponentName(app.packageName, app.activityName),
            app.user ?: Process.myUserHandle(),
            null,
            options,
        )
        return
    } catch (e: Exception) {
        // Se prueba con el método clásico.
    }
    try {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        startActivity(intent, options)
    } catch (e: Exception) {
        // La app puede haberse desinstalado o estar deshabilitada.
    }
}

/** Información de la app (también para apps de otros perfiles). */
fun Context.openAppInfo(app: AppInfo) {
    try {
        val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        la.startAppDetailsActivity(
            ComponentName(app.packageName, app.activityName),
            app.user ?: Process.myUserHandle(),
            null,
            null,
        )
    } catch (e: Exception) {
        openAppInfo(app.packageName)
    }
}

fun Context.uninstallApp(app: AppInfo) {
    try {
        val intent = Intent(
            Intent.ACTION_DELETE,
            Uri.fromParts("package", app.packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val u = app.user
        if (u != null) intent.putExtra(Intent.EXTRA_USER, u)
        startActivity(intent)
    } catch (e: Exception) {
    }
}

fun Context.openAppInfo(packageName: String) {
    try {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    } catch (e: Exception) {
    }
}

fun Context.uninstallApp(packageName: String) {
    try {
        val intent = Intent(
            Intent.ACTION_DELETE,
            Uri.fromParts("package", packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    } catch (e: Exception) {
    }
}

fun Context.openWallpaperPicker() {
    try {
        val chooser = Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Fondos de pantalla")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(chooser)
    } catch (e: Exception) {
    }
}

fun Context.openSystemSettings() {
    try {
        startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}

/** Desliza hacia abajo en el inicio para abrir el panel de notificaciones (como One UI). */
fun Context.expandNotifications() {
    try {
        val service = getSystemService("statusbar")
        val clazz = Class.forName("android.app.StatusBarManager")
        clazz.getMethod("expandNotificationsPanel").invoke(service)
    } catch (e: Exception) {
    }
}

/** Pantalla del sistema donde se da (o quita) el acceso a notificaciones. */
fun Context.openNotificationAccessSettings() {
    try {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        openSystemSettings()
    }
}

/** Desliza hacia abajo con dos dedos: ajustes rápidos. Si el sistema no lo permite, abre las notificaciones. */
fun Context.expandQuickSettings() {
    try {
        val service = getSystemService("statusbar")
        val clazz = Class.forName("android.app.StatusBarManager")
        clazz.getMethod("expandSettingsPanel").invoke(service)
    } catch (e: Exception) {
        expandNotifications()
    }
}

/** ¿Es Ultra Launcher el launcher predeterminado? */
fun Context.isDefaultLauncher(): Boolean = try {
    val ri = packageManager.resolveActivity(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
        PackageManager.MATCH_DEFAULT_ONLY,
    )
    ri?.activityInfo?.packageName == packageName
} catch (e: Exception) {
    false
}

/** Intent para pedir ser el launcher predeterminado (RoleManager en Android 10+). */
fun Context.defaultLauncherIntent(): Intent {
    if (Build.VERSION.SDK_INT >= 29) {
        val rm = getSystemService(Context.ROLE_SERVICE) as? RoleManager
        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
            return rm.createRequestRoleIntent(RoleManager.ROLE_HOME)
        }
    }
    return Intent(Settings.ACTION_HOME_SETTINGS)
}

fun Context.openAccessibilitySettings() {
    try {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}
