package com.marcos.ultralauncher

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.Collator
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

@Immutable
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: ImageBitmap,
    /** Nombre original (sin renombrar por el usuario). */
    val originalLabel: String = label,
    val category: AppCategory = AppCategory.OTHER,
    /** Perfil al que pertenece (null = el perfil actual; otro valor = perfil de trabajo, clon, etc.). */
    val user: UserHandle? = null,
    val userSerial: Long = 0L,
) {
    /** Las apps del perfil actual conservan la clave de siempre; las de otros perfiles llevan "@serie". */
    val key: String
        get() = if (user == null) "$packageName/$activityName" else "$packageName/$activityName@$userSerial"
}

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("ultra_launcher", Context.MODE_PRIVATE)
    private val pm: PackageManager = application.packageManager

    /** Host de widgets de Android (lo usan la pantalla de inicio y MainActivity). */
    val widgetHost = UltraWidgetHost(application)

    /** Todas las apps instaladas (cajón de apps), ordenadas alfabéticamente. */
    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set

    /** Qué hora se muestra debajo del reloj: la de Marcos o la de Arianna. */
    var clockPerson by mutableStateOf(ClockPerson.fromId(prefs.getString(KEY_PERSON, null)))
        private set

    /** Ajustes de personalización (tamaño, columnas, forma de iconos...). */
    var settings by mutableStateOf(loadSettings())
        private set

    /** Sube cada vez que se pulsa "Inicio" estando ya en el launcher. */
    var homeSignal by mutableIntStateOf(0)
        private set

    /** Apps ocultas del cajón (claves). */
    var hiddenKeys by mutableStateOf<Set<String>>(prefs.getStringSet(KEY_HIDDEN, emptySet())?.toSet() ?: emptySet())
        private set

    /** Nombres personalizados por app. */
    var customNames by mutableStateOf<Map<String, String>>(readStrMap(KEY_NAMES))
        private set

    /** Apps con icono propio (archivo en filesDir/icons). */
    var customIconKeys by mutableStateOf<Set<String>>(prefs.getStringSet(KEY_ICONS, emptySet())?.toSet() ?: emptySet())
        private set

    /** Veces que se abrió cada app y cuándo fue la última vez (para ordenar el cajón). */
    var usageCount by mutableStateOf<Map<String, Int>>(readLongMap(KEY_USAGE).mapValues { it.value.toInt() })
        private set
    var usageLast by mutableStateOf<Map<String, Long>>(readLongMap(KEY_LAST))
        private set

    /** Orden manual del cajón (claves de apps). */
    var customOrder by mutableStateOf<List<String>>(readOrder())
        private set

    /** Estado de los permisos opcionales (se refresca al volver a la app). */
    var notificationAccess by mutableStateOf(false)
        private set
    var contactsGranted by mutableStateOf(false)
        private set
    var isDefaultLauncher by mutableStateOf(false)
        private set

    /** Falso hasta que se termina (o se omite) la pantalla de bienvenida. */
    var onboardingDone by mutableStateOf(prefs.getBoolean(KEY_ONBOARDED, false))
        private set

    /** Apps del cajón: sin las ocultas y en el orden elegido. */
    val drawerApps: List<AppInfo> by derivedStateOf {
        val visible = apps.filter { it.key !in hiddenKeys }
        when (settings.drawerSort) {
            DrawerSort.ALPHA -> visible
            DrawerSort.MOST_USED -> visible.sortedByDescending { usageCount[it.key] ?: 0 }
            DrawerSort.RECENT -> visible.sortedByDescending { usageLast[it.key] ?: 0L }
            DrawerSort.CUSTOM -> {
                // Orden manual: lo que no está en la lista (apps nuevas) queda al final.
                val pos = HashMap<String, Int>()
                customOrder.forEachIndexed { i, k -> pos[k] = i }
                visible.sortedBy { pos[it.key] ?: Int.MAX_VALUE }
            }
        }
    }

    /** Página visible del inicio (la actualiza HomeScreen). Sirve para colocar lo que se añade. */
    var currentHomePage = 0

    /** True mientras hay una carpeta abierta (los gestos del inicio se ignoran). */
    var folderOpen = false

    /** True mientras hay un dedo sobre un widget: evita que salte el menú de "espacio vacío". */
    var widgetTouchActive = false

    // ---- Layout: lista de elementos con posición (página, fila, columna) ----

    /** Lo guardado tal cual (posiciones canónicas). */
    private var rawItems by mutableStateOf<List<HomeItem>>(emptyList())

    /** Medidas de la cuadrícula visible (las informa HomeScreen). */
    private var metrics by mutableStateOf<GridMetrics?>(null)

    /** Lo que se ve: lo guardado ajustado a las medidas actuales. */
    private val layout by derivedStateOf { resolveLayout(rawItems, metrics) }

    val homeItems: List<HomeItem> get() = layout.home
    val dockItems: List<HomeItem> get() = layout.dock

    /** Claves de apps de la lista plana antigua que aún hay que colocar en la cuadrícula. */
    private var pendingHome: List<String>? = null

    private val launcherApps = application.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
    private val userManager = application.getSystemService(Context.USER_SERVICE) as UserManager

    /** Iconos ya generados (clave de app + estilo + pack). Se vacía por paquete cuando cambia. */
    private val iconCache = ConcurrentHashMap<String, Bitmap>()
    private var lastProfileCount = 0

    private fun evictIcons(pkg: String?) {
        if (pkg == null) return
        if (pkg == settings.iconPack) iconCache.clear()
        val prefix = "$pkg/"
        iconCache.keys.toList().filter { it.startsWith(prefix) }.forEach { iconCache.remove(it) }
    }

    /** Avisos del sistema sobre apps instaladas/quitadas/actualizadas en cualquier perfil. */
    private val launcherCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
            evictIcons(packageName)
            reloadApps()
        }

        override fun onPackageAdded(packageName: String?, user: UserHandle?) {
            evictIcons(packageName)
            reloadApps()
        }

        override fun onPackageChanged(packageName: String?, user: UserHandle?) {
            evictIcons(packageName)
            reloadApps()
        }

        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) {
            packageNames?.forEach { evictIcons(it) }
            reloadApps()
        }

        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) {
            packageNames?.forEach { evictIcons(it) }
            reloadApps()
        }
    }

    init {
        val saved = prefs.getString(KEY_LAYOUT, null)?.let { LayoutJson.read(it) }
        if (saved != null) {
            rawItems = saved
        } else if (prefs.contains(KEY_HOME) || prefs.contains(KEY_DOCK)) {
            migrateLegacy()
        }

        launcherApps.registerCallback(launcherCallback, Handler(Looper.getMainLooper()))
        refreshAccess()
        reloadApps()
    }

    override fun onCleared() {
        try {
            launcherApps.unregisterCallback(launcherCallback)
        } catch (e: Exception) {
        }
        widgetHost.stopListening()
        super.onCleared()
    }

    // ---------------------------------------------------------------------------------------
    // Permisos opcionales, uso, ocultar, renombrar, icono propio
    // ---------------------------------------------------------------------------------------

    fun refreshAccess() {
        val app = getApplication<Application>()
        notificationAccess = try {
            NotificationManagerCompat.getEnabledListenerPackages(app).contains(app.packageName)
        } catch (e: Exception) {
            false
        }
        contactsGranted = app.hasContactsPermission()
        isDefaultLauncher = app.isDefaultLauncher()
        // Si apareció o desapareció un perfil (trabajo, clon...), se vuelve a leer la lista de apps.
        val count = try {
            userManager.userProfiles.size
        } catch (e: Exception) {
            0
        }
        if (lastProfileCount != 0 && count != lastProfileCount) reloadApps()
        lastProfileCount = count
    }

    fun finishOnboarding() {
        onboardingDone = true
        prefs.edit().putBoolean(KEY_ONBOARDED, true).apply()
    }

    fun showOnboardingAgain() {
        onboardingDone = false
    }

    // ---------------------------------------------------------------------------------------
    // Copia de seguridad
    // ---------------------------------------------------------------------------------------

    @Suppress("DEPRECATION")
    fun exportBackup(): String {
        val app = getApplication<Application>()
        val version = try {
            app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        return LauncherBackup.exportJson(prefs, version)
    }

    /** Importa una copia. Los widgets no se importan (hay que volver a añadirlos). */
    fun importBackup(text: String): Boolean {
        val ok = try {
            LauncherBackup.importJson(prefs, text)
        } catch (e: Exception) {
            false
        }
        if (!ok) return false
        for (w in rawItems.filter { it.type == ItemType.WIDGET }) widgetHost.deleteId(w.widgetId)
        pendingHome = null
        settings = loadSettings()
        hiddenKeys = prefs.getStringSet(KEY_HIDDEN, emptySet())?.toSet() ?: emptySet()
        customNames = readStrMap(KEY_NAMES)
        customIconKeys = prefs.getStringSet(KEY_ICONS, emptySet())?.toSet() ?: emptySet()
        usageCount = readLongMap(KEY_USAGE).mapValues { it.value.toInt() }
        usageLast = readLongMap(KEY_LAST)
        customOrder = readOrder()
        clockPerson = ClockPerson.fromId(prefs.getString(KEY_PERSON, null))
        val saved = prefs.getString(KEY_LAYOUT, null)?.let { LayoutJson.read(it) }
        if (saved != null) {
            commitRaw(saved.filter { it.type != ItemType.WIDGET })
        } else if (prefs.contains(KEY_HOME) || prefs.contains(KEY_DOCK)) {
            migrateLegacy()
            tryApplyPending()
        }
        reloadApps()
        return true
    }

    fun resetSettings() {
        updateSettings(UiSettings())
    }

    private fun readStrMap(key: String): Map<String, String> = try {
        val o = JSONObject(prefs.getString(key, "{}") ?: "{}")
        val m = HashMap<String, String>()
        for (k in o.keys()) m[k] = o.getString(k)
        m
    } catch (e: Exception) {
        emptyMap()
    }

    private fun readLongMap(key: String): Map<String, Long> = try {
        val o = JSONObject(prefs.getString(key, "{}") ?: "{}")
        val m = HashMap<String, Long>()
        for (k in o.keys()) m[k] = o.getLong(k)
        m
    } catch (e: Exception) {
        emptyMap()
    }

    /** Abre la app y apunta el uso (para "más usadas" y "recientes"). */
    fun openApp(app: AppInfo, options: Bundle? = null) {
        getApplication<Application>().launchApp(app, options)
        val c = HashMap(usageCount)
        c[app.key] = (c[app.key] ?: 0) + 1
        val l = HashMap(usageLast)
        l[app.key] = System.currentTimeMillis()
        usageCount = c
        usageLast = l
        prefs.edit()
            .putString(KEY_USAGE, JSONObject(c).toString())
            .putString(KEY_LAST, JSONObject(l).toString())
            .apply()
    }

    private fun readOrder(): List<String> = try {
        val a = org.json.JSONArray(prefs.getString(KEY_ORDER, "[]") ?: "[]")
        val out = ArrayList<String>()
        for (i in 0 until a.length()) out.add(a.getString(i))
        out
    } catch (e: Exception) {
        emptyList()
    }

    private fun saveOrder() {
        prefs.edit().putString(KEY_ORDER, org.json.JSONArray(customOrder).toString()).apply()
    }

    /** Pasa a orden manual guardando el orden que se ve ahora (así no cambia nada de golpe). */
    fun enableManualOrder() {
        if (settings.drawerSort == DrawerSort.CUSTOM) return
        val keys = drawerApps.map { it.key }
        customOrder = keys + customOrder.filter { it !in keys }
        saveOrder()
        updateSettings(settings.copy(drawerSort = DrawerSort.CUSTOM))
        toast("Orden manual activado")
    }

    /** Mueve una app del cajón a la posición de otra (arrastrar y soltar). */
    fun reorderDrawer(fromKey: String, toKey: String) {
        if (fromKey == toKey || settings.drawerSort != DrawerSort.CUSTOM) return
        val keys = drawerApps.map { it.key }.toMutableList()
        val from = keys.indexOf(fromKey)
        val to = keys.indexOf(toKey)
        if (from < 0 || to < 0) return
        val moving = keys.removeAt(from)
        keys.add(to, moving)
        customOrder = keys + customOrder.filter { it !in keys }
        saveOrder()
    }

    fun resetManualOrder() {
        customOrder = emptyList()
        saveOrder()
        toast("Orden manual restablecido (A–Z)")
    }

    fun hideApp(app: AppInfo) {
        hiddenKeys = hiddenKeys + app.key
        prefs.edit().putStringSet(KEY_HIDDEN, hiddenKeys.toSet()).apply()
        toast("Oculta: ${app.label}")
    }

    fun unhideApp(key: String) {
        hiddenKeys = hiddenKeys - key
        prefs.edit().putStringSet(KEY_HIDDEN, hiddenKeys.toSet()).apply()
    }

    /** Cambia el nombre mostrado (vacío o igual al original = restablecer). */
    fun setAppName(app: AppInfo, name: String) {
        val n = name.trim()
        val m = HashMap(customNames)
        if (n.isEmpty() || n == app.originalLabel) m.remove(app.key) else m[app.key] = n
        customNames = m
        prefs.edit().putString(KEY_NAMES, JSONObject(m as Map<*, *>).toString()).apply()
        val collator = Collator.getInstance(Locale.getDefault())
        apps = apps
            .map { if (it.key == app.key) it.copy(label = m[it.key] ?: it.originalLabel) else it }
            .sortedWith { a, b -> collator.compare(a.label, b.label) }
    }

    private fun iconFile(key: String): File {
        val dir = File(getApplication<Application>().filesDir, "icons")
        return File(dir, key.replace(Regex("[^A-Za-z0-9]"), "_") + ".png")
    }

    private fun loadCustomIcon(key: String): Bitmap? {
        val f = iconFile(key)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    private fun iconPx(): Int =
        (getApplication<Application>().resources.displayMetrics.density * 64f).toInt().coerceAtLeast(96)

    /** Usa una imagen de la galería como icono de esta app. */
    fun setCustomIcon(app: AppInfo, uri: Uri) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val px = iconPx()
            val bmp = withContext(Dispatchers.IO) {
                val b = decodeSquareBitmap(ctx, uri, px)
                if (b != null) {
                    val f = iconFile(app.key)
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
                b
            }
            if (bmp == null) {
                toast("No se pudo leer la imagen")
                return@launch
            }
            customIconKeys = customIconKeys + app.key
            prefs.edit().putStringSet(KEY_ICONS, customIconKeys.toSet()).apply()
            apps = apps.map { if (it.key == app.key) it.copy(icon = bmp.asImageBitmap()) else it }
        }
    }

    fun resetCustomIcon(app: AppInfo) {
        try {
            iconFile(app.key).delete()
        } catch (e: Exception) {
        }
        customIconKeys = customIconKeys - app.key
        prefs.edit().putStringSet(KEY_ICONS, customIconKeys.toSet()).apply()
        reloadApps()
    }

    fun requestHome() {
        homeSignal++
    }

    fun selectPerson(person: ClockPerson) {
        clockPerson = person
        prefs.edit().putString(KEY_PERSON, person.id).apply()
    }

    // ---------------------------------------------------------------------------------------
    // Migración y guardado
    // ---------------------------------------------------------------------------------------

    /**
     * Versiones <= 1.1 guardaban dos listas planas (inicio y dock). El dock se convierte ya;
     * el inicio se reparte en la cuadrícula cuando se conocen sus medidas (igual que antes se
     * paginaba, así se ve idéntico). Las claves antiguas NO se borran: quedan como respaldo.
     */
    private fun migrateLegacy() {
        val dockKeys = readList(KEY_DOCK).take(DOCK_SLOTS)
        rawItems = dockKeys.mapIndexed { i, k ->
            HomeItem(newId(), ItemType.APP, DOCK_PAGE, 0, i, appKey = k)
        }
        pendingHome = readList(KEY_HOME)
    }

    fun onGridMetrics(m: GridMetrics) {
        if (metrics != m) metrics = m
        tryApplyPending()
    }

    /** Coloca la lista plana pendiente cuando ya hay medidas y apps cargadas. */
    private fun tryApplyPending() {
        val keys = pendingHome ?: return
        val m = metrics ?: return
        if (apps.isEmpty()) return
        pendingHome = null

        val present = apps.map { it.key }.toHashSet()
        val visible = keys.filter { it in present }.distinct()
        val items = ArrayList<HomeItem>()
        var page = 0
        var idx = 0
        var cap = (m.columns * m.rowsFirst).coerceAtLeast(1)
        val capOther = (m.columns * m.rowsOther).coerceAtLeast(1)
        for (k in visible) {
            if (idx >= cap) {
                page++
                idx = 0
                cap = capOther
            }
            items.add(HomeItem(newId(), ItemType.APP, page, idx / m.columns, idx % m.columns, appKey = k))
            idx++
        }
        commitRaw(rawItems + items)
        prefs.edit().putBoolean(KEY_SEEDED, true).apply()
    }

    private fun commitRaw(list: List<HomeItem>) {
        rawItems = compactPages(list)
        prefs.edit().putString(KEY_LAYOUT, LayoutJson.write(rawItems)).apply()
    }

    /** Punto único de edición: parte de lo que se ve, aplica el cambio y lo guarda. */
    private fun edit(block: (MutableList<HomeItem>) -> Unit) {
        val list = ArrayList<HomeItem>(layout.home.size + layout.dock.size + 1)
        list.addAll(layout.home)
        list.addAll(layout.dock)
        block(list)
        commitRaw(list)
    }

    private fun newId(): String = UUID.randomUUID().toString().substring(0, 8)

    private fun readList(key: String): List<String> =
        (prefs.getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }

    /** Quita del layout lo que ya no está instalado (y las carpetas que quedan vacías). */
    @Suppress("DEPRECATION")
    private fun pruneMissing() {
        if (apps.isEmpty()) return
        val present = apps.map { it.key }.toHashSet()
        val cache = HashMap<String, Boolean>()
        val serials: Set<Long> = try {
            userManager.userProfiles.map { userManager.getSerialNumberForUser(it) }.toSet()
        } catch (e: Exception) {
            emptySet()
        }
        fun alive(key: String): Boolean {
            if (key in present) return true
            val at = key.lastIndexOf('@')
            if (at >= 0) {
                // App de otro perfil: solo se descarta si ese perfil ya no existe
                // (un perfil de trabajo pausado puede tener la lista vacía temporalmente).
                val serial = key.substring(at + 1).toLongOrNull()
                return serial == null || serial in serials
            }
            val pkg = key.substringBefore('/')
            return cache.getOrPut(pkg) {
                try {
                    pm.getApplicationInfo(pkg, 0)
                    true
                } catch (e: Exception) {
                    false
                }
            }
        }

        var changed = false
        val out = ArrayList<HomeItem>()
        for (item in rawItems) {
            when (item.type) {
                ItemType.APP -> {
                    if (alive(item.appKey ?: "")) {
                        out.add(item)
                    } else {
                        changed = true
                    }
                }
                ItemType.FOLDER -> {
                    val kids = item.children.filter { alive(it) }
                    if (kids.size != item.children.size) changed = true
                    if (kids.size == 1) {
                        out.add(HomeItem(newId(), ItemType.APP, item.page, item.row, item.col, appKey = kids[0]))
                    } else if (kids.size > 1) {
                        out.add(item.copy(children = kids))
                    }
                }
                ItemType.WIDGET -> out.add(item)
            }
        }
        if (changed) commitRaw(out)
    }

    // ---------------------------------------------------------------------------------------
    // Añadir / quitar desde el cajón y los menús
    // ---------------------------------------------------------------------------------------

    private fun guardLocked(): Boolean {
        if (settings.layoutLocked) {
            toast("El layout está bloqueado")
            return true
        }
        return false
    }

    fun addToHome(app: AppInfo) {
        if (guardLocked()) return
        val exists = layout.home.any {
            (it.type == ItemType.APP && it.appKey == app.key) ||
                (it.type == ItemType.FOLDER && app.key in it.children)
        }
        if (exists) {
            toast("Ya está en inicio")
            return
        }
        edit { list ->
            val m = metrics
            val pos = if (m != null) findFreeRect(list, m, currentHomePage, 1, 1) else Triple(0, 0, 0)
            list.add(HomeItem(newId(), ItemType.APP, pos.first, pos.second, pos.third, appKey = app.key))
        }
        toast("Añadida a inicio")
    }

    fun addToDock(app: AppInfo) {
        if (guardLocked()) return
        if (layout.dock.any { it.type == ItemType.APP && it.appKey == app.key }) {
            toast("Ya está en el dock")
            return
        }
        val free = (0 until DOCK_SLOTS).firstOrNull { s -> layout.dock.none { it.col == s } }
        if (free == null) {
            toast("El dock está lleno (máx. $DOCK_SLOTS)")
            return
        }
        edit { list ->
            list.add(HomeItem(newId(), ItemType.APP, DOCK_PAGE, 0, free, appKey = app.key))
        }
        toast("Añadida al dock")
    }

    /** Quita un elemento (app, carpeta o widget) del inicio o del dock. */
    fun removeItem(id: String) {
        if (guardLocked()) return
        val target = (layout.home + layout.dock).firstOrNull { it.id == id } ?: return
        if (target.type == ItemType.WIDGET) widgetHost.deleteId(target.widgetId)
        edit { list -> list.removeAll { it.id == id } }
    }

    // ---------------------------------------------------------------------------------------
    // Mover (arrastrar y soltar), carpetas
    // ---------------------------------------------------------------------------------------

    /**
     * Suelta un elemento 1x1 en una celda.
     * - Celda libre: se mueve.
     * - App sobre carpeta: se añade a la carpeta.
     * - App sobre app: carpeta nueva si se mantuvo encima ([merge]); si no, se intercambian.
     */
    fun moveItem(id: String, toDock: Boolean, page: Int, row: Int, col: Int, merge: Boolean) {
        if (guardLocked()) return
        edit { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@edit
            val moving = list[idx]
            if (moving.type == ItemType.WIDGET) return@edit
            val tPage = if (toDock) DOCK_PAGE else page
            val tRow = if (toDock) 0 else row
            val occIdx = list.indexOfFirst { it.id != id && it.page == tPage && it.covers(tRow, col) }
            if (occIdx < 0) {
                list[idx] = moving.copy(page = tPage, row = tRow, col = col)
                return@edit
            }
            val occ = list[occIdx]
            val movingKey = moving.appKey
            val occKey = occ.appKey
            if (occ.type == ItemType.WIDGET) {
                toast("Ahí hay un widget")
            } else if (moving.type == ItemType.APP && movingKey != null && occ.type == ItemType.FOLDER) {
                if (occ.children.size >= FOLDER_MAX) {
                    toast("La carpeta está llena")
                } else {
                    list[occIdx] = occ.copy(children = occ.children + movingKey)
                    list.removeAt(idx)
                }
            } else if (merge && moving.type == ItemType.APP && movingKey != null &&
                occ.type == ItemType.APP && occKey != null
            ) {
                val folder = HomeItem(
                    id = newId(),
                    type = ItemType.FOLDER,
                    page = occ.page,
                    row = occ.row,
                    col = occ.col,
                    title = "Carpeta",
                    children = listOf(occKey, movingKey),
                )
                list.removeAll { it.id == id || it.id == occ.id }
                list.add(folder)
            } else {
                // Intercambio de posiciones
                list[idx] = moving.copy(page = occ.page, row = occ.row, col = occ.col)
                list[occIdx] = occ.copy(page = moving.page, row = moving.row, col = moving.col)
            }
        }
    }

    fun renameFolder(id: String, title: String) {
        commitRaw((layout.home + layout.dock).map { if (it.id == id) it.copy(title = title) else it })
    }

    /** Aplica la nueva lista de apps de una carpeta: 0 la borra, 1 la convierte en app. */
    private fun applyFolderChildren(list: MutableList<HomeItem>, folder: HomeItem, kids: List<String>) {
        val idx = list.indexOfFirst { it.id == folder.id }
        if (idx < 0) return
        if (kids.isEmpty()) {
            list.removeAt(idx)
        } else if (kids.size == 1) {
            list[idx] = HomeItem(newId(), ItemType.APP, folder.page, folder.row, folder.col, appKey = kids[0])
        } else {
            list[idx] = folder.copy(children = kids)
        }
    }

    /** Saca una app de la carpeta y la deja en el primer hueco libre del inicio. */
    fun takeOutOfFolder(folderId: String, appKey: String) {
        if (guardLocked()) return
        edit { list ->
            val folder = list.firstOrNull { it.id == folderId } ?: return@edit
            val m = metrics
            val startPage = if (folder.isDock) currentHomePage else folder.page
            val pos = if (m != null) findFreeRect(list, m, startPage, 1, 1) else Triple(startPage.coerceAtLeast(0), 0, 0)
            list.add(HomeItem(newId(), ItemType.APP, pos.first, pos.second, pos.third, appKey = appKey))
            applyFolderChildren(list, folder, folder.children.filter { it != appKey })
        }
    }

    /** Deshace la carpeta: sus apps quedan sueltas (la primera ocupa el sitio de la carpeta). */
    fun dissolveFolder(id: String) {
        if (guardLocked()) return
        edit { list ->
            val folder = list.firstOrNull { it.id == id } ?: return@edit
            list.removeAll { it.id == id }
            val m = metrics
            folder.children.forEachIndexed { i, key ->
                val pos = if (i == 0) {
                    Triple(folder.page, folder.row, folder.col)
                } else if (m != null) {
                    findFreeRect(list, m, if (folder.isDock) currentHomePage else folder.page, 1, 1)
                } else {
                    Triple(0, 0, 0)
                }
                list.add(HomeItem(newId(), ItemType.APP, pos.first, pos.second, pos.third, appKey = key))
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Widgets
    // ---------------------------------------------------------------------------------------

    private fun density(): Float = getApplication<Application>().resources.displayMetrics.density

    /** Coloca un widget ya enlazado en el primer hueco libre. Si falla, libera su id. */
    fun addWidget(widgetId: Int): Boolean {
        val info = widgetHost.infoFor(widgetId)
        val m = metrics
        if (info == null || m == null) {
            widgetHost.deleteId(widgetId)
            toast("No se pudo añadir el widget")
            return false
        }
        val spans = widgetSpansFor(info, m, density())
        edit { list ->
            val pos = findFreeRect(list, m, currentHomePage, spans.second, spans.first)
            list.add(
                HomeItem(
                    id = newId(),
                    type = ItemType.WIDGET,
                    page = pos.first,
                    row = pos.second,
                    col = pos.third,
                    spanRows = spans.second,
                    spanCols = spans.first,
                    widgetId = widgetId,
                ),
            )
        }
        return true
    }

    fun canPlaceWidget(page: Int, row: Int, col: Int, sr: Int, sc: Int, ignoreId: String?): Boolean {
        val m = metrics ?: return false
        if (page < 0 || row < 0 || col < 0) return false
        if (row + sr > m.rowsOf(page) || col + sc > m.columns) return false
        return isRectFree(layout.home, page, row, col, sr, sc, ignoreId)
    }

    fun moveWidget(id: String, page: Int, row: Int, col: Int): Boolean {
        if (guardLocked()) return false
        var ok = false
        edit { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@edit
            val w = list[idx]
            if (canPlaceWidget(page, row, col, w.spanRows, w.spanCols, id)) {
                list[idx] = w.copy(page = page, row = row, col = col)
                ok = true
            }
        }
        if (!ok) toast("No hay espacio para el widget ahí")
        return ok
    }

    fun resizeWidget(id: String, cols: Int, rows: Int): Boolean {
        if (guardLocked()) return false
        var ok = false
        edit { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@edit
            val w = list[idx]
            if (canPlaceWidget(w.page, w.row, w.col, rows, cols, id)) {
                list[idx] = w.copy(spanRows = rows, spanCols = cols)
                ok = true
            }
        }
        if (!ok) toast("No hay espacio para ese tamaño")
        return ok
    }

    fun widgetLimits(item: HomeItem): SpanLimits {
        val m = metrics ?: return SpanLimits(item.spanCols, item.spanCols, item.spanRows, item.spanRows)
        return spanLimits(widgetHost.infoFor(item.widgetId), m, density(), item)
    }

    /** Lista de widgets instalados para el selector (se llama fuera del hilo principal). */
    @Suppress("DEPRECATION")
    fun loadWidgetEntries(): List<WidgetEntry> {
        val m = metrics
        val dens = density()
        val collator = Collator.getInstance(Locale.getDefault())
        return widgetHost.providers().mapNotNull { info ->
            try {
                val label = info.loadLabel(pm)?.toString() ?: ""
                val appLabel = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString()
                } catch (e: Exception) {
                    info.provider.packageName
                }
                val spans = if (m != null) widgetSpansFor(info, m, dens) else Pair(1, 1)
                WidgetEntry(info, appLabel, label, spans.first, spans.second)
            } catch (e: Exception) {
                null
            }
        }.sortedWith { a, b ->
            val c = collator.compare(a.appLabel, b.appLabel)
            if (c != 0) c else collator.compare(a.label, b.label)
        }
    }

    // ---------------------------------------------------------------------------------------
    // Ajustes
    // ---------------------------------------------------------------------------------------

    fun setLocked(locked: Boolean) {
        updateSettings(settings.copy(layoutLocked = locked))
    }

    fun updateSettings(new: UiSettings) {
        val old = settings
        settings = new
        prefs.edit()
            .putInt(KEY_COLUMNS, new.columns)
            .putInt(KEY_DRAWER_COLUMNS, new.drawerColumns)
            .putFloat(KEY_ICON_DP, new.iconDp)
            .putBoolean(KEY_LABELS, new.showLabels)
            .putBoolean(KEY_CLOCK, new.showClock)
            .putString(KEY_SHAPE, new.shape.id)
            .putFloat(KEY_DOCK_ALPHA, new.dockAlpha)
            .putBoolean(KEY_LOCKED, new.layoutLocked)
            .putString(KEY_ICON_STYLE, new.iconStyle.id)
            .putString(KEY_ICON_PACK, new.iconPack)
            .putBoolean(KEY_BADGES, new.showBadges)
            .putString(KEY_SORT, new.drawerSort.id)
            .putBoolean(KEY_TABS, new.drawerTabs)
            .putString(KEY_SEARCHBAR, new.searchBar.id)
            .putBoolean(KEY_SEARCH_CONTACTS, new.searchContacts)
            .putString(KEY_THEME_MODE, new.themeMode.id)
            .putBoolean(KEY_DYNAMIC, new.dynamicColors)
            .putFloat(KEY_HOME_DIM, new.homeDim)
            .putFloat(KEY_DRAWER_DIM, new.drawerDim)
            .putFloat(KEY_DRAWER_BLUR, new.drawerBlur)
            .putString(KEY_FONT, new.font.id)
            .putFloat(KEY_TEXT_SCALE, new.textScale)
            .putBoolean(KEY_OPEN_ANIM, new.openAnim)
            .putString(KEY_GESTURES, encodeGestures(new.gestures))
            .putBoolean(KEY_DRAWER_PAGED, new.drawerPaged)
            .apply()
        if (old.iconStyle != new.iconStyle || old.iconPack != new.iconPack) reloadApps()
    }

    private fun loadSettings(): UiSettings = UiSettings(
        columns = prefs.getInt(KEY_COLUMNS, 4).coerceIn(4, 8),
        drawerColumns = prefs.getInt(KEY_DRAWER_COLUMNS, 4).coerceIn(4, 8),
        iconDp = prefs.getFloat(KEY_ICON_DP, 56f).coerceIn(40f, 80f),
        showLabels = prefs.getBoolean(KEY_LABELS, true),
        showClock = prefs.getBoolean(KEY_CLOCK, true),
        shape = IconShapeOption.fromId(prefs.getString(KEY_SHAPE, null)),
        dockAlpha = prefs.getFloat(KEY_DOCK_ALPHA, 0.16f).coerceIn(0f, 0.6f),
        layoutLocked = prefs.getBoolean(KEY_LOCKED, false),
        iconStyle = IconStyle.fromId(prefs.getString(KEY_ICON_STYLE, null)),
        iconPack = prefs.getString(KEY_ICON_PACK, "") ?: "",
        showBadges = prefs.getBoolean(KEY_BADGES, true),
        drawerSort = DrawerSort.fromId(prefs.getString(KEY_SORT, null)),
        drawerTabs = prefs.getBoolean(KEY_TABS, false),
        searchBar = SearchBarPos.fromId(prefs.getString(KEY_SEARCHBAR, null)),
        searchContacts = prefs.getBoolean(KEY_SEARCH_CONTACTS, false),
        themeMode = ThemeMode.fromId(prefs.getString(KEY_THEME_MODE, null)),
        dynamicColors = prefs.getBoolean(KEY_DYNAMIC, false),
        homeDim = prefs.getFloat(KEY_HOME_DIM, 0f).coerceIn(0f, 0.6f),
        drawerDim = prefs.getFloat(KEY_DRAWER_DIM, 0.78f).coerceIn(0.3f, 0.95f),
        drawerBlur = prefs.getFloat(KEY_DRAWER_BLUR, 0f).coerceIn(0f, 1f),
        font = AppFont.fromId(prefs.getString(KEY_FONT, null)),
        textScale = prefs.getFloat(KEY_TEXT_SCALE, 1f).coerceIn(0.8f, 1.4f),
        openAnim = prefs.getBoolean(KEY_OPEN_ANIM, true),
        gestures = decodeGestures(prefs.getString(KEY_GESTURES, null)),
        drawerPaged = prefs.getBoolean(KEY_DRAWER_PAGED, false),
    )

    // ---------------------------------------------------------------------------------------
    // Apps instaladas
    // ---------------------------------------------------------------------------------------

    private var reloadJob: Job? = null

    fun reloadApps() {
        reloadJob?.cancel()
        val style = settings.iconStyle
        val pack = settings.iconPack
        reloadJob = viewModelScope.launch {
            val list = withContext(Dispatchers.Default) { queryApps(style, pack) }
            apps = list
            if (list.isEmpty()) return@launch
            if (!prefs.getBoolean(KEY_SEEDED, false) &&
                prefs.getString(KEY_LAYOUT, null) == null &&
                pendingHome == null
            ) {
                seedDefaults(list)
            }
            tryApplyPending()
            pruneMissing()
        }
    }

    /** Lee las apps de todos los perfiles y arma los iconos en paralelo (con caché). */
    private suspend fun queryApps(style: IconStyle, packPkg: String): List<AppInfo> = coroutineScope {
        val ctx = getApplication<Application>()
        val me = Process.myUserHandle()
        val px = iconPx()
        val collator = Collator.getInstance(Locale.getDefault())
        val pack = if (packPkg.isNotEmpty()) IconPack(ctx, packPkg).takeIf { it.load() } else null
        val names = customNames
        val iconKeys = customIconKeys

        val entries = ArrayList<Pair<LauncherActivityInfo, UserHandle?>>()
        for (u in userManager.userProfiles) {
            val other = u != me
            val list: List<LauncherActivityInfo>? = try {
                launcherApps.getActivityList(null, u)
            } catch (e: Exception) {
                null
            }
            if (list == null) continue
            for (ai in list) {
                if (ai.componentName.packageName != ctx.packageName) {
                    entries.add(Pair(ai, if (other) u else null))
                }
            }
        }

        val built = entries
            .map { entry ->
                async(Dispatchers.Default) { buildApp(entry.first, entry.second, style, packPkg, pack, px, names, iconKeys) }
            }
            .awaitAll()
            .filterNotNull()
        built.sortedWith { a, b -> collator.compare(a.label, b.label) }
    }

    private fun buildApp(
        ai: LauncherActivityInfo,
        user: UserHandle?,
        style: IconStyle,
        packPkg: String,
        pack: IconPack?,
        px: Int,
        names: Map<String, String>,
        iconKeys: Set<String>,
    ): AppInfo? {
        return try {
            val cn = ai.componentName
            val serial = if (user != null) userManager.getSerialNumberForUser(user) else 0L
            val key = if (user == null) {
                cn.packageName + "/" + cn.className
            } else {
                cn.packageName + "/" + cn.className + "@" + serial
            }
            val original = ai.label.toString()
            val custom = if (key in iconKeys) loadCustomIcon(key) else null
            val cacheKey = key + "|" + style.id + "|" + packPkg
            val bmp: Bitmap = custom ?: iconCache[cacheKey] ?: run {
                val b: Bitmap = if (user != null) {
                    // Apps de trabajo: icono con la insignia del maletín.
                    ai.getBadgedIcon(0).toPackBitmap(px)
                } else {
                    val fromPack = pack?.iconFor(key)?.toPackBitmap(px)
                    if (fromPack != null) {
                        fromPack
                    } else {
                        val d = ai.getIcon(0)
                        if (style == IconStyle.THEMED) d.toThemedBitmap(px) else d.toIconBitmap(px)
                    }
                }
                iconCache[cacheKey] = b
                b
            }
            AppInfo(
                label = names[key] ?: original,
                packageName = cn.packageName,
                activityName = cn.className,
                icon = bmp.asImageBitmap(),
                originalLabel = original,
                category = if (user != null) AppCategory.WORK else AppCategory.of(ai.applicationInfo),
                user = user,
                userSerial = serial,
            )
        } catch (e: Exception) {
            null
        }
    }

    /** Primera vez: prepara el dock y el inicio con las apps típicas de un teléfono. */
    private fun seedDefaults(list: List<AppInfo>) {
        val byPackage = list.filter { it.user == null }.groupBy { it.packageName }

        fun firstFor(intent: Intent): AppInfo? {
            val packages = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
                .map { it.activityInfo.packageName }
            for (p in packages) {
                val found = byPackage[p]?.firstOrNull()
                if (found != null) return found
            }
            return null
        }

        val dock = listOfNotNull(
            firstFor(Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))),
            firstFor(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            firstFor(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com"))),
            firstFor(Intent(MediaStore.ACTION_IMAGE_CAPTURE)),
        ).distinctBy { it.key }

        val galleryIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse("content://media/external/images/media/1"), "image/*")
        }
        val fromIntents = listOfNotNull(
            firstFor(galleryIntent),
            firstFor(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)),
            firstFor(Intent(AlarmClock.ACTION_SHOW_ALARMS)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MAPS)),
            firstFor(Intent(Settings.ACTION_SETTINGS)),
        )
        val fromPackages = listOf(
            "com.android.vending",
            "com.google.android.youtube",
            "com.google.android.apps.photos",
            "com.google.android.gm",
            "com.whatsapp",
            "com.instagram.android",
            "com.spotify.music",
        ).mapNotNull { byPackage[it]?.firstOrNull() }

        val dockKeysSet = dock.map { it.key }.toSet()
        val home = (fromIntents + fromPackages)
            .distinctBy { it.key }
            .filter { it.key !in dockKeysSet }

        rawItems = dock.take(DOCK_SLOTS).mapIndexed { i, a ->
            HomeItem(newId(), ItemType.APP, DOCK_PAGE, 0, i, appKey = a.key)
        }
        pendingHome = home.map { it.key }
    }

    private fun toast(text: String) {
        Toast.makeText(getApplication<Application>(), text, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val KEY_HOME = "home_keys"
        const val KEY_DOCK = "dock_keys"
        const val KEY_LAYOUT = "layout_v2"
        const val KEY_PERSON = "clock_person"
        const val KEY_SEEDED = "seeded"
        const val KEY_COLUMNS = "ui_columns"
        const val KEY_DRAWER_COLUMNS = "ui_drawer_columns"
        const val KEY_ICON_DP = "ui_icon_dp"
        const val KEY_LABELS = "ui_labels"
        const val KEY_CLOCK = "ui_clock"
        const val KEY_SHAPE = "ui_shape"
        const val KEY_DOCK_ALPHA = "ui_dock_alpha"
        const val KEY_LOCKED = "ui_locked"
        const val KEY_ICON_STYLE = "ui_icon_style"
        const val KEY_ICON_PACK = "ui_icon_pack"
        const val KEY_BADGES = "ui_badges"
        const val KEY_SORT = "ui_drawer_sort"
        const val KEY_TABS = "ui_drawer_tabs"
        const val KEY_SEARCHBAR = "ui_search_bar"
        const val KEY_SEARCH_CONTACTS = "ui_search_contacts"
        const val KEY_THEME_MODE = "ui_theme_mode"
        const val KEY_DYNAMIC = "ui_dynamic"
        const val KEY_HOME_DIM = "ui_home_dim"
        const val KEY_DRAWER_DIM = "ui_drawer_dim"
        const val KEY_DRAWER_BLUR = "ui_drawer_blur"
        const val KEY_FONT = "ui_font"
        const val KEY_TEXT_SCALE = "ui_text_scale"
        const val KEY_OPEN_ANIM = "ui_open_anim"
        const val KEY_GESTURES = "ui_gestures"
        const val KEY_DRAWER_PAGED = "ui_drawer_paged"
        const val KEY_ORDER = "drawer_order"
        const val KEY_ONBOARDED = "onboarded"
        const val KEY_HIDDEN = "app_hidden"
        const val KEY_NAMES = "app_names"
        const val KEY_ICONS = "app_icons"
        const val KEY_USAGE = "usage_count"
        const val KEY_LAST = "usage_last"
    }
}
