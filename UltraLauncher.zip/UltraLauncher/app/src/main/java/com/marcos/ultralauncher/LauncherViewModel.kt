package com.marcos.ultralauncher

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: ImageBitmap,
    /** Categoría que declara la app (ApplicationInfo.CATEGORY_*), -1 si no declara ninguna. */
    val category: Int = -1,
) {
    val key: String get() = "$packageName/$activityName"
}

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("ultra_launcher", Context.MODE_PRIVATE)
    private val pm: PackageManager = application.packageManager

    /** Host de widgets de Android (lo usan la pantalla de inicio y MainActivity). */
    val widgetHost = UltraWidgetHost(application)

    /** Todas las apps instaladas (cajón de apps), ordenadas alfabéticamente. */
    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set

    /** Qué hora se muestra debajo del reloj: la de Marcos o la de Arianna. */
    var clockPerson by mutableStateOf(ClockPerson.fromId(prefs.getString(KEY_PERSON, null)))
        private set

    /** Ajustes de personalización (tamaño, columnas, forma de iconos...). */
    var settings by mutableStateOf(loadSettings())
        private set

    /** Apps tal como las devuelve el sistema (sin nombres personalizados). */
    private var baseApps: List<AppInfo> = emptyList()

    /** Nombres personalizados: clave de app -> nombre. */
    private val customLabels = HashMap<String, String>().apply { putAll(readStringMap(KEY_CUSTOM_LABELS)) }

    /** Apps ocultas del cajón. */
    var hiddenKeys by mutableStateOf<Set<String>>(readStringSet(KEY_HIDDEN))
        private set

    private val launchCounts = HashMap<String, Int>().apply { putAll(readIntMap(KEY_USE_COUNT)) }
    private val lastLaunch = HashMap<String, Long>().apply { putAll(readLongMap(KEY_USE_LAST)) }

    /** Sube cuando cambia el uso de apps (para reordenar el cajón por uso/recientes). */
    var usageTick by mutableIntStateOf(0)
        private set

    /** App que se está renombrando (la muestra LauncherApp). */
    var renameTarget by mutableStateOf<AppInfo?>(null)

    /** La barra de búsqueda del inicio pide abrir el cajón con el teclado listo. */
    var searchSignal by mutableIntStateOf(0)
        private set
    var searchFocusPending = false

    /** Sube cada vez que se pulsa "Inicio" estando ya en el launcher. */
    var homeSignal by mutableIntStateOf(0)
        private set

    /** Página visible del inicio (la actualiza HomeScreen). Sirve para colocar lo que se añade. */
    var currentHomePage = 0

    /** True mientras hay un dedo sobre un widget: evita que salte el menú de "espacio vacío". */
    var widgetTouchActive = false

    // ---- Layout: lista de elementos con posición (página, fila, columna) ----

    /** Lo guardado tal cual (posiciones canónicas). */
    private var rawItems by mutableStateOf<List<HomeItem>>(emptyList())

    /** Medidas de la cuadrícula visible (las informa HomeScreen). */
    private var metrics by mutableStateOf<GridMetrics?>(null)

    /** Lo que se ve: lo guardado ajustado a las medidas actuales. */
    private val layout by derivedStateOf { resolveLayout(rawItems, metrics) }

    val homeItems: List<HomeItem> get() = layout.home
    val dockItems: List<HomeItem> get() = layout.dock

    /** Claves de apps de la lista plana antigua que aún hay que colocar en la cuadrícula. */
    private var pendingHome: List<String>? = null

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            reloadApps()
        }
    }

    init {
        BadgeStore.enabled = settings.showBadges
        val saved = prefs.getString(KEY_LAYOUT, null)?.let { LayoutJson.read(it) }
        if (saved != null) {
            rawItems = saved
        } else if (prefs.contains(KEY_HOME) || prefs.contains(KEY_DOCK)) {
            migrateLegacy()
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(
            application,
            packageReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        reloadApps()
    }

    override fun onCleared() {
        try {
            getApplication<Application>().unregisterReceiver(packageReceiver)
        } catch (e: Exception) {
        }
        widgetHost.stopListening()
        super.onCleared()
    }

    fun requestHome() {
        homeSignal++
    }

    fun selectPerson(person: ClockPerson) {
        clockPerson = person
        prefs.edit().putString(KEY_PERSON, person.id).apply()
    }

    // ---------------------------------------------------------------------------------------
    // Migración y guardado
    // ---------------------------------------------------------------------------------------

    /**
     * Versiones <= 1.1 guardaban dos listas planas (inicio y dock). El dock se convierte ya;
     * el inicio se reparte en la cuadrícula cuando se conocen sus medidas (igual que antes se
     * paginaba, así se ve idéntico). Las claves antiguas NO se borran: quedan como respaldo.
     */
    private fun migrateLegacy() {
        val dockKeys = readList(KEY_DOCK).take(DOCK_SLOTS)
        rawItems = dockKeys.mapIndexed { i, k ->
            HomeItem(newId(), ItemType.APP, DOCK_PAGE, 0, i, appKey = k)
        }
        pendingHome = readList(KEY_HOME)
    }

    fun onGridMetrics(m: GridMetrics) {
        if (metrics != m) metrics = m
        tryApplyPending()
    }

    /** Coloca la lista plana pendiente cuando ya hay medidas y apps cargadas. */
    private fun tryApplyPending() {
        val keys = pendingHome ?: return
        val m = metrics ?: return
        if (apps.isEmpty()) return
        pendingHome = null

        val present = apps.map { it.key }.toHashSet()
        val visible = keys.filter { it in present }.distinct()
        val items = ArrayList<HomeItem>()
        var page = 0
        var idx = 0
        var cap = (m.columns * m.rowsFirst).coerceAtLeast(1)
        val capOther = (m.columns * m.rowsOther).coerceAtLeast(1)
        for (k in visible) {
            if (idx >= cap) {
                page++
                idx = 0
                cap = capOther
            }
            items.add(HomeItem(newId(), ItemType.APP, page, idx / m.columns, idx % m.columns, appKey = k))
            idx++
        }
        commitRaw(rawItems + items)
        prefs.edit().putBoolean(KEY_SEEDED, true).apply()
    }

    private fun commitRaw(list: List<HomeItem>) {
        rawItems = compactPages(list)
        prefs.edit().putString(KEY_LAYOUT, LayoutJson.write(rawItems)).apply()
    }

    /** Punto único de edición: parte de lo que se ve, aplica el cambio y lo guarda. */
    private fun edit(block: (MutableList<HomeItem>) -> Unit) {
        val list = ArrayList<HomeItem>(layout.home.size + layout.dock.size + 1)
        list.addAll(layout.home)
        list.addAll(layout.dock)
        block(list)
        commitRaw(list)
    }

    private fun newId(): String = UUID.randomUUID().toString().substring(0, 8)

    private fun readList(key: String): List<String> =
        (prefs.getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }

    /** Quita del layout lo que ya no está instalado (y las carpetas que quedan vacías). */
    @Suppress("DEPRECATION")
    private fun pruneMissing() {
        if (apps.isEmpty()) return
        val present = apps.map { it.key }.toHashSet()
        val cache = HashMap<String, Boolean>()
        fun alive(key: String): Boolean {
            if (key in present) return true
            val pkg = key.substringBefore('/')
            return cache.getOrPut(pkg) {
                try {
                    pm.getApplicationInfo(pkg, 0)
                    true
                } catch (e: Exception) {
                    false
                }
            }
        }

        var changed = false
        val out = ArrayList<HomeItem>()
        for (item in rawItems) {
            when (item.type) {
                ItemType.APP -> {
                    if (alive(item.appKey ?: "")) {
                        out.add(item)
                    } else {
                        changed = true
                    }
                }
                ItemType.FOLDER -> {
                    val kids = item.children.filter { alive(it) }
                    if (kids.size != item.children.size) changed = true
                    if (kids.size == 1) {
                        out.add(HomeItem(newId(), ItemType.APP, item.page, item.row, item.col, appKey = kids[0]))
                    } else if (kids.size > 1) {
                        out.add(item.copy(children = kids))
                    }
                }
                ItemType.WIDGET -> out.add(item)
            }
        }
        if (changed) commitRaw(out)
    }

    // ---------------------------------------------------------------------------------------
    // Añadir / quitar desde el cajón y los menús
    // ---------------------------------------------------------------------------------------

    private fun guardLocked(): Boolean {
        if (settings.layoutLocked) {
            toast("El layout está bloqueado")
            return true
        }
        return false
    }

    fun addToHome(app: AppInfo) {
        if (guardLocked()) return
        val exists = layout.home.any {
            (it.type == ItemType.APP && it.appKey == app.key) ||
                (it.type == ItemType.FOLDER && app.key in it.children)
        }
        if (exists) {
            toast("Ya está en inicio")
            return
        }
        edit { list ->
            val m = metrics
            val pos = if (m != null) findFreeRect(list, m, currentHomePage, 1, 1) else Triple(0, 0, 0)
            list.add(HomeItem(newId(), ItemType.APP, pos.first, pos.second, pos.third, appKey = app.key))
        }
        toast("Añadida a inicio")
    }

    fun addToDock(app: AppInfo) {
        if (guardLocked()) return
        if (layout.dock.any { it.type == ItemType.APP && it.appKey == app.key }) {
            toast("Ya está en el dock")
            return
        }
        val free = (0 until DOCK_SLOTS).firstOrNull { s -> layout.dock.none { it.col == s } }
        if (free == null) {
            toast("El dock está lleno (máx. $DOCK_SLOTS)")
            return
        }
        edit { list ->
            list.add(HomeItem(newId(), ItemType.APP, DOCK_PAGE, 0, free, appKey = app.key))
        }
        toast("Añadida al dock")
    }

    /** Quita un elemento (app, carpeta o widget) del inicio o del dock. */
    fun removeItem(id: String) {
        if (guardLocked()) return
        val target = (layout.home + layout.dock).firstOrNull { it.id == id } ?: return
        if (target.type == ItemType.WIDGET) widgetHost.deleteId(target.widgetId)
        edit { list -> list.removeAll { it.id == id } }
    }

    // ---------------------------------------------------------------------------------------
    // Mover (arrastrar y soltar), carpetas
    // ---------------------------------------------------------------------------------------

    /**
     * Suelta un elemento 1x1 en una celda.
     * - Celda libre: se mueve.
     * - App sobre carpeta: se añade a la carpeta.
     * - App sobre app: carpeta nueva si se mantuvo encima ([merge]); si no, se intercambian.
     */
    fun moveItem(id: String, toDock: Boolean, page: Int, row: Int, col: Int, merge: Boolean) {
        if (guardLocked()) return
        edit { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@edit
            val moving = list[idx]
            if (moving.type == ItemType.WIDGET) return@edit
            val tPage = if (toDock) DOCK_PAGE else page
            val tRow = if (toDock) 0 else row
            val occIdx = list.indexOfFirst { it.id != id && it.page == tPage && it.covers(tRow, col) }
            if (occIdx < 0) {
                list[idx] = moving.copy(page = tPage, row = tRow, col = col)
                return@edit
            }
            val occ = list[occIdx]
            val movingKey = moving.appKey
            val occKey = occ.appKey
            if (occ.type == ItemType.WIDGET) {
                toast("Ahí hay un widget")
            } else if (moving.type == ItemType.APP && movingKey != null && occ.type == ItemType.FOLDER) {
                if (occ.children.size >= FOLDER_MAX) {
                    toast("La carpeta está llena")
                } else {
                    list[occIdx] = occ.copy(children = occ.children + movingKey)
                    list.removeAt(idx)
                }
            } else if (merge && moving.type == ItemType.APP && movingKey != null &&
                occ.type == ItemType.APP && occKey != null
            ) {
                val folder = HomeItem(
                    id = newId(),
                    type = ItemType.FOLDER,
                    page = occ.page,
                    row = occ.row,
                    col = occ.col,
                    title = "Carpeta",
                    children = listOf(occKey, movingKey),
                )
                list.removeAll { it.id == id || it.id == occ.id }
                list.add(folder)
            } else {
                // Intercambio de posiciones
                list[idx] = moving.copy(page = occ.page, row = occ.row, col = occ.col)
                list[occIdx] = occ.copy(page = moving.page, row = moving.row, col = moving.col)
            }
        }
    }

    fun renameFolder(id: String, title: String) {
        commitRaw((layout.home + layout.dock).map { if (it.id == id) it.copy(title = title) else it })
    }

    /** Aplica la nueva lista de apps de una carpeta: 0 la borra, 1 la convierte en app. */
    private fun applyFolderChildren(list: MutableList<HomeItem>, folder: HomeItem, kids: List<String>) {
        val idx = list.indexOfFirst { it.id == folder.id }
        if (idx < 0) return
        if (kids.isEmpty()) {
            list.removeAt(idx)
        } else if (kids.size == 1) {
            list[idx] = HomeItem(newId(), ItemType.APP, folder.page, folder.row, folder.col, appKey = kids[0])
        } else {
            list[idx] = folder.copy(children = kids)
        }
    }

    /** Saca una app de la carpeta y la deja en el primer hueco libre del inicio. */
    fun takeOutOfFolder(folderId: String, appKey: String) {
        if (guardLocked()) return
        edit { list ->
            val folder = list.firstOrNull { it.id == folderId } ?: return@edit
            val m = metrics
            val startPage = if (folder.isDock) currentHomePage else folder.page
            val pos = if (m != null) findFreeRect(list, m, startPage, 1, 1) else Triple(startPage.coerceAtLeast(0), 0, 0)
            list.add(HomeItem(newId(), ItemType.APP, pos.first, pos.second, pos.third, appKey = appKey))
            applyFolderChildren(list, folder, folder.children.filter { it != appKey })
        }
    }

    /** Deshace la carpeta: sus apps quedan sueltas (la primera ocupa el sitio de la carpeta). */
    fun dissolveFolder(id: String) {
        if (guardLocked()) return
        edit { list ->
            val folder = list.firstOrNull { it.id == id } ?: return@edit
            list.removeAll { it.id == id }
            val m = metrics
            folder.children.forEachIndexed { i, key ->
                val pos = if (i == 0) {
                    Triple(folder.page, folder.row, folder.col)
                } else if (m != null) {
                    findFreeRect(list, m, if (folder.isDock) currentHomePage else folder.page, 1, 1)
                } else {
                    Triple(0, 0, 0)
                }
                list.add(HomeItem(newId(), ItemType.APP, pos.first, pos.second, pos.third, appKey = key))
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Widgets
    // ---------------------------------------------------------------------------------------

    private fun density(): Float = getApplication<Application>().resources.displayMetrics.density

    /** Coloca un widget ya enlazado en el primer hueco libre. Si falla, libera su id. */
    fun addWidget(widgetId: Int): Boolean {
        val info = widgetHost.infoFor(widgetId)
        val m = metrics
        if (info == null || m == null) {
            widgetHost.deleteId(widgetId)
            toast("No se pudo añadir el widget")
            return false
        }
        val spans = widgetSpansFor(info, m, density())
        edit { list ->
            val pos = findFreeRect(list, m, currentHomePage, spans.second, spans.first)
            list.add(
                HomeItem(
                    id = newId(),
                    type = ItemType.WIDGET,
                    page = pos.first,
                    row = pos.second,
                    col = pos.third,
                    spanRows = spans.second,
                    spanCols = spans.first,
                    widgetId = widgetId,
                ),
            )
        }
        return true
    }

    fun canPlaceWidget(page: Int, row: Int, col: Int, sr: Int, sc: Int, ignoreId: String?): Boolean {
        val m = metrics ?: return false
        if (page < 0 || row < 0 || col < 0) return false
        if (row + sr > m.rowsOf(page) || col + sc > m.columns) return false
        return isRectFree(layout.home, page, row, col, sr, sc, ignoreId)
    }

    fun moveWidget(id: String, page: Int, row: Int, col: Int): Boolean {
        if (guardLocked()) return false
        var ok = false
        edit { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@edit
            val w = list[idx]
            if (canPlaceWidget(page, row, col, w.spanRows, w.spanCols, id)) {
                list[idx] = w.copy(page = page, row = row, col = col)
                ok = true
            }
        }
        if (!ok) toast("No hay espacio para el widget ahí")
        return ok
    }

    fun resizeWidget(id: String, cols: Int, rows: Int): Boolean {
        if (guardLocked()) return false
        var ok = false
        edit { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@edit
            val w = list[idx]
            if (canPlaceWidget(w.page, w.row, w.col, rows, cols, id)) {
                list[idx] = w.copy(spanRows = rows, spanCols = cols)
                ok = true
            }
        }
        if (!ok) toast("No hay espacio para ese tamaño")
        return ok
    }

    fun widgetLimits(item: HomeItem): SpanLimits {
        val m = metrics ?: return SpanLimits(item.spanCols, item.spanCols, item.spanRows, item.spanRows)
        return spanLimits(widgetHost.infoFor(item.widgetId), m, density(), item)
    }

    /** Lista de widgets instalados para el selector (se llama fuera del hilo principal). */
    @Suppress("DEPRECATION")
    fun loadWidgetEntries(): List<WidgetEntry> {
        val m = metrics
        val dens = density()
        val collator = Collator.getInstance(Locale.getDefault())
        return widgetHost.providers().mapNotNull { info ->
            try {
                val label = info.loadLabel(pm)?.toString() ?: ""
                val appLabel = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString()
                } catch (e: Exception) {
                    info.provider.packageName
                }
                val spans = if (m != null) widgetSpansFor(info, m, dens) else Pair(1, 1)
                WidgetEntry(info, appLabel, label, spans.first, spans.second)
            } catch (e: Exception) {
                null
            }
        }.sortedWith { a, b ->
            val c = collator.compare(a.appLabel, b.appLabel)
            if (c != 0) c else collator.compare(a.label, b.label)
        }
    }

    // ---------------------------------------------------------------------------------------
    // Ajustes
    // ---------------------------------------------------------------------------------------

    fun setLocked(locked: Boolean) {
        updateSettings(settings.copy(layoutLocked = locked))
    }

    fun updateSettings(new: UiSettings) {
        val old = settings
        settings = new
        BadgeStore.enabled = new.showBadges
        prefs.edit()
            .putInt(KEY_COLUMNS, new.columns)
            .putInt(KEY_DRAWER_COLUMNS, new.drawerColumns)
            .putFloat(KEY_ICON_DP, new.iconDp)
            .putBoolean(KEY_LABELS, new.showLabels)
            .putBoolean(KEY_CLOCK, new.showClock)
            .putString(KEY_SHAPE, new.shape.id)
            .putFloat(KEY_DOCK_ALPHA, new.dockAlpha)
            .putBoolean(KEY_LOCKED, new.layoutLocked)
            .putString(KEY_DRAWER_SORT, new.drawerSort.id)
            .putBoolean(KEY_DRAWER_CATS, new.drawerCategories)
            .putBoolean(KEY_SEARCH_BAR, new.showSearchBar)
            .putBoolean(KEY_THEMED, new.themedIcons)
            .putBoolean(KEY_BADGES, new.showBadges)
            .apply()
        if (old.themedIcons != new.themedIcons) reloadApps()
    }

    private fun loadSettings(): UiSettings = UiSettings(
        columns = prefs.getInt(KEY_COLUMNS, 4).coerceIn(4, 6),
        drawerColumns = prefs.getInt(KEY_DRAWER_COLUMNS, 4).coerceIn(4, 6),
        iconDp = prefs.getFloat(KEY_ICON_DP, 56f).coerceIn(40f, 80f),
        showLabels = prefs.getBoolean(KEY_LABELS, true),
        showClock = prefs.getBoolean(KEY_CLOCK, true),
        shape = IconShapeOption.fromId(prefs.getString(KEY_SHAPE, null)),
        dockAlpha = prefs.getFloat(KEY_DOCK_ALPHA, 0.16f).coerceIn(0f, 0.6f),
        layoutLocked = prefs.getBoolean(KEY_LOCKED, false),
        drawerSort = DrawerSort.fromId(prefs.getString(KEY_DRAWER_SORT, null)),
        drawerCategories = prefs.getBoolean(KEY_DRAWER_CATS, true),
        showSearchBar = prefs.getBoolean(KEY_SEARCH_BAR, false),
        themedIcons = prefs.getBoolean(KEY_THEMED, false),
        showBadges = prefs.getBoolean(KEY_BADGES, false),
    )

    // ---------------------------------------------------------------------------------------
    // Nombres, apps ocultas, uso y búsqueda (tanda 1.3)
    // ---------------------------------------------------------------------------------------

    private fun readStringMap(key: String): Map<String, String> = try {
        val o = JSONObject(prefs.getString(key, null) ?: "{}")
        val out = HashMap<String, String>()
        for (k in o.keys()) out[k] = o.optString(k)
        out
    } catch (e: Exception) {
        emptyMap()
    }

    private fun readIntMap(key: String): Map<String, Int> = try {
        val o = JSONObject(prefs.getString(key, null) ?: "{}")
        val out = HashMap<String, Int>()
        for (k in o.keys()) out[k] = o.optInt(k)
        out
    } catch (e: Exception) {
        emptyMap()
    }

    private fun readLongMap(key: String): Map<String, Long> = try {
        val o = JSONObject(prefs.getString(key, null) ?: "{}")
        val out = HashMap<String, Long>()
        for (k in o.keys()) out[k] = o.optLong(k)
        out
    } catch (e: Exception) {
        emptyMap()
    }

    private fun readStringSet(key: String): Set<String> = try {
        val a = JSONArray(prefs.getString(key, null) ?: "[]")
        val out = HashSet<String>()
        for (i in 0 until a.length()) out.add(a.getString(i))
        out
    } catch (e: Exception) {
        emptySet()
    }

    private fun saveJson(key: String, json: String) {
        prefs.edit().putString(key, json).apply()
    }

    /** Aplica los nombres personalizados y reordena alfabéticamente. */
    private fun applyLabels() {
        val collator = Collator.getInstance(Locale.getDefault())
        apps = baseApps
            .map { a ->
                val custom = customLabels[a.key]
                if (custom.isNullOrBlank()) a else a.copy(label = custom)
            }
            .sortedWith { a, b -> collator.compare(a.label, b.label) }
    }

    fun requestRename(app: AppInfo) {
        renameTarget = app
    }

    /** Guarda el nuevo nombre; vacío o null = volver al nombre original. */
    fun renameApp(key: String, label: String?) {
        val t = label?.trim().orEmpty()
        if (t.isEmpty()) customLabels.remove(key) else customLabels[key] = t.take(40)
        saveJson(KEY_CUSTOM_LABELS, JSONObject(customLabels).toString())
        renameTarget = null
        applyLabels()
    }

    fun hideApp(app: AppInfo) {
        hiddenKeys = hiddenKeys + app.key
        saveJson(KEY_HIDDEN, JSONArray(hiddenKeys.toList()).toString())
        toast("App oculta. Para mostrarla: Personalizar > Apps ocultas")
    }

    fun unhideApp(key: String) {
        hiddenKeys = hiddenKeys - key
        saveJson(KEY_HIDDEN, JSONArray(hiddenKeys.toList()).toString())
    }

    fun recordLaunch(app: AppInfo) {
        launchCounts[app.key] = (launchCounts[app.key] ?: 0) + 1
        lastLaunch[app.key] = System.currentTimeMillis()
        saveJson(KEY_USE_COUNT, JSONObject(launchCounts).toString())
        saveJson(KEY_USE_LAST, JSONObject(lastLaunch).toString())
        usageTick++
    }

    /** Apps del cajón: sin las ocultas y en el orden elegido (A-Z, más usadas o recientes). */
    fun drawerApps(): List<AppInfo> {
        val visible = apps.filter { it.key !in hiddenKeys }
        return when (settings.drawerSort) {
            DrawerSort.AZ -> visible
            DrawerSort.MOST_USED -> visible.sortedByDescending { launchCounts[it.key] ?: 0 }
            DrawerSort.RECENT -> visible.sortedByDescending { lastLaunch[it.key] ?: 0L }
        }
    }

    fun openSearch() {
        searchFocusPending = true
        searchSignal++
    }

    private fun themedColors(): ThemedColors {
        val ctx = getApplication<Application>()
        return if (Build.VERSION.SDK_INT >= 31) {
            ThemedColors(
                ctx.getColor(android.R.color.system_accent1_100),
                ctx.getColor(android.R.color.system_accent1_800),
            )
        } else {
            ThemedColors(0xFFD9E2FF.toInt(), 0xFF1B2B5B.toInt())
        }
    }

    // ---------------------------------------------------------------------------------------
    // Apps instaladas
    // ---------------------------------------------------------------------------------------

    fun reloadApps() {
        viewModelScope.launch {
            val themed = if (settings.themedIcons) themedColors() else null
            val list = withContext(Dispatchers.Default) { queryApps(themed) }
            baseApps = list
            applyLabels()
            if (list.isEmpty()) return@launch
            if (!prefs.getBoolean(KEY_SEEDED, false) &&
                prefs.getString(KEY_LAYOUT, null) == null &&
                pendingHome == null
            ) {
                seedDefaults(list)
            }
            tryApplyPending()
            pruneMissing()
        }
    }

    private fun queryApps(themed: ThemedColors?): List<AppInfo> {
        val ctx = getApplication<Application>()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(intent, 0)
        val iconPx = (ctx.resources.displayMetrics.density * 64f).toInt().coerceAtLeast(96)
        val collator = Collator.getInstance(Locale.getDefault())
        return resolved
            .filter { it.activityInfo.packageName != ctx.packageName }
            .mapNotNull { ri ->
                try {
                    val ai = ri.activityInfo
                    AppInfo(
                        label = ri.loadLabel(pm).toString(),
                        packageName = ai.packageName,
                        activityName = ai.name,
                        icon = ri.loadIcon(pm).toIconBitmap(iconPx, themed).asImageBitmap(),
                        category = ai.applicationInfo.category,
                    )
                } catch (e: Exception) {
                    null
                }
            }
            .sortedWith { a, b -> collator.compare(a.label, b.label) }
    }

    /** Primera vez: prepara el dock y el inicio con las apps típicas de un teléfono. */
    private fun seedDefaults(list: List<AppInfo>) {
        val byPackage = list.groupBy { it.packageName }

        fun firstFor(intent: Intent): AppInfo? {
            val packages = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
                .map { it.activityInfo.packageName }
            for (p in packages) {
                val found = byPackage[p]?.firstOrNull()
                if (found != null) return found
            }
            return null
        }

        val dock = listOfNotNull(
            firstFor(Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))),
            firstFor(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            firstFor(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com"))),
            firstFor(Intent(MediaStore.ACTION_IMAGE_CAPTURE)),
        ).distinctBy { it.key }

        val galleryIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse("content://media/external/images/media/1"), "image/*")
        }
        val fromIntents = listOfNotNull(
            firstFor(galleryIntent),
            firstFor(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)),
            firstFor(Intent(AlarmClock.ACTION_SHOW_ALARMS)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MAPS)),
            firstFor(Intent(Settings.ACTION_SETTINGS)),
        )
        val fromPackages = listOf(
            "com.android.vending",
            "com.google.android.youtube",
            "com.google.android.apps.photos",
            "com.google.android.gm",
            "com.whatsapp",
            "com.instagram.android",
            "com.spotify.music",
        ).mapNotNull { byPackage[it]?.firstOrNull() }

        val dockKeysSet = dock.map { it.key }.toSet()
        val home = (fromIntents + fromPackages)
            .distinctBy { it.key }
            .filter { it.key !in dockKeysSet }

        rawItems = dock.take(DOCK_SLOTS).mapIndexed { i, a ->
            HomeItem(newId(), ItemType.APP, DOCK_PAGE, 0, i, appKey = a.key)
        }
        pendingHome = home.map { it.key }
    }

    private fun toast(text: String) {
        Toast.makeText(getApplication<Application>(), text, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val KEY_HOME = "home_keys"
        const val KEY_DOCK = "dock_keys"
        const val KEY_LAYOUT = "layout_v2"
        const val KEY_PERSON = "clock_person"
        const val KEY_SEEDED = "seeded"
        const val KEY_COLUMNS = "ui_columns"
        const val KEY_DRAWER_COLUMNS = "ui_drawer_columns"
        const val KEY_ICON_DP = "ui_icon_dp"
        const val KEY_LABELS = "ui_labels"
        const val KEY_CLOCK = "ui_clock"
        const val KEY_SHAPE = "ui_shape"
        const val KEY_DOCK_ALPHA = "ui_dock_alpha"
        const val KEY_LOCKED = "ui_locked"
        const val KEY_DRAWER_SORT = "ui_drawer_sort"
        const val KEY_DRAWER_CATS = "ui_drawer_cats"
        const val KEY_SEARCH_BAR = "ui_search_bar"
        const val KEY_THEMED = "ui_themed_icons"
        const val KEY_BADGES = "ui_badges"
        const val KEY_CUSTOM_LABELS = "custom_labels_v1"
        const val KEY_HIDDEN = "hidden_apps_v1"
        const val KEY_USE_COUNT = "use_count_v1"
        const val KEY_USE_LAST = "use_last_v1"
    }
}
