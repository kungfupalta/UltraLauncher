package com.marcos.ultralauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Estado del servicio opcional de accesibilidad (solo sirve para bloquear la pantalla). */
object LockAccess {
    var service by mutableStateOf<LockAccessibilityService?>(null)

    val enabled: Boolean get() = service != null

    /** Bloquea la pantalla (Android 9+). Devuelve false si el servicio no está activo. */
    fun lock(): Boolean {
        if (Build.VERSION.SDK_INT < 28) return false
        val s = service ?: return false
        return try {
            s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        } catch (e: Exception) {
            false
        }
    }
}

/**
 * Servicio OPCIONAL: el único uso es el gesto "Bloquear pantalla". No lee el contenido de la
 * pantalla ni de otras apps (canRetrieveWindowContent = false).
 */
class LockAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        LockAccess.service = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        LockAccess.service = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    }

    override fun onInterrupt() {
    }
}
