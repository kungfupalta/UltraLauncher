package com.marcos.ultralauncher

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.marcos.ultralauncher.ui.LauncherApp
import com.marcos.ultralauncher.ui.UltraTheme

class MainActivity : ComponentActivity() {

    private val vm: LauncherViewModel by viewModels()
    private lateinit var widgetFlow: WidgetFlow

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetFlow = WidgetFlow(this, vm.widgetHost) { id -> vm.addWidget(id) }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            UltraTheme(vm.settings) {
                LauncherApp(vm, onAddWidget = { widgetFlow.start(it) })
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Para que los widgets se actualicen mientras el launcher está visible.
        vm.widgetHost.startListening()
    }

    override fun onResume() {
        super.onResume()
        // Puede haber cambiado un permiso opcional desde Ajustes.
        vm.refreshAccess()
    }

    override fun onStop() {
        vm.widgetHost.stopListening()
        super.onStop()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        widgetFlow.onActivityResult(requestCode, resultCode)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Pulsar "Inicio" estando ya aquí: cierra el cajón y vuelve a la primera página.
        if (intent.action == Intent.ACTION_MAIN) {
            vm.requestHome()
        }
    }
}
