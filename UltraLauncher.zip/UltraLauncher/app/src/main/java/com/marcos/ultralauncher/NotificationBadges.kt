package com.marcos.ultralauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Número de notificaciones por app, observable desde Compose. */
object BadgeStore {
    /** Lo activa/desactiva el ajuste "Insignias de notificación". */
    var enabled by mutableStateOf(false)

    val counts = mutableStateMapOf<String, Int>()

    fun countFor(packageName: String): Int = if (enabled) (counts[packageName] ?: 0) else 0

    fun replaceAll(map: Map<String, Int>) {
        val stale = counts.keys.filter { it !in map }
        stale.forEach { counts.remove(it) }
        for ((k, v) in map) {
            if (counts[k] != v) counts[k] = v
        }
    }
}

/** Lee las notificaciones activas (el usuario debe darle acceso en Ajustes del sistema). */
class UltraNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        refresh()
    }

    override fun onListenerDisconnected() {
        BadgeStore.replaceAll(emptyMap())
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refresh()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refresh()
    }

    private fun refresh() {
        try {
            val active = activeNotifications ?: return
            val map = HashMap<String, Int>()
            for (n in active) {
                if (n.isOngoing) continue
                if (n.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) continue
                map[n.packageName] = (map[n.packageName] ?: 0) + 1
            }
            BadgeStore.replaceAll(map)
        } catch (e: Exception) {
        }
    }
}
