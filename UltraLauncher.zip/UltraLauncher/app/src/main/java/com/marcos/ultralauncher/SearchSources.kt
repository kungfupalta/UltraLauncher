package com.marcos.ultralauncher

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat

data class ContactResult(val name: String, val uri: Uri)

/** Un acceso directo a una pantalla de Ajustes del sistema. */
data class SettingEntry(val title: String, val action: String)

val SettingEntries: List<SettingEntry> = listOf(
    SettingEntry("Wi‑Fi", Settings.ACTION_WIFI_SETTINGS),
    SettingEntry("Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS),
    SettingEntry("Pantalla", Settings.ACTION_DISPLAY_SETTINGS),
    SettingEntry("Sonido", Settings.ACTION_SOUND_SETTINGS),
    SettingEntry("Batería", Settings.ACTION_BATTERY_SAVER_SETTINGS),
    SettingEntry("Aplicaciones", Settings.ACTION_APPLICATION_SETTINGS),
    SettingEntry("Ubicación", Settings.ACTION_LOCATION_SOURCE_SETTINGS),
    SettingEntry("Almacenamiento", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
    SettingEntry("Fecha y hora", Settings.ACTION_DATE_SETTINGS),
    SettingEntry("Idioma", Settings.ACTION_LOCALE_SETTINGS),
    SettingEntry("Accesibilidad", Settings.ACTION_ACCESSIBILITY_SETTINGS),
    SettingEntry("Modo avión", Settings.ACTION_AIRPLANE_MODE_SETTINGS),
    SettingEntry("Ajustes", Settings.ACTION_SETTINGS),
)

fun Context.hasContactsPermission(): Boolean =
    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) ==
        PackageManager.PERMISSION_GRANTED

/** Busca contactos por nombre (necesita el permiso opcional de contactos). */
fun Context.searchContacts(query: String, limit: Int = 5): List<ContactResult> {
    if (!hasContactsPermission() || query.isBlank()) return emptyList()
    val out = ArrayList<ContactResult>()
    try {
        val uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_FILTER_URI, Uri.encode(query))
        val projection = arrayOf(
            ContactsContract.Contacts._ID,
            ContactsContract.Contacts.LOOKUP_KEY,
            ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
        )
        val cursor = contentResolver.query(
            uri,
            projection,
            null,
            null,
            ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " ASC",
        )
        cursor?.use { c ->
            while (c.moveToNext() && out.size < limit) {
                val id = c.getLong(0)
                val lookup = c.getString(1)
                val name = c.getString(2)
                if (lookup != null && name != null) {
                    out.add(ContactResult(name, ContactsContract.Contacts.getLookupUri(id, lookup)))
                }
            }
        }
    } catch (e: Exception) {
    }
    return out
}

fun Context.openContact(uri: Uri) {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}

fun Context.openSettingAction(action: String) {
    try {
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        openSystemSettings()
    }
}

fun Context.webSearch(query: String) {
    try {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}
