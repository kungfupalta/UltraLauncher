package com.marcos.ultralauncher

import android.content.Context
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserHandle

/** Atajo de una app (los que aparecen al mantener pulsado su icono en otros launchers). */
data class AppShortcut(
    val id: String,
    val packageName: String,
    val label: String,
    val user: UserHandle,
)

/**
 * Atajos de [packageName]. Android solo los entrega al launcher predeterminado; si el sistema
 * lo rechaza (no somos el launcher activo) se devuelve una lista vacía.
 */
fun Context.queryShortcuts(packageName: String, max: Int = 4): List<AppShortcut> {
    return try {
        val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps ?: return emptyList()
        val user = Process.myUserHandle()
        val query = LauncherApps.ShortcutQuery()
            .setPackage(packageName)
            .setQueryFlags(
                LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED,
            )
        val list = la.getShortcuts(query, user) ?: return emptyList()
        list.filter { it.isEnabled }
            .mapNotNull { info ->
                val label = (info.shortLabel ?: info.longLabel)?.toString()
                if (label.isNullOrBlank()) null else AppShortcut(info.id, info.`package`, label, user)
            }
            .take(max)
    } catch (e: Exception) {
        emptyList()
    }
}

fun Context.startAppShortcut(shortcut: AppShortcut) {
    try {
        val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps ?: return
        la.startShortcut(shortcut.packageName, shortcut.id, null, null, shortcut.user)
    } catch (e: Exception) {
    }
}
