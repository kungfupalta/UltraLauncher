package com.marcos.ultralauncher

enum class IconShapeOption(val id: String, val label: String) {
    SQUIRCLE("squircle", "Squircle"),
    CIRCLE("circle", "Círculo"),
    ROUNDED("rounded", "Suave"),
    SQUARE("square", "Cuadrado");

    companion object {
        fun fromId(id: String?): IconShapeOption =
            entries.firstOrNull { it.id == id } ?: SQUIRCLE
    }
}

/** Estilo de los iconos: originales (adaptativos) o monocromáticos tipo "iconos temáticos". */
enum class IconStyle(val id: String, val label: String) {
    NORMAL("normal", "Normal"),
    THEMED("themed", "Temático");

    companion object {
        fun fromId(id: String?): IconStyle = entries.firstOrNull { it.id == id } ?: NORMAL
    }
}

enum class DrawerSort(val id: String, val label: String) {
    ALPHA("alpha", "A–Z"),
    MOST_USED("used", "Más usadas"),
    RECENT("recent", "Recientes");

    companion object {
        fun fromId(id: String?): DrawerSort = entries.firstOrNull { it.id == id } ?: ALPHA
    }
}

enum class SearchBarPos(val id: String, val label: String) {
    TOP("top", "Arriba"),
    BOTTOM("bottom", "Abajo"),
    HIDDEN("hidden", "Oculta");

    companion object {
        fun fromId(id: String?): SearchBarPos = entries.firstOrNull { it.id == id } ?: HIDDEN
    }
}

/** Todo lo que se puede personalizar desde "Personalizar". */
data class UiSettings(
    val columns: Int = 4,
    val drawerColumns: Int = 4,
    val iconDp: Float = 56f,
    val showLabels: Boolean = true,
    val showClock: Boolean = true,
    val shape: IconShapeOption = IconShapeOption.SQUIRCLE,
    val dockAlpha: Float = 0.16f,
    /** Si está activo no se puede mover, quitar ni añadir nada del inicio. */
    val layoutLocked: Boolean = false,
    val iconStyle: IconStyle = IconStyle.NORMAL,
    /** Paquete del pack de iconos elegido ("" = ninguno). */
    val iconPack: String = "",
    val showBadges: Boolean = true,
    val drawerSort: DrawerSort = DrawerSort.ALPHA,
    val drawerTabs: Boolean = false,
    val searchBar: SearchBarPos = SearchBarPos.HIDDEN,
    val searchContacts: Boolean = false,
)
