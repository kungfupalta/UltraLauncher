package com.marcos.ultralauncher

enum class IconShapeOption(val id: String, val label: String) {
    SQUIRCLE("squircle", "Squircle"),
    CIRCLE("circle", "Círculo"),
    ROUNDED("rounded", "Suave"),
    SQUARE("square", "Cuadrado");

    companion object {
        fun fromId(id: String?): IconShapeOption =
            entries.firstOrNull { it.id == id } ?: SQUIRCLE
    }
}

enum class DrawerSort(val id: String, val label: String) {
    AZ("az", "A-Z"),
    MOST_USED("used", "Más usadas"),
    RECENT("recent", "Recientes");

    companion object {
        fun fromId(id: String?): DrawerSort = entries.firstOrNull { it.id == id } ?: AZ
    }
}

/** Todo lo que se puede personalizar desde "Personalizar". */
data class UiSettings(
    val columns: Int = 4,
    val drawerColumns: Int = 4,
    val iconDp: Float = 56f,
    val showLabels: Boolean = true,
    val showClock: Boolean = true,
    val shape: IconShapeOption = IconShapeOption.SQUIRCLE,
    val dockAlpha: Float = 0.16f,
    /** Si está activo no se puede mover, quitar ni añadir nada del inicio. */
    val layoutLocked: Boolean = false,
    /** Orden del cajón de apps. */
    val drawerSort: DrawerSort = DrawerSort.AZ,
    /** Fila de categorías (Juegos, Social...) arriba del cajón. */
    val drawerCategories: Boolean = true,
    /** Barra de búsqueda sobre el dock. */
    val showSearchBar: Boolean = false,
    /** Iconos monocromáticos con los colores del sistema (Android 13+; si la app no tiene, se deja normal). */
    val themedIcons: Boolean = false,
    /** Globos con el número de notificaciones (pide acceso a notificaciones). */
    val showBadges: Boolean = false,
)
