package com.marcos.ultralauncher

import androidx.compose.runtime.Immutable

enum class IconShapeOption(val id: String, val label: String) {
    SQUIRCLE("squircle", "Squircle"),
    CIRCLE("circle", "Círculo"),
    ROUNDED("rounded", "Suave"),
    SQUARE("square", "Cuadrado");

    companion object {
        fun fromId(id: String?): IconShapeOption =
            entries.firstOrNull { it.id == id } ?: SQUIRCLE
    }
}

/** Estilo de los iconos: originales (adaptativos) o monocromáticos tipo "iconos temáticos". */
enum class IconStyle(val id: String, val label: String) {
    NORMAL("normal", "Normal"),
    THEMED("themed", "Temático");

    companion object {
        fun fromId(id: String?): IconStyle = entries.firstOrNull { it.id == id } ?: NORMAL
    }
}

enum class DrawerSort(val id: String, val label: String) {
    ALPHA("alpha", "A–Z"),
    ALPHA_DESC("alpha_desc", "Z–A"),
    INSTALLED("installed", "Por descarga"),
    MOST_USED("used", "Más usadas"),
    RECENT("recent", "Últimas abiertas"),
    CUSTOM("custom", "Manual");

    companion object {
        fun fromId(id: String?): DrawerSort = entries.firstOrNull { it.id == id } ?: ALPHA
    }
}

enum class SearchBarPos(val id: String, val label: String) {
    TOP("top", "Arriba"),
    BOTTOM("bottom", "Abajo"),
    HIDDEN("hidden", "Oculta");

    companion object {
        fun fromId(id: String?): SearchBarPos = entries.firstOrNull { it.id == id } ?: HIDDEN
    }
}

enum class ThemeMode(val id: String, val label: String) {
    AUTO("auto", "Automático"),
    LIGHT("light", "Claro"),
    DARK("dark", "Oscuro");

    companion object {
        fun fromId(id: String?): ThemeMode = entries.firstOrNull { it.id == id } ?: AUTO
    }
}

/** Fuente de la interfaz (se mapea a FontFamily en la capa de UI). */
enum class AppFont(val id: String, val label: String) {
    DEFAULT("default", "Normal"),
    SANS("sans", "Sans"),
    SERIF("serif", "Serif"),
    MONO("mono", "Mono"),
    CURSIVE("cursive", "Cursiva");

    companion object {
        fun fromId(id: String?): AppFont = entries.firstOrNull { it.id == id } ?: DEFAULT
    }
}

/** Todo lo que se puede personalizar desde "Personalizar". */
@Immutable
data class UiSettings(
    val columns: Int = 4,
    val drawerColumns: Int = 4,
    val iconDp: Float = 56f,
    val showLabels: Boolean = true,
    val showClock: Boolean = true,
    val shape: IconShapeOption = IconShapeOption.SQUIRCLE,
    val dockAlpha: Float = 0.16f,
    /** Si está activo no se puede mover, quitar ni añadir nada del inicio. */
    val layoutLocked: Boolean = false,
    val iconStyle: IconStyle = IconStyle.NORMAL,
    /** Paquete del pack de iconos elegido ("" = ninguno). */
    val iconPack: String = "",
    val showBadges: Boolean = true,
    val drawerSort: DrawerSort = DrawerSort.ALPHA,
    val drawerTabs: Boolean = false,
    val searchBar: SearchBarPos = SearchBarPos.HIDDEN,
    val searchContacts: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.AUTO,
    /** Colores dinámicos Material You (Android 12+). */
    val dynamicColors: Boolean = false,
    /** Oscurecido fijo sobre el fondo en el inicio (0 a 0,6). */
    val homeDim: Float = 0f,
    /** Oscurecido del fondo al abrir el cajón (0,3 a 0,95). */
    val drawerDim: Float = 0.78f,
    /** Desenfoque del fondo al abrir el cajón (0 a 1; Android 12+). */
    val drawerBlur: Float = 0f,
    val font: AppFont = AppFont.DEFAULT,
    /** Escala del texto de toda la interfaz. */
    val textScale: Float = 1f,
    /** Las apps se abren creciendo desde el icono. */
    val openAnim: Boolean = true,
    val gestures: Map<GestureType, GestureBinding> = defaultGestures(),
    /** El cajón se desliza en horizontal, en páginas, en vez de hacia arriba y abajo. */
    val drawerPaged: Boolean = false,
)
