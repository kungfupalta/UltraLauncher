package com.marcos.ultralauncher

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent
import android.widget.Toast
import kotlin.math.ceil

/** Un widget disponible en el selector. */
data class WidgetEntry(
    val info: AppWidgetProviderInfo,
    val appLabel: String,
    val label: String,
    val spanCols: Int,
    val spanRows: Int,
)

/** Límites de tamaño (en celdas) al redimensionar un widget. */
data class SpanLimits(
    val minCols: Int,
    val maxCols: Int,
    val minRows: Int,
    val maxRows: Int,
) {
    val canResize: Boolean get() = maxCols > minCols || maxRows > minRows
}

/** Límites de tamaño (en dp) de un bloque con tamaño libre. */
data class LimitsDp(val minW: Float, val maxW: Float, val minH: Float, val maxH: Float) {
    val canResize: Boolean get() = maxW > minW + 1f || maxH > minH + 1f

    companion object {
        /** Normaliza para que el mínimo nunca pase al máximo. */
        fun of(minW: Float, maxW: Float, minH: Float, maxH: Float): LimitsDp {
            val a = minW.coerceAtLeast(MIN_BLOCK_DP)
            val b = minH.coerceAtLeast(MIN_BLOCK_DP)
            return LimitsDp(a, maxOf(a, maxW), b, maxOf(b, maxH))
        }
    }
}

/** Tamaño inicial (dp) de un widget: el que pide su proveedor, sin redondear a celdas. */
fun widgetDefaultDp(info: AppWidgetProviderInfo, m: GridMetrics, density: Float): Pair<Float, Float> {
    val totalW = m.columns * m.cellWDp
    val totalH = minOf(m.rowsFirst, m.rowsOther) * m.cellHDp
    val w = (info.minWidth / density).coerceIn(MIN_BLOCK_DP * 2f, totalW)
    val h = (info.minHeight / density).coerceIn(MIN_BLOCK_DP * 2f, totalH)
    return Pair(w, h)
}

/** Rango de tamaños (dp) que admite un widget según lo que declare su proveedor. */
fun widgetLimitsDp(info: AppWidgetProviderInfo?, m: GridMetrics, density: Float, item: HomeItem): LimitsDp {
    val totalW = m.columns * m.cellWDp
    val totalH = m.rowsOf(item.page) * m.cellHDp
    val cur = blockRect(item, m)
    val mode = info?.resizeMode ?: 0
    val horizontal = (mode and AppWidgetProviderInfo.RESIZE_HORIZONTAL) != 0
    val vertical = (mode and AppWidgetProviderInfo.RESIZE_VERTICAL) != 0
    val minWdp = if (info != null && info.minResizeWidth > 0) {
        minOf(info.minResizeWidth, info.minWidth) / density
    } else {
        MIN_BLOCK_DP
    }
    val minHdp = if (info != null && info.minResizeHeight > 0) {
        minOf(info.minResizeHeight, info.minHeight) / density
    } else {
        MIN_BLOCK_DP
    }
    return LimitsDp.of(
        minW = if (horizontal) minOf(minWdp, cur.w) else cur.w,
        maxW = if (horizontal) totalW else cur.w,
        minH = if (vertical) minOf(minHdp, cur.h) else cur.h,
        maxH = if (vertical) totalH else cur.h,
    )
}

/**
 * Celdas que necesita un widget al añadirlo. Los tamaños de AppWidgetProviderInfo vienen en píxeles,
 * por eso se pasan a dp con la densidad de pantalla.
 */
fun widgetSpansFor(info: AppWidgetProviderInfo, m: GridMetrics, density: Float): Pair<Int, Int> {
    val wDp = info.minWidth / density
    val hDp = info.minHeight / density
    val sc = ceil(wDp / m.cellWDp).toInt().coerceIn(1, m.columns)
    val sr = ceil(hDp / m.cellHDp).toInt().coerceIn(1, minOf(m.rowsFirst, m.rowsOther))
    return Pair(sc, sr)
}

/** Rango de tamaños permitido para un widget según lo que declare su proveedor. */
fun spanLimits(info: AppWidgetProviderInfo?, m: GridMetrics, density: Float, item: HomeItem): SpanLimits {
    val mode = info?.resizeMode ?: 0
    val horizontal = (mode and AppWidgetProviderInfo.RESIZE_HORIZONTAL) != 0
    val vertical = (mode and AppWidgetProviderInfo.RESIZE_VERTICAL) != 0
    val maxRowsPage = m.rowsOf(item.page)
    val minC = if (info != null) {
        ceil((info.minResizeWidth / density) / m.cellWDp).toInt().coerceIn(1, m.columns)
    } else {
        1
    }
    val minR = if (info != null) {
        ceil((info.minResizeHeight / density) / m.cellHDp).toInt().coerceIn(1, maxRowsPage)
    } else {
        1
    }
    return SpanLimits(
        minCols = if (horizontal) minOf(minC, item.spanCols) else item.spanCols,
        maxCols = if (horizontal) m.columns else item.spanCols,
        minRows = if (vertical) minOf(minR, item.spanRows) else item.spanRows,
        maxRows = if (vertical) maxRowsPage else item.spanRows,
    )
}

/** Envuelve AppWidgetHost: los widgets de este launcher se identifican con un host fijo. */
class UltraWidgetHost(context: Context) {

    private val appContext: Context = context.applicationContext
    val manager: AppWidgetManager = AppWidgetManager.getInstance(appContext)
    private val host = AppWidgetHost(appContext, HOST_ID)

    fun startListening() {
        try {
            host.startListening()
        } catch (e: Exception) {
        }
    }

    fun stopListening() {
        try {
            host.stopListening()
        } catch (e: Exception) {
        }
    }

    fun allocateId(): Int = host.allocateAppWidgetId()

    fun deleteId(id: Int) {
        try {
            host.deleteAppWidgetId(id)
        } catch (e: Exception) {
        }
    }

    fun infoFor(id: Int): AppWidgetProviderInfo? = try {
        manager.getAppWidgetInfo(id)
    } catch (e: Exception) {
        null
    }

    fun providers(): List<AppWidgetProviderInfo> = try {
        manager.installedProviders
    } catch (e: Exception) {
        emptyList()
    }

    fun createView(context: Context, id: Int, info: AppWidgetProviderInfo): AppWidgetHostView =
        host.createView(context, id, info)

    fun startConfigure(activity: Activity, id: Int, requestCode: Int) {
        host.startAppWidgetConfigureActivityForResult(activity, id, 0, requestCode, null)
    }

    private companion object {
        const val HOST_ID = 1024
    }
}

/**
 * Flujo para añadir un widget: reservar id -> permiso de enlace (si hace falta) ->
 * pantalla de configuración del widget (si la tiene) -> colocarlo en el inicio.
 */
class WidgetFlow(
    private val activity: Activity,
    private val host: UltraWidgetHost,
    private val onReady: (Int) -> Unit,
) {
    private var pendingId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null

    fun start(info: AppWidgetProviderInfo) {
        val id = try {
            host.allocateId()
        } catch (e: Exception) {
            toast("No se pudo reservar el widget")
            return
        }
        pendingId = id
        pendingInfo = info
        val allowed = try {
            host.manager.bindAppWidgetIdIfAllowed(id, info.provider)
        } catch (e: Exception) {
            false
        }
        if (allowed) {
            configureOrFinish()
        } else {
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            }
            try {
                activity.startActivityForResult(intent, REQ_BIND)
            } catch (e: Exception) {
                cancel()
                toast("Este dispositivo no permite enlazar widgets")
            }
        }
    }

    /** Devuelve true si el resultado era de este flujo. */
    fun onActivityResult(requestCode: Int, resultCode: Int): Boolean {
        when (requestCode) {
            REQ_BIND -> {
                if (resultCode == Activity.RESULT_OK) configureOrFinish() else cancel()
                return true
            }
            REQ_CONFIGURE -> {
                if (resultCode == Activity.RESULT_OK) finish() else cancel()
                return true
            }
        }
        return false
    }

    private fun configureOrFinish() {
        val info = pendingInfo ?: return
        if (info.configure != null) {
            try {
                host.startConfigure(activity, pendingId, REQ_CONFIGURE)
                return
            } catch (e: Exception) {
                // Si no se puede abrir la configuración, se añade con los valores por defecto.
            }
        }
        finish()
    }

    private fun finish() {
        val id = pendingId
        pendingId = -1
        pendingInfo = null
        if (id >= 0) onReady(id)
    }

    private fun cancel() {
        if (pendingId >= 0) host.deleteId(pendingId)
        pendingId = -1
        pendingInfo = null
    }

    private fun toast(text: String) {
        Toast.makeText(activity, text, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val REQ_BIND = 9101
        const val REQ_CONFIGURE = 9102
    }
}
