package com.marcos.ultralauncher.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.IconPackInfo
import com.marcos.ultralauncher.LauncherViewModel
import com.marcos.ultralauncher.listIconPacks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Cambiar el nombre y el icono de una app (solo dentro de este launcher). */
@Composable
fun AppEditDialog(vm: LauncherViewModel, app: AppInfo, onDismiss: () -> Unit) {
    var name by remember(app.key) { mutableStateOf(app.label) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setCustomIcon(app, uri)
    }
    val current = vm.apps.firstOrNull { it.key == app.key } ?: app

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ) {
            Column(
                Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Nombre e icono", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(14.dp))
                Image(
                    bitmap = current.icon,
                    contentDescription = null,
                    modifier = Modifier
                        .size(72.dp)
                        .clip(vm.settings.shape.toShape()),
                )
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    singleLine = true,
                    label = { Text("Nombre") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    TextButton(onClick = { picker.launch("image/*") }) { Text("Elegir imagen") }
                    TextButton(
                        onClick = { vm.resetCustomIcon(app) },
                        enabled = app.key in vm.customIconKeys,
                    ) { Text("Icono original") }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    TextButton(onClick = { name = app.originalLabel }) { Text("Nombre original") }
                    TextButton(
                        onClick = {
                            vm.setAppName(app, name)
                            onDismiss()
                        },
                    ) { Text("Guardar") }
                }
            }
        }
    }
}

/** Elegir el pack de iconos entre los instalados. */
@Composable
fun IconPackDialog(current: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val packs by produceState<List<IconPackInfo>?>(null) {
        value = withContext(Dispatchers.IO) { context.listIconPacks() }
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ) {
            Column(Modifier.padding(vertical = 20.dp)) {
                Text(
                    "Pack de iconos",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 24.dp),
                )
                Spacer(Modifier.height(8.dp))
                val list = packs
                if (list == null) {
                    Text("Buscando…", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        item(key = "none") {
                            PackRow("Ninguno (iconos originales)", current.isEmpty()) { onPick("") }
                        }
                        items(list, key = { it.packageName }) { p ->
                            PackRow(p.label, p.packageName == current) { onPick(p.packageName) }
                        }
                        if (list.isEmpty()) {
                            item(key = "empty") {
                                Text(
                                    "No hay packs de iconos instalados. Instalá uno desde Play Store " +
                                        "(compatible con ADW / Nova) y volvé acá.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                                )
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cerrar") }
                }
            }
        }
    }
}

@Composable
private fun PackRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else Color.Transparent)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (selected) Text("✓", color = MaterialTheme.colorScheme.primary)
    }
}

/** Lista de apps ocultas del cajón, con opción de volver a mostrarlas. */
@Composable
fun HiddenAppsDialog(vm: LauncherViewModel, onDismiss: () -> Unit) {
    val hidden = vm.apps.filter { it.key in vm.hiddenKeys }
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ) {
            Column(Modifier.padding(vertical = 20.dp)) {
                Text(
                    "Apps ocultas",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 24.dp),
                )
                Spacer(Modifier.height(8.dp))
                if (hidden.isEmpty()) {
                    Text(
                        "No ocultaste ninguna app. Para ocultar una: mantené pulsado su icono en el cajón.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    )
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(hidden, key = { it.key }) { app ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 24.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Image(
                                    bitmap = app.icon,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(vm.settings.shape.toShape()),
                                )
                                Spacer(Modifier.width(12.dp))
                                Text(app.label, fontSize = 15.sp, modifier = Modifier.weight(1f))
                                TextButton(onClick = { vm.unhideApp(app.key) }) { Text("Mostrar") }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cerrar") }
                }
            }
        }
    }
}
