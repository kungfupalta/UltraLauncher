package com.marcos.ultralauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marcos.ultralauncher.AppCategory
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.BadgeStore
import com.marcos.ultralauncher.ContactResult
import com.marcos.ultralauncher.DrawerSort
import com.marcos.ultralauncher.LauncherViewModel
import com.marcos.ultralauncher.SettingEntries
import com.marcos.ultralauncher.openContact
import com.marcos.ultralauncher.openSettingAction
import com.marcos.ultralauncher.searchContacts
import com.marcos.ultralauncher.webSearch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

/** Letra inicial para el scroller lateral ('#' para lo que no empieza por A–Z). */
private fun letterOf(label: String): Char {
    val first = label.trim().firstOrNull() ?: return '#'
    val base = Normalizer.normalize(first.toString(), Normalizer.Form.NFD).firstOrNull() ?: return '#'
    val up = base.uppercaseChar()
    return if (up in 'A'..'Z') up else '#'
}

@Composable
fun AppDrawer(
    vm: LauncherViewModel,
    connection: NestedScrollConnection,
    focusSearch: Boolean,
    onOpen: (AppInfo, Offset?) -> Unit,
    onAddHome: (AppInfo) -> Unit,
    onAddDock: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onEdit: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = vm.settings
    val iconSize = settings.iconDp.dp
    val shape = settings.shape.toShape()
    val showLabels = settings.showLabels

    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(AppCategory.ALL) }
    val focusRequester = remember { FocusRequester() }
    val gridState = rememberLazyGridState()

    LaunchedEffect(focusSearch) {
        if (focusSearch) {
            delay(320)
            try {
                focusRequester.requestFocus()
            } catch (e: Exception) {
            }
        }
    }

    val q = query.trim()
    val all = vm.drawerApps
    val tabs = remember(all) {
        AppCategory.entries.filter { c -> c == AppCategory.ALL || all.any { it.category == c } }
    }
    val activeTab = if (tab in tabs) tab else AppCategory.ALL
    val shown: List<AppInfo> = if (q.isEmpty()) {
        if (settings.drawerTabs && activeTab != AppCategory.ALL) all.filter { it.category == activeTab } else all
    } else {
        all.filter { it.label.contains(q, ignoreCase = true) || it.originalLabel.contains(q, ignoreCase = true) }
    }

    val contacts by produceState<List<ContactResult>>(emptyList(), q, settings.searchContacts, vm.contactsGranted) {
        value = if (q.isNotEmpty() && settings.searchContacts && vm.contactsGranted) {
            withContext(Dispatchers.IO) { context.searchContacts(q) }
        } else {
            emptyList()
        }
    }
    val settingMatches = if (q.isEmpty()) emptyList() else SettingEntries.filter { it.title.contains(q, ignoreCase = true) }

    val firstIndex = remember(shown) {
        val m = LinkedHashMap<Char, Int>()
        shown.forEachIndexed { i, a -> if (!m.containsKey(letterOf(a.label))) m[letterOf(a.label)] = i }
        m
    }
    val showScroller = q.isEmpty() && settings.drawerSort == DrawerSort.ALPHA && shown.size > 12

    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(top = 14.dp),
    ) {
        SearchField(
            query = query,
            onChange = { query = it },
            focusRequester = focusRequester,
            onSearch = {
                if (q.isNotEmpty()) {
                    val first = shown.firstOrNull()
                    if (first != null) onOpen(first, null) else context.webSearch(q)
                }
            },
        )

        if (settings.drawerTabs && q.isEmpty() && tabs.size > 1) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                tabs.forEach { c ->
                    val selected = c == activeTab
                    Text(
                        text = c.label,
                        fontSize = 13.sp,
                        color = if (selected) Color.Black else Color.White,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (selected) Color(0xFF8AB4FF) else Color.White.copy(alpha = 0.14f))
                            .clickable { tab = c }
                            .padding(horizontal = 14.dp, vertical = 7.dp),
                    )
                }
            }
        } else {
            Spacer(Modifier.height(8.dp))
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(settings.drawerColumns),
                state = gridState,
                modifier = Modifier
                    .fillMaxSize()
                    .nestedScroll(connection),
                contentPadding = PaddingValues(
                    start = 12.dp,
                    end = if (showScroller) 30.dp else 12.dp,
                    top = 8.dp,
                    bottom = 24.dp,
                ),
            ) {
                items(shown, key = { it.key }) { app ->
                    AppIcon(
                        app = app,
                        showLabel = showLabels,
                        iconSize = iconSize,
                        shape = shape,
                        badge = if (settings.showBadges) (BadgeStore.counts[app.packageName] ?: 0) else 0,
                        onClick = { c -> onOpen(app, c) },
                        menu = {
                            shortcutMenu(context, app) + listOf(
                                MenuAction("Añadir a inicio") { onAddHome(app) },
                                MenuAction("Añadir al dock") { onAddDock(app) },
                                MenuAction("Nombre e icono") { onEdit(app) },
                                MenuAction("Ocultar app") { vm.hideApp(app) },
                                MenuAction("Info de la app") { onInfo(app) },
                                MenuAction("Desinstalar") { onUninstall(app) },
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (showLabels) iconSize + 40.dp else iconSize + 26.dp),
                    )
                }

                if (q.isNotEmpty()) {
                    if (contacts.isNotEmpty()) {
                        item(key = "h:contacts", span = { GridItemSpan(maxLineSpan) }) {
                            SectionHeader("Contactos")
                        }
                        items(
                            contacts,
                            key = { c -> "c:" + c.uri.toString() },
                            span = { GridItemSpan(maxLineSpan) },
                        ) { c ->
                            ResultRow(c.name) { context.openContact(c.uri) }
                        }
                    }
                    if (settingMatches.isNotEmpty()) {
                        item(key = "h:settings", span = { GridItemSpan(maxLineSpan) }) {
                            SectionHeader("Ajustes")
                        }
                        items(
                            settingMatches,
                            key = { s -> "s:" + s.action },
                            span = { GridItemSpan(maxLineSpan) },
                        ) { s ->
                            ResultRow(s.title) { context.openSettingAction(s.action) }
                        }
                    }
                    item(key = "h:web", span = { GridItemSpan(maxLineSpan) }) {
                        SectionHeader("Web")
                    }
                    item(key = "web", span = { GridItemSpan(maxLineSpan) }) {
                        ResultRow("Buscar «$q» en la web") { context.webSearch(q) }
                    }
                }
            }

            if (showScroller) {
                AlphabetScroller(
                    letters = firstIndex.keys.toList(),
                    onSelect = { c ->
                        val idx = firstIndex[c]
                        if (idx != null) scope.launch { gridState.scrollToItem(idx) }
                    },
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(vertical = 8.dp),
                )
            }
        }
        Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        color = Color(0xFF8AB4FF),
        fontSize = 13.sp,
        modifier = Modifier.padding(start = 12.dp, top = 16.dp, bottom = 4.dp),
    )
}

@Composable
private fun ResultRow(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 16.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
    )
}

/** Barra de letras al borde derecho: tocar o arrastrar salta a esa letra. */
@Composable
private fun AlphabetScroller(
    letters: List<Char>,
    onSelect: (Char) -> Unit,
    modifier: Modifier = Modifier,
) {
    var heightPx by remember { mutableIntStateOf(1) }
    var active by remember { mutableStateOf<Char?>(null) }

    fun pick(y: Float) {
        if (letters.isEmpty()) return
        val i = (y / heightPx * letters.size).toInt().coerceIn(0, letters.size - 1)
        val c = letters[i]
        if (c != active) {
            active = c
            onSelect(c)
        }
    }

    Column(
        modifier = modifier
            .width(24.dp)
            .fillMaxHeight()
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pointerInput(letters) {
                detectDragGestures(
                    onDragStart = { pick(it.y) },
                    onDrag = { change, _ ->
                        change.consume()
                        pick(change.position.y)
                    },
                    onDragEnd = { active = null },
                    onDragCancel = { active = null },
                )
            }
            .pointerInput(letters) {
                detectTapGestures(
                    onPress = { offset ->
                        pick(offset.y)
                        tryAwaitRelease()
                        active = null
                    },
                )
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        letters.forEach { c ->
            Text(
                text = c.toString(),
                fontSize = 10.sp,
                color = if (c == active) Color(0xFF8AB4FF) else Color.White.copy(alpha = 0.7f),
            )
        }
    }
}

@Composable
private fun SearchField(
    query: String,
    onChange: (String) -> Unit,
    focusRequester: FocusRequester,
    onSearch: () -> Unit,
) {
    BasicTextField(
        value = query,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
        cursorBrush = SolidColor(Color.White),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .focusRequester(focusRequester),
        decorationBox = { inner ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color.White.copy(alpha = 0.16f))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.size(22.dp),
                )
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text(
                            text = "Buscar apps, contactos, ajustes y web",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 16.sp,
                        )
                    }
                    inner()
                }
            }
        },
    )
}
