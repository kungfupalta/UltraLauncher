package com.marcos.ultralauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marcos.ultralauncher.AppCategory
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.BadgeStore
import com.marcos.ultralauncher.appCategory
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.Normalizer

@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    connection: NestedScrollConnection,
    onOpen: (AppInfo) -> Unit,
    onAddHome: (AppInfo) -> Unit,
    onAddDock: (AppInfo) -> Unit,
    onRename: (AppInfo) -> Unit,
    onHide: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onWebSearch: (String) -> Unit,
    columns: Int,
    iconSize: Dp,
    shape: Shape,
    showLabels: Boolean,
    showLetters: Boolean,
    showCategories: Boolean,
    requestFocus: Boolean,
    onFocusHandled: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(AppCategory.ALL) }
    val focusRequester = remember { FocusRequester() }
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()

    // Si se llegó desde la barra de búsqueda del inicio: foco en el campo (y teclado).
    LaunchedEffect(Unit) {
        if (requestFocus) {
            onFocusHandled()
            delay(250)
            try {
                focusRequester.requestFocus()
            } catch (e: Exception) {
            }
        }
    }

    val activeCategory = if (showCategories) category else AppCategory.ALL
    val filtered = remember(apps, query, activeCategory) {
        val q = query.trim()
        apps.filter { app ->
            (activeCategory == AppCategory.ALL || app.appCategory() == activeCategory) &&
                (q.isEmpty() || app.label.contains(q, ignoreCase = true))
        }
    }

    val lettersOn = showLetters && query.isBlank() && filtered.size > 12
    val letterIndex = remember(filtered, lettersOn) {
        val map = LinkedHashMap<Char, Int>()
        if (lettersOn) {
            filtered.forEachIndexed { i, app -> map.getOrPut(letterOf(app.label)) { i } }
        }
        map
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(top = 14.dp),
    ) {
        SearchField(
            query = query,
            onChange = { query = it },
            focusRequester = focusRequester,
            onSearch = {
                val first = filtered.firstOrNull()
                if (first != null) {
                    onOpen(first)
                } else if (query.isNotBlank()) {
                    onWebSearch(query.trim())
                }
            },
        )

        if (showCategories) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AppCategory.entries.forEach { c ->
                    val selected = c == category
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (selected) Color(0xFF8AB4FF) else Color.White.copy(alpha = 0.14f))
                            .clickable { category = c }
                            .padding(horizontal = 14.dp, vertical = 7.dp),
                    ) {
                        Text(
                            text = c.label,
                            fontSize = 13.sp,
                            color = if (selected) Color.Black else Color.White,
                        )
                    }
                }
            }
        } else {
            Spacer(Modifier.height(8.dp))
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                state = gridState,
                modifier = Modifier
                    .fillMaxSize()
                    .nestedScroll(connection),
                contentPadding = PaddingValues(
                    start = 12.dp,
                    end = if (lettersOn) 28.dp else 12.dp,
                    top = 8.dp,
                    bottom = 24.dp,
                ),
            ) {
                items(filtered, key = { it.key }) { app ->
                    AppIcon(
                        app = app,
                        showLabel = showLabels,
                        iconSize = iconSize,
                        shape = shape,
                        badgeCount = BadgeStore.countFor(app.packageName),
                        onClick = { onOpen(app) },
                        menu = listOf(
                            MenuAction("Añadir a inicio") { onAddHome(app) },
                            MenuAction("Añadir al dock") { onAddDock(app) },
                            MenuAction("Renombrar") { onRename(app) },
                            MenuAction("Ocultar del cajón") { onHide(app) },
                            MenuAction("Info de la app") { onInfo(app) },
                            MenuAction("Desinstalar") { onUninstall(app) },
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (showLabels) iconSize + 40.dp else iconSize + 26.dp),
                    )
                }
                if (query.isNotBlank()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        WebSearchRow(query = query.trim(), onClick = { onWebSearch(query.trim()) })
                    }
                }
            }

            if (lettersOn && letterIndex.isNotEmpty()) {
                LetterStrip(
                    letters = letterIndex.keys.toList(),
                    onJump = { letter ->
                        scope.launch { gridState.scrollToItem(letterIndex[letter] ?: 0) }
                    },
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight()
                        .padding(vertical = 8.dp)
                        .width(24.dp),
                )
            }
        }
        Spacer(Modifier.navigationBarsPadding())
    }
}

/** Primera letra (sin tilde) en mayúscula; lo que no es letra va bajo "#". */
private fun letterOf(label: String): Char {
    val c = label.trim().firstOrNull() ?: return '#'
    val base = Normalizer.normalize(c.uppercaseChar().toString(), Normalizer.Form.NFD).firstOrNull() ?: c
    return if (base.isLetter()) base else '#'
}

/** Tira de letras al borde: tocar o arrastrar salta a esa letra. */
@Composable
private fun LetterStrip(
    letters: List<Char>,
    onJump: (Char) -> Unit,
    modifier: Modifier = Modifier,
) {
    var heightPx by remember { mutableIntStateOf(1) }

    fun jump(y: Float) {
        if (letters.isEmpty()) return
        val idx = (y / heightPx * letters.size).toInt().coerceIn(0, letters.size - 1)
        onJump(letters[idx])
    }

    Column(
        modifier = modifier
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pointerInput(letters) {
                detectTapGestures(onTap = { o -> jump(o.y) })
            }
            .pointerInput(letters) {
                detectVerticalDragGestures(
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        jump(change.position.y)
                    },
                )
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly,
    ) {
        letters.forEach { l ->
            Text(text = l.toString(), color = Color.White.copy(alpha = 0.75f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun WebSearchRow(query: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.12f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            )
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.85f),
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(12.dp))
        Text(text = "Buscar \"$query\" en la web", color = Color.White, fontSize = 15.sp)
    }
}

@Composable
private fun SearchField(
    query: String,
    onChange: (String) -> Unit,
    focusRequester: FocusRequester,
    onSearch: () -> Unit,
) {
    BasicTextField(
        value = query,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
        cursorBrush = SolidColor(Color.White),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .focusRequester(focusRequester),
        decorationBox = { inner ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color.White.copy(alpha = 0.16f))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.size(22.dp),
                )
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text(
                            text = "Buscar",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 16.sp,
                        )
                    }
                    inner()
                }
            }
        },
    )
}
