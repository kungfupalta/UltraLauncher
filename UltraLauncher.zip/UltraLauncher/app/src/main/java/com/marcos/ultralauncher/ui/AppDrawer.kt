package com.marcos.ultralauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marcos.ultralauncher.AppCategory
import com.marcos.ultralauncher.AppEntry
import com.marcos.ultralauncher.DrawerEntry
import com.marcos.ultralauncher.FolderEntry
import com.marcos.ultralauncher.HomeItem
import com.marcos.ultralauncher.ItemType
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.BadgeStore
import com.marcos.ultralauncher.ContactResult
import com.marcos.ultralauncher.DrawerSort
import com.marcos.ultralauncher.LauncherViewModel
import com.marcos.ultralauncher.SettingEntries
import com.marcos.ultralauncher.openContact
import com.marcos.ultralauncher.openSettingAction
import com.marcos.ultralauncher.searchContacts
import com.marcos.ultralauncher.webSearch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer
import kotlin.math.roundToInt

/** Letra inicial para el scroller lateral ('#' para lo que no empieza por A–Z). */
private fun letterOf(label: String): Char {
    val first = label.trim().firstOrNull() ?: return '#'
    val base = Normalizer.normalize(first.toString(), Normalizer.Form.NFD).firstOrNull() ?: return '#'
    val up = base.uppercaseChar()
    return if (up in 'A'..'Z') up else '#'
}

@Composable
fun AppDrawer(
    vm: LauncherViewModel,
    connection: NestedScrollConnection,
    focusSearch: Boolean,
    onOpen: (AppInfo, Offset?) -> Unit,
    onAddHome: (AppInfo) -> Unit,
    onAddDock: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onEdit: (AppInfo) -> Unit,
    onRequestClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val dd = remember { DrawerDrag() }
    val scope = rememberCoroutineScope()
    val settings = vm.settings
    val iconSize = settings.iconDp.dp
    val shape = settings.shape.toShape()
    val showLabels = settings.showLabels

    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(AppCategory.ALL) }
    var sortMenu by remember { mutableStateOf(false) }
    var openFolderId by remember { mutableStateOf<String?>(null) }
    var folderCenter by remember { mutableStateOf(Offset.Zero) }
    var drawerOrigin by remember { mutableStateOf(Offset.Zero) }
    val focusRequester = remember { FocusRequester() }
    val gridState = rememberLazyGridState()

    LaunchedEffect(focusSearch) {
        if (focusSearch) {
            delay(320)
            try {
                focusRequester.requestFocus()
            } catch (e: Exception) {
            }
        }
    }

    val q = query.trim()
    val all = vm.drawerApps
    val tabs = remember(all) {
        AppCategory.entries.filter { c -> c == AppCategory.ALL || all.any { it.category == c } }
    }
    val activeTab = if (tab in tabs) tab else AppCategory.ALL
    val entriesAll = vm.drawerEntries
    val shown: List<DrawerEntry> = remember(entriesAll, all, q, activeTab, settings.drawerTabs) {
        if (q.isEmpty()) {
            if (settings.drawerTabs && activeTab != AppCategory.ALL) {
                all.filter { it.category == activeTab }.map { AppEntry(it) }
            } else {
                entriesAll
            }
        } else {
            all.filter { it.label.contains(q, ignoreCase = true) || it.originalLabel.contains(q, ignoreCase = true) }
                .map { AppEntry(it) }
        }
    }

    val contacts by produceState<List<ContactResult>>(emptyList(), q, settings.searchContacts, vm.contactsGranted) {
        value = if (q.isNotEmpty() && settings.searchContacts && vm.contactsGranted) {
            withContext(Dispatchers.IO) { context.searchContacts(q) }
        } else {
            emptyList()
        }
    }
    val settingMatches = if (q.isEmpty()) emptyList() else SettingEntries.filter { it.title.contains(q, ignoreCase = true) }

    val firstIndex = remember(shown) {
        val m = LinkedHashMap<Char, Int>()
        shown.forEachIndexed { i, a -> if (!m.containsKey(letterOf(a.label))) m[letterOf(a.label)] = i }
        m
    }
    // El espacio del scroller se reserva siempre (así la grilla no se corre al pasar a orden manual).
    val reserveScroller = q.isEmpty() && shown.size > 12
    val showScroller = reserveScroller && settings.drawerSort == DrawerSort.ALPHA

    Box(
        modifier = modifier
            .fillMaxSize()
            .onGloballyPositioned { drawerOrigin = it.positionInRoot() },
    ) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(top = 14.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                SearchField(
                    query = query,
                    onChange = { query = it },
                    focusRequester = focusRequester,
                    onSearch = {
                        if (q.isNotEmpty()) {
                            val first = (shown.firstOrNull() as? AppEntry)?.app
                            if (first != null) onOpen(first, null) else context.webSearch(q)
                        }
                    },
                )
            }
            Box(Modifier.padding(end = 12.dp)) {
                Text(
                    text = "⋮",
                    color = Color.White,
                    fontSize = 26.sp,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable { sortMenu = true }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                )
                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                    DropdownMenuItem(text = { Text("Ordenar por") }, onClick = {}, enabled = false)
                    DrawerSort.entries.forEach { opt ->
                        val mark = if (opt == settings.drawerSort) "✓  " else "     "
                        DropdownMenuItem(
                            text = { Text(mark + opt.label) },
                            onClick = {
                                sortMenu = false
                                if (opt == DrawerSort.CUSTOM) vm.enableManualOrder() else vm.updateSettings(settings.copy(drawerSort = opt))
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (settings.drawerPaged) "Ver en lista (vertical)" else "Ver en páginas (horizontal)") },
                        onClick = {
                            sortMenu = false
                            vm.updateSettings(settings.copy(drawerPaged = !settings.drawerPaged))
                        },
                    )
                    if (settings.drawerSort == DrawerSort.CUSTOM) {
                        DropdownMenuItem(
                            text = { Text("Restablecer orden manual") },
                            onClick = {
                                sortMenu = false
                                vm.resetManualOrder()
                            },
                        )
                    }
                }
            }
        }

        if (settings.drawerTabs && q.isEmpty() && tabs.size > 1) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                tabs.forEach { c ->
                    val selected = c == activeTab
                    Text(
                        text = c.label,
                        fontSize = 13.sp,
                        color = if (selected) Color.Black else Color.White,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (selected) Color(0xFF8AB4FF) else Color.White.copy(alpha = 0.14f))
                            .clickable { tab = c }
                            .padding(horizontal = 14.dp, vertical = 7.dp),
                    )
                }
            }
        } else {
            Spacer(Modifier.height(8.dp))
        }

        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .onGloballyPositioned { dd.areaRect = it.boundsInRoot() },
        ) {
            val cols = adaptiveColumns(settings.drawerColumns, LocalConfiguration.current.screenWidthDp)
            val cellH = if (showLabels) iconSize + 40.dp else iconSize + 26.dp
            val startPad = 12.dp
            val endPad = if (reserveScroller) 30.dp else 12.dp
            val topPad = 8.dp
            val indicatorSpace = 28.dp
            val usePaged = settings.drawerPaged && q.isEmpty()
            val canReorder = q.isEmpty() && (!settings.drawerTabs || activeTab == AppCategory.ALL)
            val rows = ((maxHeight - topPad - indicatorSpace) / cellH).toInt().coerceAtLeast(1)
            val perPage = cols * rows
            val pageCount = ((shown.size + perPage - 1) / perPage).coerceAtLeast(1)
            val pagerState = rememberPagerState(pageCount = { pageCount })
            val shownNow by rememberUpdatedState(shown)

            SideEffect {
                dd.paged = usePaged
                dd.columns = cols
                dd.rows = rows
                dd.itemCount = shown.size
                dd.startPadPx = with(density) { startPad.toPx() }
                dd.topPadPx = with(density) { topPad.toPx() }
                dd.cellWPx = with(density) { ((maxWidth - startPad - endPad) / cols).toPx() }
                dd.cellHPx = with(density) { cellH.toPx() }
                dd.scrollProvider = {
                    (gridState.firstVisibleItemIndex / cols) * dd.cellHPx + gridState.firstVisibleItemScrollOffset
                }
                dd.pageProvider = { pagerState.currentPage }
            }

            // Suelta: reordena, crea una carpeta (app sobre app mantenida) o mete la app en una carpeta.
            fun finishDrag(moved: Boolean) {
                val key = dd.dragKey
                val target = shownNow.getOrNull(dd.hoverIndex)
                val merge = dd.mergeReady
                val dragged = shownNow.firstOrNull { it.key == key }
                dd.cancel()
                if (!moved || key == null || target == null || target.key == key) return
                if (dragged is AppEntry && target is FolderEntry) {
                    vm.addToDrawerFolder(target.folder.id, dragged.app.key)
                } else if (dragged is AppEntry && target is AppEntry && merge) {
                    vm.createDrawerFolder(dragged.app.key, target.app.key)
                } else {
                    vm.reorderDrawer(key, target.key)
                }
            }

            DrawerMergeTimer(dd)

            // Mientras se arrastra: desplaza la lista (o cambia de página) al llegar a los bordes.
            LaunchedEffect(dd.active, usePaged) {
                if (!dd.active) return@LaunchedEffect
                val edgeY = with(density) { 72.dp.toPx() }
                val edgeX = with(density) { 44.dp.toPx() }
                var cooldown = 0
                while (true) {
                    val r = dd.areaRect
                    val p = dd.pointer
                    if (!usePaged) {
                        val dy = when {
                            p.y < r.top + edgeY -> -18f
                            p.y > r.bottom - edgeY -> 18f
                            else -> 0f
                        }
                        if (dy != 0f) {
                            gridState.scrollBy(dy)
                            dd.update(p)
                        }
                    } else if (cooldown > 0) {
                        cooldown--
                    } else {
                        val dir = when {
                            p.x < r.left + edgeX -> -1
                            p.x > r.right - edgeX -> 1
                            else -> 0
                        }
                        val target = pagerState.currentPage + dir
                        if (dir != 0 && target in 0 until pagerState.pageCount) {
                            pagerState.animateScrollToPage(target)
                            cooldown = 30
                            dd.update(p)
                        }
                    }
                    delay(16)
                }
            }

            // Una celda del cajón: app o carpeta (con su menú y el arrastre para reordenar).
            @Composable
            fun DrawerCell(entry: DrawerEntry, index: Int, cellModifier: Modifier) {
                val isTarget by remember(index, entry.key) {
                    derivedStateOf { dd.hoverIndex == index && dd.dragKey != entry.key }
                }
                val handle = if (canReorder) {
                    remember(entry.key) {
                        ReorderHandle(
                            onStart = { p ->
                                vm.enableManualOrder()
                                dd.begin(entry.key, p)
                            },
                            onMove = { dd.update(it) },
                            onEnd = { moved -> finishDrag(moved) },
                            onCancel = { dd.cancel() },
                        )
                    }
                } else {
                    null
                }
                val dimmed = dd.dragKey == entry.key
                when (entry) {
                    is AppEntry -> {
                        val app = entry.app
                        val draggedIsApp = dd.dragKey?.startsWith("f:") == false
                        AppIcon(
                            app = app,
                            showLabel = showLabels,
                            iconSize = iconSize,
                            shape = shape,
                            badge = if (settings.showBadges) (BadgeStore.counts[app.packageName] ?: 0) else 0,
                            onClick = { c -> onOpen(app, c) },
                            menu = {
                                shortcutMenu(context, app) + listOf(
                                    MenuAction("Añadir a inicio") { onAddHome(app) },
                                    MenuAction("Añadir al dock") { onAddDock(app) },
                                    MenuAction("Nombre e icono") { onEdit(app) },
                                    MenuAction("Ocultar app") { vm.hideApp(app) },
                                    MenuAction("Info de la app") { onInfo(app) },
                                    MenuAction("Desinstalar") { onUninstall(app) },
                                )
                            },
                            reorder = handle,
                            highlight = isTarget,
                            merging = isTarget && dd.mergeReady && draggedIsApp,
                            dimmed = dimmed,
                            modifier = cellModifier,
                        )
                    }
                    is FolderEntry -> {
                        IconCell(
                            keyId = entry.key,
                            label = entry.label,
                            showLabel = showLabels,
                            iconSize = iconSize,
                            menu = {
                                listOf(
                                    MenuAction("Abrir") {
                                        folderCenter = Offset(dd.areaRect.center.x, dd.areaRect.center.y)
                                        openFolderId = entry.folder.id
                                    },
                                    MenuAction("Deshacer carpeta") { vm.dissolveDrawerFolder(entry.folder.id) },
                                )
                            },
                            onClick = { c ->
                                folderCenter = c
                                openFolderId = entry.folder.id
                            },
                            reorder = handle,
                            highlight = isTarget,
                            dimmed = dimmed,
                            modifier = cellModifier,
                        ) { size ->
                            FolderIcon(apps = entry.apps, size = size, shape = shape)
                        }
                    }
                }
            }

            if (usePaged) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            // Deslizar hacia abajo cierra el cajón (en modo páginas no hay lista que lo haga).
                            var total = 0f
                            detectVerticalDragGestures(
                                onDragStart = { total = 0f },
                                onVerticalDrag = { _, dy -> total += dy },
                                onDragEnd = { if (total > 140.dp.toPx() && !dd.active) onRequestClose() },
                            )
                        },
                ) { page ->
                    Column(
                        Modifier
                            .fillMaxSize()
                            .padding(start = startPad, end = endPad, top = topPad),
                    ) {
                        for (r in 0 until rows) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .height(cellH),
                            ) {
                                for (c in 0 until cols) {
                                    val idx = page * perPage + r * cols + c
                                    val entry = shown.getOrNull(idx)
                                    if (entry != null) {
                                        key(entry.key) {
                                            DrawerCell(entry, idx, Modifier.weight(1f).fillMaxHeight())
                                        }
                                    } else {
                                        Spacer(Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
                if (pageCount > 1) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                    ) {
                        repeat(pageCount) { i ->
                            val selected = i == pagerState.currentPage
                            Box(
                                Modifier
                                    .size(if (selected) 7.dp else 6.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = if (selected) 1f else 0.45f)),
                            )
                        }
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(cols),
                    state = gridState,
                    modifier = Modifier
                        .fillMaxSize()
                        .nestedScroll(connection),
                    contentPadding = PaddingValues(
                        start = startPad,
                        end = endPad,
                        top = topPad,
                        bottom = 24.dp,
                    ),
                ) {
                    itemsIndexed(shown, key = { _, e -> e.key }) { index, entry ->
                        DrawerCell(entry, index, Modifier.fillMaxWidth().height(cellH))
                    }

                    if (q.isNotEmpty()) {
                        if (contacts.isNotEmpty()) {
                            item(key = "h:contacts", span = { GridItemSpan(maxLineSpan) }) {
                                SectionHeader("Contactos")
                            }
                            items(
                                contacts,
                                key = { c -> "c:" + c.uri.toString() },
                                span = { GridItemSpan(maxLineSpan) },
                            ) { c ->
                                ResultRow(c.name) { context.openContact(c.uri) }
                            }
                        }
                        if (settingMatches.isNotEmpty()) {
                            item(key = "h:settings", span = { GridItemSpan(maxLineSpan) }) {
                                SectionHeader("Ajustes")
                            }
                            items(
                                settingMatches,
                                key = { s -> "s:" + s.action },
                                span = { GridItemSpan(maxLineSpan) },
                            ) { s ->
                                ResultRow(s.title) { context.openSettingAction(s.action) }
                            }
                        }
                        item(key = "h:web", span = { GridItemSpan(maxLineSpan) }) {
                            SectionHeader("Web")
                        }
                        item(key = "web", span = { GridItemSpan(maxLineSpan) }) {
                            ResultRow("Buscar «$q» en la web") { context.webSearch(q) }
                        }
                    }
                }
            }

            if (showScroller) {
                AlphabetScroller(
                    letters = firstIndex.keys.toList(),
                    onSelect = { c ->
                        val idx = firstIndex[c]
                        if (idx != null) {
                            scope.launch {
                                if (usePaged) pagerState.scrollToPage(idx / perPage) else gridState.scrollToItem(idx)
                            }
                        }
                    },
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(vertical = 8.dp),
                )
            }

            // Icono flotante mientras se arrastra
            val draggedKey = dd.dragKey
            if (draggedKey != null) {
                val dEntry = shown.firstOrNull { it.key == draggedKey }
                if (dEntry != null) {
                    val floatSize = iconSize * 1.15f
                    val floatPx = with(density) { floatSize.toPx() }
                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (dd.pointer.x - dd.areaRect.left - floatPx / 2f).roundToInt(),
                                    (dd.pointer.y - dd.areaRect.top - floatPx / 2f).roundToInt(),
                                )
                            }
                            .size(floatSize),
                    ) {
                        when (dEntry) {
                            is AppEntry -> Image(
                                bitmap = dEntry.app.icon,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(floatSize)
                                    .clip(shape),
                            )
                            is FolderEntry -> FolderIcon(apps = dEntry.apps, size = floatSize, shape = shape)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.navigationBarsPadding())
    }

        // Carpeta abierta del cajón
        val openF = openFolderId?.let { id -> vm.drawerFolders.firstOrNull { it.id == id } }
        if (openF != null) {
            FolderOverlay(
                folder = HomeItem(
                    id = openF.id,
                    type = ItemType.FOLDER,
                    page = 0,
                    row = 0,
                    col = 0,
                    title = openF.name,
                    children = openF.keys,
                ),
                apps = openF.keys.mapNotNull { k -> all.firstOrNull { it.key == k } },
                originLocal = folderCenter - drawerOrigin,
                iconSize = iconSize,
                shape = shape,
                onRename = { vm.renameDrawerFolder(openF.id, it) },
                onOpenApp = {
                    openFolderId = null
                    onOpen(it, null)
                },
                onTakeOut = { vm.removeFromDrawerFolder(openF.id, it.key) },
                onEdit = onEdit,
                onInfo = onInfo,
                onUninstall = onUninstall,
                onClose = { openFolderId = null },
            )
        }
    }
}

/** Tras mantener el dedo 450 ms sobre una app, soltar otra encima crea una carpeta en vez de reordenar. */
@Composable
private fun DrawerMergeTimer(dd: DrawerDrag) {
    val idx = dd.hoverIndex
    val key = dd.dragKey
    LaunchedEffect(idx, key) {
        dd.mergeReady = false
        if (idx >= 0 && key != null) {
            delay(450)
            dd.mergeReady = true
        }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        color = Color(0xFF8AB4FF),
        fontSize = 13.sp,
        modifier = Modifier.padding(start = 12.dp, top = 16.dp, bottom = 4.dp),
    )
}

@Composable
private fun ResultRow(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 16.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
    )
}

/** Barra de letras al borde derecho: tocar o arrastrar salta a esa letra. */
@Composable
private fun AlphabetScroller(
    letters: List<Char>,
    onSelect: (Char) -> Unit,
    modifier: Modifier = Modifier,
) {
    var heightPx by remember { mutableIntStateOf(1) }
    var active by remember { mutableStateOf<Char?>(null) }

    fun pick(y: Float) {
        if (letters.isEmpty()) return
        val i = (y / heightPx * letters.size).toInt().coerceIn(0, letters.size - 1)
        val c = letters[i]
        if (c != active) {
            active = c
            onSelect(c)
        }
    }

    Column(
        modifier = modifier
            .width(24.dp)
            .fillMaxHeight()
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pointerInput(letters) {
                detectDragGestures(
                    onDragStart = { pick(it.y) },
                    onDrag = { change, _ ->
                        change.consume()
                        pick(change.position.y)
                    },
                    onDragEnd = { active = null },
                    onDragCancel = { active = null },
                )
            }
            .pointerInput(letters) {
                detectTapGestures(
                    onPress = { offset ->
                        pick(offset.y)
                        tryAwaitRelease()
                        active = null
                    },
                )
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        letters.forEach { c ->
            Text(
                text = c.toString(),
                fontSize = 10.sp,
                color = if (c == active) Color(0xFF8AB4FF) else Color.White.copy(alpha = 0.7f),
            )
        }
    }
}

@Composable
private fun SearchField(
    query: String,
    onChange: (String) -> Unit,
    focusRequester: FocusRequester,
    onSearch: () -> Unit,
) {
    BasicTextField(
        value = query,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
        cursorBrush = SolidColor(Color.White),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .focusRequester(focusRequester),
        decorationBox = { inner ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color.White.copy(alpha = 0.16f))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.size(22.dp),
                )
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text(
                            text = "Buscar apps, contactos, ajustes y web",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 16.sp,
                        )
                    }
                    inner()
                }
            }
        },
    )
}
