package com.marcos.ultralauncher.ui

import android.os.SystemClock
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marcos.ultralauncher.AppInfo

data class MenuAction(val label: String, val action: () -> Unit)

internal val LabelStyle = TextStyle(
    color = Color.White,
    fontSize = 12.sp,
    textAlign = TextAlign.Center,
    shadow = Shadow(color = Color.Black.copy(alpha = 0.45f), offset = Offset(0f, 2f), blurRadius = 6f),
)

/**
 * Icono de app para el cajón (y para las carpetas abiertas): tocar abre la app y mantener
 * pulsado muestra el menú. Si se le pasa [reorder], mantener pulsado y arrastrar permite
 * reordenar (y mantener pulsado sin mover abre el menú).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppInfo,
    showLabel: Boolean,
    menu: () -> List<MenuAction>,
    onClick: (Offset) -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = 56.dp,
    shape: Shape = SquircleShape,
    badge: Int = 0,
    reorder: ReorderHandle? = null,
    highlight: Boolean = false,
    dimmed: Boolean = false,
) {
    var menuOpen by remember { mutableStateOf(false) }
    var coords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.9f else 1f,
        label = "iconPress",
    )
    val suppressUntil = remember { LongArray(1) }
    val moved = remember { BooleanArray(1) }
    val startRoot = remember { FloatArray(2) }
    val currentReorder by rememberUpdatedState(reorder)
    val currentClick by rememberUpdatedState(onClick)
    val haptics = LocalHapticFeedback.current

    fun center(): Offset = try {
        coords?.boundsInRoot()?.center ?: Offset.Zero
    } catch (e: Exception) {
        Offset.Zero
    }

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val limit = maxWidth * 0.86f
        val size = if (iconSize < limit) iconSize else limit

        val gestures: Modifier = if (reorder != null) {
            Modifier
                .clickable(interactionSource = interaction, indication = null) {
                    if (SystemClock.uptimeMillis() >= suppressUntil[0]) currentClick(center())
                }
                .pointerInput(app.key) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { offset ->
                            suppressUntil[0] = Long.MAX_VALUE
                            moved[0] = false
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            val root = coords?.localToRoot(offset) ?: Offset.Zero
                            startRoot[0] = root.x
                            startRoot[1] = root.y
                            currentReorder?.onStart?.invoke(root)
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val c = coords
                            if (c != null) {
                                val root = c.localToRoot(change.position)
                                if ((root - Offset(startRoot[0], startRoot[1])).getDistance() > 14f) moved[0] = true
                                currentReorder?.onMove?.invoke(root)
                            }
                        },
                        onDragEnd = {
                            suppressUntil[0] = SystemClock.uptimeMillis() + 350L
                            currentReorder?.onEnd?.invoke(moved[0])
                            if (!moved[0]) menuOpen = true
                        },
                        onDragCancel = {
                            suppressUntil[0] = SystemClock.uptimeMillis() + 350L
                            currentReorder?.onCancel?.invoke()
                        },
                    )
                }
        } else {
            Modifier.combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = { currentClick(center()) },
                onLongClick = { menuOpen = true },
            )
        }

        Column(
            modifier = Modifier
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    alpha = if (dimmed) 0.25f else 1f
                }
                .onGloballyPositioned { coords = it }
                .semantics {
                    customActions = listOf(CustomAccessibilityAction("Más opciones") {
                        menuOpen = true
                        true
                    })
                }
                .then(gestures)
                .background(
                    if (highlight) Color.White.copy(alpha = 0.22f) else Color.Transparent,
                    RoundedCornerShape(18.dp),
                )
                .padding(horizontal = 2.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(size)) {
                Image(
                    bitmap = app.icon,
                    contentDescription = if (showLabel) null else app.label,
                    modifier = Modifier
                        .size(size)
                        .clip(shape),
                )
                if (badge > 0) BadgeDot(badge, Modifier.align(Alignment.TopEnd))
            }
            if (showLabel) {
                Spacer(Modifier.height(5.dp))
                Text(
                    text = app.label,
                    style = LabelStyle,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        DropdownMenu(
            expanded = menuOpen,
            onDismissRequest = { menuOpen = false },
        ) {
            val entries = remember(menuOpen) { if (menuOpen) menu() else emptyList() }
            entries.forEach { item ->
                DropdownMenuItem(
                    text = { Text(item.label) },
                    onClick = {
                        menuOpen = false
                        item.action()
                    },
                )
            }
        }
    }
}

/** Insignia roja con la cantidad de notificaciones de la app. */
@Composable
fun BadgeDot(count: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(18.dp)
            .clip(CircleShape)
            .background(Color(0xFFFF5252)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (count > 9) "9+" else count.toString(),
            color = Color.White,
            fontSize = 10.sp,
        )
    }
}
