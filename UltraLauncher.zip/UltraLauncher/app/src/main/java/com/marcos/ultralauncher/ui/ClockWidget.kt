package com.marcos.ultralauncher.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.text.format.DateFormat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.marcos.ultralauncher.ClockPerson
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

private val TextShadow = Shadow(
    color = Color.Black.copy(alpha = 0.35f),
    offset = Offset(0f, 2f),
    blurRadius = 8f,
)

private fun personLine(
    person: ClockPerson,
    now: Instant,
    local: ZonedDateTime,
    fmt: DateTimeFormatter,
): String {
    val z = now.atZone(person.zone)
    val diff = ChronoUnit.DAYS.between(local.toLocalDate(), z.toLocalDate())
    val day = when {
        diff < 0 -> " (ayer)"
        diff > 0 -> " (mañana)"
        else -> ""
    }
    return "Hora de ${person.displayName} · ${person.country} · ${z.format(fmt)}$day"
}

/** Hora actual, actualizada cada minuto y al cambiar la hora, la zona o prender la pantalla. */
@Composable
private fun rememberNow(): Instant {
    val context = LocalContext.current
    var now by remember { mutableStateOf(Instant.now()) }
    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                now = Instant.now()
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        now = Instant.now()
        onDispose {
            try {
                context.unregisterReceiver(receiver)
            } catch (e: Exception) {
            }
        }
    }
    return now
}

/**
 * Reloj grande del inicio (hora y fecha). Es un bloque del inicio: se puede mover, redimensionar
 * (el texto crece o se achica con el tamaño) y quitar. Se vuelve a agregar desde "Widgets".
 */
@Composable
fun ClockBlock(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val now = rememberNow()
    val locale = Locale.getDefault()
    val is24 = DateFormat.is24HourFormat(context)
    val local = now.atZone(ZoneId.systemDefault())
    val timeFmt = DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm", locale)
    val dateFmt = DateTimeFormatter.ofPattern("EEE, d MMM", locale)

    BoxWithConstraints(modifier = modifier) {
        val timeSp = minOf(maxHeight.value * 0.42f, maxWidth.value / 3.1f).coerceAtLeast(18f)
        val dateSp = (timeSp * 0.21f).coerceIn(11f, 22f)
        Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
            Text(
                text = local.format(timeFmt),
                style = TextStyle(
                    color = Color.White,
                    fontSize = timeSp.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = (-timeSp * 0.026f).sp,
                    shadow = TextShadow,
                ),
                maxLines = 1,
            )
            Text(
                text = local.format(dateFmt),
                style = TextStyle(
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = dateSp.sp,
                    fontWeight = FontWeight.Medium,
                    shadow = TextShadow,
                ),
                maxLines = 1,
            )
        }
    }
}

/** Versión corta para ponerlos a los dos en la misma línea: "Marcos 10:45". */
private fun shortLine(person: ClockPerson, now: Instant, local: ZonedDateTime, fmt: DateTimeFormatter): String {
    val z = now.atZone(person.zone)
    val diff = ChronoUnit.DAYS.between(local.toLocalDate(), z.toLocalDate())
    val day = when {
        diff < 0 -> " (ayer)"
        diff > 0 -> " (mañana)"
        else -> ""
    }
    return person.displayName + " " + z.format(fmt) + day
}

/**
 * Hora de Marcos (Argentina) y/o de Arianna (Ecuador) como bloque del inicio, "de corrido": siempre
 * en una sola línea, con la letra ajustada al ancho del bloque. Tocá para elegir Marcos, Arianna
 * o los dos juntos.
 */
@Composable
fun PersonBlock(
    person: ClockPerson,
    both: Boolean,
    onPersonSelected: (ClockPerson) -> Unit,
    onBothSelected: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val now = rememberNow()
    var menuOpen by remember { mutableStateOf(false) }
    val locale = Locale.getDefault()
    val is24 = DateFormat.is24HourFormat(context)
    val local = now.atZone(ZoneId.systemDefault())
    val otherFmt = DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a", locale)
    val text = if (both) {
        ClockPerson.entries.joinToString("  ·  ") { shortLine(it, now, local, otherFmt) }
    } else {
        personLine(person, now, local, otherFmt)
    }

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.CenterStart) {
        // La letra se achica o crece para que todo entre en una línea.
        val heightSp = maxHeight.value * 0.30f
        val widthSp = (maxWidth.value - 44f) / ((text.length + 2) * 0.52f)
        val sp = minOf(heightSp, widthSp).coerceIn(9f, 26f)
        Box {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { menuOpen = true }
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = text,
                    style = TextStyle(
                        color = Color.White.copy(alpha = 0.95f),
                        fontSize = sp.sp,
                        shadow = TextShadow,
                    ),
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Text(
                    text = " ▾",
                    style = TextStyle(
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = sp.sp,
                        shadow = TextShadow,
                    ),
                    maxLines = 1,
                )
            }

            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false },
            ) {
                ClockPerson.entries.forEach { p ->
                    val mark = if (!both && p == person) "✓  " else ""
                    DropdownMenuItem(
                        text = { Text(mark + personLine(p, now, local, otherFmt)) },
                        onClick = {
                            menuOpen = false
                            onPersonSelected(p)
                        },
                    )
                }
                DropdownMenuItem(
                    text = { Text((if (both) "✓  " else "") + "Los dos, en la misma línea") },
                    onClick = {
                        menuOpen = false
                        onBothSelected()
                    },
                )
            }
        }
    }
}
