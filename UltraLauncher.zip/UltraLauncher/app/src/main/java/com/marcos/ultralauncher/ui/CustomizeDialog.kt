package com.marcos.ultralauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.marcos.ultralauncher.DrawerSort
import com.marcos.ultralauncher.IconShapeOption
import com.marcos.ultralauncher.hasNotificationAccess
import com.marcos.ultralauncher.openNotificationAccessSettings
import com.marcos.ultralauncher.UiSettings
import kotlin.math.roundToInt

/** Panel de personalización: los cambios se ven al instante y se guardan solos. */
@Composable
fun CustomizeDialog(
    settings: UiSettings,
    hiddenCount: Int,
    onChange: (UiSettings) -> Unit,
    onOpenHidden: () -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF26262B),
            contentColor = Color.White,
        ) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 20.dp),
            ) {
                Text("Personalizar", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))

                SectionLabel("Tamaño de iconos: ${settings.iconDp.roundToInt()}")
                Slider(
                    value = settings.iconDp,
                    onValueChange = { onChange(settings.copy(iconDp = it)) },
                    valueRange = 40f..80f,
                )

                SectionLabel("Columnas en inicio")
                Choices(listOf("4", "5", "6"), settings.columns - 4) {
                    onChange(settings.copy(columns = it + 4))
                }

                SectionLabel("Columnas en el cajón de apps")
                Choices(listOf("4", "5", "6"), settings.drawerColumns - 4) {
                    onChange(settings.copy(drawerColumns = it + 4))
                }

                SectionLabel("Forma de los iconos")
                val shapes = IconShapeOption.entries
                Choices(shapes.map { it.label }, shapes.indexOf(settings.shape)) {
                    onChange(settings.copy(shape = shapes[it]))
                }

                SectionLabel("Opacidad del dock: ${(settings.dockAlpha / 0.6f * 100).roundToInt()}%")
                Slider(
                    value = settings.dockAlpha,
                    onValueChange = { onChange(settings.copy(dockAlpha = it)) },
                    valueRange = 0f..0.6f,
                )

                SectionLabel("Orden del cajón de apps")
                val sorts = DrawerSort.entries
                Choices(sorts.map { it.label }, sorts.indexOf(settings.drawerSort)) {
                    onChange(settings.copy(drawerSort = sorts[it]))
                }

                ToggleRow("Categorías arriba del cajón", settings.drawerCategories) {
                    onChange(settings.copy(drawerCategories = it))
                }
                ToggleRow("Barra de búsqueda sobre el dock", settings.showSearchBar) {
                    onChange(settings.copy(showSearchBar = it))
                }
                ToggleRow("Iconos temáticos (Android 13+)", settings.themedIcons) {
                    onChange(settings.copy(themedIcons = it))
                }
                ToggleRow("Insignias de notificación", settings.showBadges) {
                    if (it && !context.hasNotificationAccess()) context.openNotificationAccessSettings()
                    onChange(settings.copy(showBadges = it))
                }
                TextButton(onClick = onOpenHidden) {
                    Text(if (hiddenCount > 0) "Apps ocultas ($hiddenCount)" else "Apps ocultas")
                }

                ToggleRow("Mostrar nombres de las apps", settings.showLabels) {
                    onChange(settings.copy(showLabels = it))
                }
                ToggleRow("Mostrar reloj en inicio", settings.showClock) {
                    onChange(settings.copy(showClock = it))
                }
                ToggleRow("Bloquear layout (evita mover por accidente)", settings.layoutLocked) {
                    onChange(settings.copy(layoutLocked = it))
                }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    TextButton(onClick = { onChange(UiSettings(layoutLocked = settings.layoutLocked)) }) { Text("Restablecer") }
                    TextButton(onClick = onDismiss) { Text("Listo") }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = Color.White.copy(alpha = 0.7f),
        fontSize = 13.sp,
        modifier = Modifier.padding(top = 14.dp, bottom = 2.dp),
    )
}

@Composable
private fun Choices(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        labels.forEachIndexed { i, text ->
            val isSelected = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isSelected) Color(0xFF8AB4FF) else Color.White.copy(alpha = 0.12f))
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = text,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = if (isSelected) Color.Black else Color.White,
                )
            }
        }
    }
}

@Composable
private fun ToggleRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
