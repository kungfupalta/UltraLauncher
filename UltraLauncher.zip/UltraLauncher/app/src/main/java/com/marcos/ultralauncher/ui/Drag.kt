package com.marcos.ultralauncher.ui

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import com.marcos.ultralauncher.DOCK_PAGE
import com.marcos.ultralauncher.DOCK_SLOTS
import com.marcos.ultralauncher.HomeItem
import com.marcos.ultralauncher.ItemType
import kotlin.math.floor
import kotlin.math.roundToInt

/** Celda de destino: (página, fila, columna). El dock es la página [DOCK_PAGE]. */
data class Cell(val page: Int, val row: Int, val col: Int)

/**
 * Estado del arrastre de un elemento (app, carpeta o widget). Las posiciones están en coordenadas
 * de la raíz. La celda de destino se calcula con la geometría de la cuadrícula (no con rectángulos
 * registrados por cada celda), así también funciona sobre celdas vacías.
 */
@Stable
class DragController {
    var item by mutableStateOf<HomeItem?>(null)
        private set
    var pointer by mutableStateOf(Offset.Zero)
        private set
    var overTrash by mutableStateOf(false)
        private set
    var hover by mutableStateOf<Cell?>(null)
        private set

    /** Se activa tras mantener el dedo sobre la misma celda: soltar crea una carpeta. */
    var mergeReady by mutableStateOf(false)

    var startPointer: Offset = Offset.Zero
        private set

    /** Dónde se agarró el elemento (relativo a su esquina superior izquierda). Para widgets. */
    var grab: Offset = Offset.Zero
        private set

    val active: Boolean get() = item != null

    // Geometría: la actualiza HomeScreen en cada composición.
    var trashRect: Rect = Rect.Zero
    var gridRect: Rect = Rect.Zero
    var dockRect: Rect = Rect.Zero
    var columns: Int = 4
    var rowsFirst: Int = 1
    var rowsOther: Int = 1
    var cellWPx: Float = 0f
    var cellHPx: Float = 0f
    var hPadPx: Float = 0f
    var clockPx: Float = 0f
    var dockPadPx: Float = 0f
    var currentPage: Int = 0

    private fun rowsOf(page: Int): Int = if (page == 0) rowsFirst else rowsOther

    fun begin(item: HomeItem, at: Offset, grab: Offset = Offset.Zero) {
        this.item = item
        this.startPointer = at
        this.grab = grab
        mergeReady = false
        update(at)
    }

    fun update(p: Offset) {
        pointer = p
        overTrash = trashRect.contains(p)
        hover = if (overTrash) null else computeHover(p)
    }

    fun cancel() {
        item = null
        overTrash = false
        hover = null
        mergeReady = false
    }

    private fun computeHover(p: Offset): Cell? {
        val dragged = item ?: return null
        if (cellWPx <= 0f || cellHPx <= 0f) return null
        val left = gridRect.left + hPadPx
        val top = gridRect.top + (if (currentPage == 0) clockPx else 0f)
        val rows = rowsOf(currentPage)

        if (dragged.type == ItemType.WIDGET) {
            if (!gridRect.contains(p)) return null
            val tlx = p.x - grab.x
            val tly = p.y - grab.y
            val maxCol = (columns - dragged.spanCols).coerceAtLeast(0)
            val maxRow = (rows - dragged.spanRows).coerceAtLeast(0)
            val col = ((tlx - left) / cellWPx).roundToInt().coerceIn(0, maxCol)
            val row = ((tly - top) / cellHPx).roundToInt().coerceIn(0, maxRow)
            return Cell(currentPage, row, col)
        }

        if (dockRect.contains(p)) {
            val slotW = (dockRect.width - 2f * dockPadPx) / DOCK_SLOTS
            if (slotW <= 0f) return null
            val idx = ((p.x - dockRect.left - dockPadPx) / slotW).toInt().coerceIn(0, DOCK_SLOTS - 1)
            return Cell(DOCK_PAGE, 0, idx)
        }

        if (!gridRect.contains(p)) return null
        val c = floor((p.x - left) / cellWPx).toInt()
        val r = floor((p.y - top) / cellHPx).toInt()
        return if (c in 0 until columns && r in 0 until rows) Cell(currentPage, r, c) else null
    }
}
