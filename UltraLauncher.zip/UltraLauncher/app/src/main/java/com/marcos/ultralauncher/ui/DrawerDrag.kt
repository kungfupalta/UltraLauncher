package com.marcos.ultralauncher.ui

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import kotlin.math.floor

/** Lo que un icono del cajón avisa cuando se lo arrastra para reordenar. */
class ReorderHandle(
    val onStart: (Offset) -> Unit,
    val onMove: (Offset) -> Unit,
    /** [moved] = true si se arrastró de verdad (si no, solo fue una pulsación larga). */
    val onEnd: (Boolean) -> Unit,
    val onCancel: () -> Unit,
)

/**
 * Estado del arrastre para ordenar el cajón. La celda de destino se calcula con la geometría de
 * la grilla (columnas, alto de celda, desplazamiento), igual en lista vertical y en páginas.
 */
@Stable
class DrawerDrag {
    var dragKey by mutableStateOf<String?>(null)
        private set
    var pointer by mutableStateOf(Offset.Zero)
        private set

    /** Posición (en la lista mostrada) sobre la que está el dedo; -1 si ninguna. */
    var hoverIndex by mutableIntStateOf(-1)
        private set

    val active: Boolean get() = dragKey != null

    // Geometría: la actualiza AppDrawer en cada composición.
    var areaRect: Rect = Rect.Zero
    var paged: Boolean = false
    var columns: Int = 4
    var rows: Int = 1
    var itemCount: Int = 0
    var startPadPx: Float = 0f
    var topPadPx: Float = 0f
    var cellWPx: Float = 0f
    var cellHPx: Float = 0f

    /** Desplazamiento vertical del contenido (solo en modo lista). */
    var scrollProvider: () -> Float = { 0f }

    /** Página actual (solo en modo páginas). */
    var pageProvider: () -> Int = { 0 }

    fun begin(key: String, at: Offset) {
        dragKey = key
        update(at)
    }

    fun update(p: Offset) {
        pointer = p
        hoverIndex = indexAt(p)
    }

    fun cancel() {
        dragKey = null
        hoverIndex = -1
    }

    private fun indexAt(p: Offset): Int {
        if (cellWPx <= 0f || cellHPx <= 0f || !areaRect.contains(p)) return -1
        val col = floor((p.x - areaRect.left - startPadPx) / cellWPx).toInt()
        if (col !in 0 until columns) return -1
        val index: Int
        if (paged) {
            val row = floor((p.y - areaRect.top - topPadPx) / cellHPx).toInt()
            if (row !in 0 until rows) return -1
            index = pageProvider() * (columns * rows) + row * columns + col
        } else {
            val row = floor((p.y - areaRect.top - topPadPx + scrollProvider()) / cellHPx).toInt()
            if (row < 0) return -1
            index = row * columns + col
        }
        return if (index in 0 until itemCount) index else -1
    }
}
