package com.marcos.ultralauncher.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.marcos.ultralauncher.ClockPerson

/** Menú que aparece al mantener pulsado un espacio vacío del inicio. */
@Composable
fun EditMenuDialog(
    person: ClockPerson,
    onPersonSelected: (ClockPerson) -> Unit,
    locked: Boolean,
    onToggleLock: () -> Unit,
    onWidgets: () -> Unit,
    onCustomize: () -> Unit,
    onWallpaper: () -> Unit,
    onSettings: () -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF26262B),
            contentColor = Color.White,
        ) {
            Column(Modifier.padding(vertical = 12.dp)) {
                MenuRow("Personalizar", onCustomize)
                MenuRow("Widgets", onWidgets)
                MenuRow(if (locked) "Desbloquear layout" else "Bloquear layout", onToggleLock)
                MenuRow("Fondos de pantalla", onWallpaper)

                Text(
                    text = "Hora debajo del reloj",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 14.dp, bottom = 2.dp),
                )
                ClockPerson.entries.forEach { p ->
                    val mark = if (p == person) "✓  " else "      "
                    MenuRow("${mark}Hora de ${p.displayName} (${p.country})") {
                        onPersonSelected(p)
                        onDismiss()
                    }
                }

                MenuRow("Ajustes del sistema", onSettings)
            }
        }
    }
}

@Composable
private fun MenuRow(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 16.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
    )
}
