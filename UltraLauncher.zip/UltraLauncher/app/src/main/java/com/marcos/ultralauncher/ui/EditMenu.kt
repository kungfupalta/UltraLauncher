package com.marcos.ultralauncher.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/** Menú que aparece al mantener pulsado un espacio vacío del inicio. */
@Composable
fun EditMenuDialog(
    locked: Boolean,
    onToggleLock: () -> Unit,
    onWidgets: () -> Unit,
    onCustomize: () -> Unit,
    onWallpaper: () -> Unit,
    onSettings: () -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ) {
            Column(Modifier.padding(vertical = 12.dp)) {
                MenuRow("Personalizar", onCustomize)
                MenuRow("Widgets", onWidgets)
                MenuRow(if (locked) "Desbloquear layout" else "Bloquear layout", onToggleLock)
                MenuRow("Fondos de pantalla", onWallpaper)

                MenuRow("Ajustes del sistema", onSettings)
            }
        }
    }
}

@Composable
private fun MenuRow(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        fontSize = 16.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
    )
}
