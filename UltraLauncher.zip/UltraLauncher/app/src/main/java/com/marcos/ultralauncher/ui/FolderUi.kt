package com.marcos.ultralauncher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.HomeItem
import kotlinx.coroutines.launch

/** Icono de carpeta: una placa translúcida con hasta 4 mini iconos. */
@Composable
fun FolderIcon(
    apps: List<AppInfo>,
    size: Dp,
    shape: Shape,
    modifier: Modifier = Modifier,
) {
    val mini = size * 0.40f
    val gap = size * 0.06f
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.24f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            for (r in 0 until 2) {
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    for (c in 0 until 2) {
                        val app = apps.getOrNull(r * 2 + c)
                        if (app != null) {
                            Image(
                                bitmap = app.icon,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(mini)
                                    .clip(RoundedCornerShape(percent = 28)),
                            )
                        } else {
                            Spacer(Modifier.size(mini))
                        }
                    }
                }
            }
        }
    }
}

/**
 * Carpeta abierta: aparece creciendo desde el icono ([originLocal], en coordenadas de esta
 * pantalla) y se cierra al tocar fuera o con "atrás". El nombre se edita tocándolo.
 */
@Composable
fun FolderOverlay(
    folder: HomeItem,
    apps: List<AppInfo>,
    originLocal: Offset,
    iconSize: Dp,
    shape: Shape,
    onRename: (String) -> Unit,
    onOpenApp: (AppInfo) -> Unit,
    onTakeOut: (AppInfo) -> Unit,
    onEdit: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onClose: () -> Unit,
) {
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var closing by remember { mutableStateOf(false) }
    var title by remember(folder.id) { mutableStateOf(folder.title) }

    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(durationMillis = 220, easing = FastOutSlowInEasing))
    }

    fun close() {
        if (closing) return
        closing = true
        scope.launch {
            progress.animateTo(0f, tween(durationMillis = 180))
            onClose()
        }
    }

    BackHandler(enabled = true) { close() }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val h = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val pivot = TransformOrigin(
            (originLocal.x / w).coerceIn(0f, 1f),
            (originLocal.y / h).coerceIn(0f, 1f),
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val s = 0.35f + 0.65f * progress.value
                    scaleX = s
                    scaleY = s
                    alpha = progress.value
                    transformOrigin = pivot
                }
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                ) { close() },
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 24.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .background(Color(0xF0222226))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { }
                    .padding(horizontal = 16.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                BasicTextField(
                    value = title,
                    onValueChange = { v ->
                        val t = v.take(24)
                        title = t
                        onRename(t)
                    },
                    singleLine = true,
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = 20.sp,
                        textAlign = TextAlign.Center,
                    ),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.Center) {
                            if (title.isEmpty()) {
                                Text("Carpeta", color = Color.White.copy(alpha = 0.5f), fontSize = 20.sp)
                            }
                            inner()
                        }
                    },
                )
                Spacer(Modifier.height(12.dp))
                Column(
                    Modifier
                        .heightIn(max = 400.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    apps.chunked(3).forEach { rowApps ->
                        Row(Modifier.fillMaxWidth()) {
                            rowApps.forEach { app ->
                                AppIcon(
                                    app = app,
                                    showLabel = true,
                                    iconSize = iconSize,
                                    shape = shape,
                                    onClick = { _ -> onOpenApp(app) },
                                    menu = {
                                        listOf(
                                            MenuAction("Sacar de la carpeta") { onTakeOut(app) },
                                            MenuAction("Nombre e icono") { onEdit(app) },
                                            MenuAction("Info de la app") { onInfo(app) },
                                            MenuAction("Desinstalar") { onUninstall(app) },
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(iconSize + 40.dp),
                                )
                            }
                            repeat(3 - rowApps.size) {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}
