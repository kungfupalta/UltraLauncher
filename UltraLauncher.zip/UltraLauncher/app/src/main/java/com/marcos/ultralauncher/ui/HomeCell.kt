package com.marcos.ultralauncher.ui

import android.os.SystemClock
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.marcos.ultralauncher.HomeItem

private class CoordsHolder {
    var coords: LayoutCoordinates? = null
}

private fun centerOf(holder: CoordsHolder): Offset =
    try {
        holder.coords?.boundsInRoot()?.center ?: Offset.Zero
    } catch (e: Exception) {
        Offset.Zero
    }

/**
 * Celda del inicio o del dock (app o carpeta). Mantener pulsado y arrastrar mueve el elemento;
 * mantener pulsado sin mover abre el menú. Con el layout bloqueado ([locked]) no se arrastra:
 * mantener pulsado solo abre el menú.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeCell(
    item: HomeItem,
    label: String,
    showLabel: Boolean,
    menu: () -> List<MenuAction>,
    onClick: (Offset) -> Unit,
    drag: DragController,
    locked: Boolean,
    iconSize: Dp,
    onDrop: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable (Dp) -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.9f else 1f,
        label = "cellPress",
    )
    val holder = remember { CoordsHolder() }
    val suppressUntil = remember { LongArray(1) }
    val moved = remember { BooleanArray(1) }
    val currentItem by rememberUpdatedState(item)
    val currentOnDrop by rememberUpdatedState(onDrop)
    val currentOnClick by rememberUpdatedState(onClick)
    val haptics = LocalHapticFeedback.current

    // ¿Es esta la celda sobre la que está el dedo mientras se arrastra?
    val isTarget by remember(item.id, item.page, item.row, item.col) {
        derivedStateOf {
            val h = drag.hover
            h != null && h.page == item.page && h.row == item.row && h.col == item.col &&
                drag.item?.id != item.id
        }
    }
    val mergeHot = isTarget && drag.mergeReady

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val limit = maxWidth * 0.86f
        val size = if (iconSize < limit) iconSize else limit

        val gestures: Modifier = if (!locked) {
            Modifier
                .clickable(interactionSource = interaction, indication = null) {
                    if (SystemClock.uptimeMillis() >= suppressUntil[0]) currentOnClick(centerOf(holder))
                }
                .pointerInput(item.id, locked) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { offset ->
                            suppressUntil[0] = Long.MAX_VALUE
                            moved[0] = false
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            val root = holder.coords?.localToRoot(offset) ?: Offset.Zero
                            drag.begin(currentItem, root)
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val c = holder.coords
                            if (c != null) {
                                val root = c.localToRoot(change.position)
                                if ((root - drag.startPointer).getDistance() > 14f) moved[0] = true
                                drag.update(root)
                            }
                        },
                        onDragEnd = {
                            suppressUntil[0] = SystemClock.uptimeMillis() + 350L
                            if (moved[0]) {
                                currentOnDrop()
                            } else {
                                drag.cancel()
                                menuOpen = true
                            }
                        },
                        onDragCancel = {
                            suppressUntil[0] = SystemClock.uptimeMillis() + 350L
                            drag.cancel()
                        },
                    )
                }
        } else {
            Modifier.combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = { currentOnClick(centerOf(holder)) },
                onLongClick = { menuOpen = true },
            )
        }

        val highlight = when {
            mergeHot -> Color(0xFF8AB4FF).copy(alpha = 0.40f)
            isTarget -> Color.White.copy(alpha = 0.22f)
            else -> Color.Transparent
        }

        Column(
            modifier = Modifier
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    alpha = if (drag.item?.id == currentItem.id) 0.25f else 1f
                }
                .onGloballyPositioned { c -> holder.coords = c }
                .semantics {
                    customActions = listOf(CustomAccessibilityAction("Más opciones") {
                        menuOpen = true
                        true
                    })
                }
                .then(gestures)
                .background(highlight, RoundedCornerShape(18.dp))
                .padding(horizontal = 2.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            icon(size)
            if (showLabel) {
                Spacer(Modifier.height(5.dp))
                Text(
                    text = label,
                    style = LabelStyle,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        DropdownMenu(
            expanded = menuOpen,
            onDismissRequest = { menuOpen = false },
        ) {
            val entries = remember(menuOpen) { if (menuOpen) menu() else emptyList() }
            entries.forEach { entry ->
                DropdownMenuItem(
                    text = { Text(entry.label) },
                    onClick = {
                        menuOpen = false
                        entry.action()
                    },
                )
            }
        }
    }
}
