package com.marcos.ultralauncher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.BadgeStore
import com.marcos.ultralauncher.SearchBarPos
import com.marcos.ultralauncher.DOCK_PAGE
import com.marcos.ultralauncher.DOCK_SLOTS
import com.marcos.ultralauncher.GridMetrics
import com.marcos.ultralauncher.HomeItem
import com.marcos.ultralauncher.ItemType
import com.marcos.ultralauncher.LauncherViewModel
import kotlinx.coroutines.delay
import kotlin.math.roundToInt


/** En pantallas anchas (tablet, plegado abierto, horizontal) se suman columnas para aprovechar el espacio. */
internal fun adaptiveColumns(base: Int, widthDp: Int): Int =
    (base + ((widthDp - 400) / 200).coerceIn(0, 4)).coerceAtMost(10)

@Composable
fun HomeScreen(
    vm: LauncherViewModel,
    appsByKey: Map<String, AppInfo>,
    onOpen: (AppInfo, Offset?) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onEdit: (AppInfo) -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val drag = remember { DragController() }
    var origin by remember { mutableStateOf(Offset.Zero) }
    var openFolderId by remember { mutableStateOf<String?>(null) }
    var folderCenter by remember { mutableStateOf(Offset.Zero) }
    var editingId by remember { mutableStateOf<String?>(null) }

    val settings = vm.settings
    val shape = settings.shape.toShape()
    val columns = adaptiveColumns(settings.columns, LocalConfiguration.current.screenWidthDp)
    val iconDp = settings.iconDp.dp
    val showLabels = settings.showLabels
    val locked = settings.layoutLocked
    val cellHeight = if (showLabels) iconDp + 40.dp else iconDp + 26.dp

    val homeItems = vm.homeItems
    val dockItems = vm.dockItems
    val maxPage = homeItems.maxOfOrNull { it.page } ?: 0
    // Mientras se arrastra aparece una página vacía extra al final para poder soltar ahí.
    val pageCount = maxPage + 1 + (if (drag.active) 1 else 0)
    val pagerState = rememberPagerState(pageCount = { pageCount })

    // Se llama al soltar: decide a qué celda va el elemento (o si va a la papelera).
    fun finishDrag() {
        val dragged = drag.item
        if (dragged != null) {
            val hover = drag.hover
            if (drag.overTrash) {
                vm.removeItem(dragged.id)
            } else if (hover != null) {
                if (dragged.isBlock) {
                    vm.moveWidget(dragged.id, hover.page, hover.row, hover.col)
                } else {
                    vm.moveItem(
                        dragged.id,
                        hover.page == DOCK_PAGE,
                        hover.page,
                        hover.row,
                        hover.col,
                        drag.mergeReady,
                    )
                }
            }
        }
        drag.cancel()
        editingId = null
    }

    BackHandler(enabled = editingId != null) { editingId = null }

    // Con una carpeta abierta o un bloque en edición, los gestos del inicio (cajón, doble toque...) se ignoran.
    SideEffect { vm.folderOpen = openFolderId != null || editingId != null }

    Box(
        modifier = modifier
            .fillMaxSize()
            // Recortes de pantalla (cámara, bisagra) y barra de navegación lateral en horizontal.
            .windowInsetsPadding(WindowInsets.displayCutout.only(WindowInsetsSides.Horizontal))
            .windowInsetsPadding(WindowInsets.navigationBars.only(WindowInsetsSides.Horizontal))
            .onGloballyPositioned { origin = it.positionInRoot() },
    ) {
        MergeTimer(drag)

        Column(Modifier.fillMaxSize()) {

            val searchPos = settings.searchBar
            if (searchPos == SearchBarPos.TOP) {
                HomeSearchBar(
                    onClick = onSearch,
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }

            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .then(if (searchPos == SearchBarPos.TOP) Modifier else Modifier.statusBarsPadding())
                    .onGloballyPositioned { drag.gridRect = it.boundsInRoot() },
            ) {
                val indicatorSpace = 26.dp
                // El reloj ya no reserva espacio fijo: es un bloque más del inicio.
                val rowsOther = ((maxHeight - indicatorSpace) / cellHeight).toInt().coerceAtLeast(1)
                val rowsFirst = rowsOther
                val cellWDp = (maxWidth - 24.dp).value / columns
                val cellHDp = cellHeight.value

                val widthPx = with(density) { maxWidth.toPx() }
                val hPadPx = with(density) { 12.dp.toPx() }
                SideEffect {
                    drag.columns = columns
                    drag.rowsFirst = rowsFirst
                    drag.rowsOther = rowsOther
                    drag.cellWPx = (widthPx - 2f * hPadPx) / columns
                    drag.cellHPx = with(density) { cellHeight.toPx() }
                    drag.hPadPx = hPadPx
                    drag.clockPx = 0f
                    drag.dockPadPx = with(density) { 6.dp.toPx() }
                    drag.currentPage = pagerState.currentPage
                    vm.currentHomePage = pagerState.currentPage
                }

                LaunchedEffect(columns, rowsFirst, rowsOther, cellWDp, cellHDp) {
                    vm.onGridMetrics(GridMetrics(columns, rowsFirst, rowsOther, cellWDp, cellHDp))
                }

                LaunchedEffect(vm.homeSignal) {
                    if (vm.homeSignal > 0) {
                        openFolderId = null
                        editingId = null
                        pagerState.animateScrollToPage(0)
                    }
                }

                // Al cambiar de página mientras se arrastra, se recalcula la celda de destino.
                LaunchedEffect(pagerState.currentPage) {
                    if (drag.active) drag.update(drag.pointer)
                }

                // Arrastrando hacia el borde izquierdo/derecho cambia de página.
                val edgePx = with(density) { 40.dp.toPx() }
                val edgeDir by remember(edgePx, widthPx) {
                    derivedStateOf {
                        when {
                            !drag.active -> 0
                            drag.pointer.x < edgePx -> -1
                            drag.pointer.x > widthPx - edgePx -> 1
                            else -> 0
                        }
                    }
                }
                LaunchedEffect(edgeDir) {
                    if (edgeDir != 0) {
                        while (true) {
                            delay(650)
                            val target = pagerState.currentPage + edgeDir
                            if (target in 0 until pagerState.pageCount) {
                                pagerState.animateScrollToPage(target)
                            }
                        }
                    }
                }

                HorizontalPager(
                    state = pagerState,
                    beyondViewportPageCount = (pageCount - 1).coerceAtLeast(0),
                    modifier = Modifier.fillMaxSize(),
                ) { page ->
                    val pageItems = remember(homeItems, page) { homeItems.filter { it.page == page } }
                    HomePage(
                        page = page,
                        vm = vm,
                        items = pageItems,
                        appsByKey = appsByKey,
                        drag = drag,
                        shape = shape,
                        columns = columns,
                        rows = if (page == 0) rowsFirst else rowsOther,
                        iconDp = iconDp,
                        cellHeight = cellHeight,
                        showLabels = showLabels,
                        locked = locked,
                        editingId = editingId,
                        onEditing = { editingId = it },
                        onOpenFolder = { folder, center ->
                            folderCenter = center
                            openFolderId = folder.id
                        },
                        onOpen = onOpen,
                        onInfo = onInfo,
                        onUninstall = onUninstall,
                        onEdit = onEdit,
                        onDrop = { finishDrag() },
                    )
                }

                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                ) {
                    repeat(pageCount) { i ->
                        val selected = i == pagerState.currentPage
                        Box(
                            Modifier
                                .size(if (selected) 7.dp else 6.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = if (selected) 1f else 0.45f)),
                        )
                    }
                }
            }

            if (settings.searchBar == SearchBarPos.BOTTOM) {
                HomeSearchBar(
                    onClick = onSearch,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }

            // Dock: 4 huecos
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Row(
                    modifier = Modifier
                        .widthIn(max = 520.dp)
                        .fillMaxWidth()
                        .onGloballyPositioned { drag.dockRect = it.boundsInRoot() }
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color.White.copy(alpha = settings.dockAlpha))
                        .padding(horizontal = 6.dp, vertical = 10.dp),
                ) {
                    for (slot in 0 until DOCK_SLOTS) {
                        val d = dockItems.firstOrNull { it.col == slot }
                        val cellMod = Modifier
                            .weight(1f)
                            .height(iconDp + 8.dp)
                        if (d == null) {
                            DockEmptySlot(slot, drag, cellMod)
                        } else {
                            key(d.id) {
                                ItemCell(
                                    item = d,
                                    vm = vm,
                                    appsByKey = appsByKey,
                                    drag = drag,
                                    shape = shape,
                                    iconDp = iconDp,
                                    showLabel = false,
                                    locked = locked,
                                    onOpenFolder = { folder, center ->
                                        folderCenter = center
                                        openFolderId = folder.id
                                    },
                                    onOpen = onOpen,
                                    onInfo = onInfo,
                                    onUninstall = onUninstall,
                                    onEdit = onEdit,
                                    onDrop = { finishDrag() },
                                    modifier = cellMod,
                                )
                            }
                        }
                    }
                }
            }
        }

        // Papelera + elemento flotante mientras se arrastra
        val dragged = drag.item
        if (dragged != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 14.dp)
                    .onGloballyPositioned { drag.trashRect = it.boundsInRoot().inflate(28f) }
                    .clip(RoundedCornerShape(32.dp))
                    .background(if (drag.overTrash) Color(0xFFE53935) else Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 22.dp, vertical = 14.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = null,
                        tint = Color.White,
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(text = "Quitar", color = Color.White, fontSize = 15.sp)
                }
            }

            if (dragged.isBlock) {
                val wDp = with(density) { (drag.cellWPx * dragged.spanCols).toDp() }
                val hDp = with(density) { (drag.cellHPx * dragged.spanRows).toDp() }
                Box(
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                (drag.pointer.x - drag.grab.x - origin.x).roundToInt(),
                                (drag.pointer.y - drag.grab.y - origin.y).roundToInt(),
                            )
                        }
                        .size(wDp, hDp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color.White.copy(alpha = 0.28f)),
                )
            } else {
                val floatSize = iconDp * 1.15f
                val floatPx = with(density) { floatSize.toPx() }
                Box(
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                (drag.pointer.x - origin.x - floatPx / 2f).roundToInt(),
                                (drag.pointer.y - origin.y - floatPx / 2f).roundToInt(),
                            )
                        }
                        .size(floatSize),
                ) {
                    if (dragged.type == ItemType.FOLDER) {
                        FolderIcon(
                            apps = dragged.children.mapNotNull { appsByKey[it] },
                            size = floatSize,
                            shape = shape,
                        )
                    } else {
                        val app = appsByKey[dragged.appKey ?: ""]
                        if (app != null) {
                            Image(
                                bitmap = app.icon,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(floatSize)
                                    .clip(shape),
                            )
                        }
                    }
                }
            }
        }

        // Carpeta abierta
        val openFolder = openFolderId?.let { id ->
            homeItems.firstOrNull { it.id == id } ?: dockItems.firstOrNull { it.id == id }
        }
        if (openFolder != null && openFolder.type == ItemType.FOLDER) {
            FolderOverlay(
                folder = openFolder,
                apps = openFolder.children.mapNotNull { appsByKey[it] },
                originLocal = folderCenter - origin,
                iconSize = iconDp,
                shape = shape,
                onRename = { vm.renameFolder(openFolder.id, it) },
                onOpenApp = {
                    openFolderId = null
                    onOpen(it, null)
                },
                onTakeOut = { vm.takeOutOfFolder(openFolder.id, it.key) },
                onEdit = onEdit,
                onInfo = onInfo,
                onUninstall = onUninstall,
                onClose = { openFolderId = null },
            )
        }

    }
}

/** Tras mantener el dedo 450 ms sobre una celda, soltar crea una carpeta en lugar de intercambiar. */
@Composable
private fun MergeTimer(drag: DragController) {
    val hover = drag.hover
    val id = drag.item?.id
    LaunchedEffect(hover, id) {
        drag.mergeReady = false
        if (hover != null && id != null) {
            delay(450)
            drag.mergeReady = true
        }
    }
}

@Composable
private fun HomePage(
    page: Int,
    vm: LauncherViewModel,
    items: List<HomeItem>,
    appsByKey: Map<String, AppInfo>,
    drag: DragController,
    shape: Shape,
    columns: Int,
    rows: Int,
    iconDp: Dp,
    cellHeight: Dp,
    showLabels: Boolean,
    locked: Boolean,
    editingId: String?,
    onEditing: (String?) -> Unit,
    onOpenFolder: (HomeItem, Offset) -> Unit,
    onOpen: (AppInfo, Offset?) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onEdit: (AppInfo) -> Unit,
    onDrop: () -> Unit,
) {
    val density = LocalDensity.current
    val haptics = LocalHapticFeedback.current
    var pinch by remember { mutableStateOf<PinchInfo?>(null) }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .height(cellHeight * rows)
                // Tocar un hueco vacío sale del modo edición de widgets.
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { onEditing(null) })
                },
        ) {
            val cellW = maxWidth / columns

            HoverHighlight(page, drag, items, vm, cellW, cellHeight)

            // Vista previa del tamaño mientras se pellizca
            val pv = pinch
            if (pv != null) {
                val base = items.firstOrNull { it.id == pv.itemId }
                if (base != null) {
                    val tint = if (pv.exact) Color(0xFF66BB6A) else Color(0xFFE53935)
                    Box(
                        Modifier
                            .offset(x = cellW * base.col, y = cellHeight * base.row)
                            .size(cellW * pv.c, cellHeight * pv.r)
                            .padding(3.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(tint.copy(alpha = 0.22f))
                            .border(3.dp, tint, RoundedCornerShape(22.dp)),
                    )
                }
            }

            for (item in items) {
                key(item.id) {
                    // Pellizco: cambia columnas/filas con vista previa; se aplica al soltar.
                    val pinchStart: () -> Unit = {
                        pinch = PinchInfo(item.id, item.spanCols, item.spanRows, item.spanCols, item.spanRows, true)
                    }
                    val pinchMove: (Float, Float) -> Unit = { dx, dy ->
                        val lim = vm.widgetLimits(item)
                        val cellWpx = with(density) { cellW.toPx() }
                        val cellHpx = with(density) { cellHeight.toPx() }
                        var c = (item.spanCols + (dx / cellWpx).roundToInt()).coerceIn(lim.minCols, lim.maxCols)
                        var r = (item.spanRows + (dy / cellHpx).roundToInt()).coerceIn(lim.minRows, lim.maxRows)
                        val wantC = c
                        val wantR = r
                        while (!vm.canPlaceWidget(page, item.row, item.col, r, c, item.id) &&
                            (c > item.spanCols || r > item.spanRows)
                        ) {
                            if (c - item.spanCols >= r - item.spanRows && c > item.spanCols) c-- else if (r > item.spanRows) r-- else c--
                        }
                        val cur = pinch
                        if (cur != null && (cur.c != c || cur.r != r)) {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        }
                        pinch = PinchInfo(item.id, item.spanCols, item.spanRows, c, r, c == wantC && r == wantR)
                    }
                    val pinchEnd: () -> Unit = {
                        val p = pinch
                        pinch = null
                        if (p != null && (p.c != item.spanCols || p.r != item.spanRows)) {
                            vm.resizeWidget(item.id, p.c, p.r)
                        }
                    }
                    val resizeStep: (Int) -> Unit = { d ->
                        val lim = vm.widgetLimits(item)
                        vm.resizeWidget(
                            item.id,
                            (item.spanCols + d).coerceIn(lim.minCols, lim.maxCols),
                            (item.spanRows + d).coerceIn(lim.minRows, lim.maxRows),
                        )
                    }
                    if (item.type == ItemType.WIDGET) {
                        WidgetCell(
                            item = item,
                            host = vm.widgetHost,
                            widthDp = cellW.value * item.spanCols,
                            heightDp = cellHeight.value * item.spanRows,
                            locked = locked,
                            editing = editingId == item.id,
                            dragging = drag.item?.id == item.id,
                            canResize = vm.widgetLimits(item).canResize,
                            onTouchActive = { vm.widgetTouchActive = it },
                            onLongPress = { onEditing(item.id) },
                            onExitEdit = { onEditing(null) },
                            onRemove = {
                                onEditing(null)
                                vm.removeItem(item.id)
                            },
                            onResizeStep = resizeStep,
                            onPinchStart = pinchStart,
                            onPinch = pinchMove,
                            onPinchEnd = pinchEnd,
                            onDragStart = { grab, root -> drag.begin(item, root, grab) },
                            onDragMove = { drag.update(it) },
                            onDragEnd = onDrop,
                            onDragCancel = { drag.cancel() },
                            modifier = Modifier
                                .offset(x = cellW * item.col, y = cellHeight * item.row)
                                .size(cellW * item.spanCols, cellHeight * item.spanRows)
                                .padding(4.dp),
                        )
                    } else if (item.type == ItemType.CLOCK || item.type == ItemType.PERSON) {
                        EditableBlock(
                            blockKey = item.id,
                            locked = locked,
                            editing = editingId == item.id,
                            dragging = drag.item?.id == item.id,
                            canResize = vm.widgetLimits(item).canResize,
                            cancelChildTouch = null,
                            onTouchActive = { vm.widgetTouchActive = it },
                            onLongPress = { onEditing(item.id) },
                            onExitEdit = { onEditing(null) },
                            onRemove = {
                                onEditing(null)
                                vm.removeItem(item.id)
                            },
                            onResizeStep = resizeStep,
                            onPinchStart = pinchStart,
                            onPinch = pinchMove,
                            onPinchEnd = pinchEnd,
                            onDragStart = { grab, root -> drag.begin(item, root, grab) },
                            onDragMove = { drag.update(it) },
                            onDragEnd = onDrop,
                            onDragCancel = { drag.cancel() },
                            modifier = Modifier
                                .offset(x = cellW * item.col, y = cellHeight * item.row)
                                .size(cellW * item.spanCols, cellHeight * item.spanRows)
                                .padding(4.dp),
                        ) {
                            if (item.type == ItemType.CLOCK) {
                                ClockBlock(Modifier.fillMaxSize())
                            } else {
                                PersonBlock(
                                    person = vm.clockPerson,
                                    both = vm.clockBoth,
                                    onPersonSelected = {
                                        vm.selectPerson(it)
                                        vm.chooseClockBoth(false)
                                    },
                                    onBothSelected = { vm.chooseClockBoth(true) },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                        }
                    } else {
                        ItemCell(
                            item = item,
                            vm = vm,
                            appsByKey = appsByKey,
                            drag = drag,
                            shape = shape,
                            iconDp = iconDp,
                            showLabel = showLabels,
                            locked = locked,
                            onOpenFolder = onOpenFolder,
                            onOpen = onOpen,
                            onInfo = onInfo,
                            onUninstall = onUninstall,
                            onEdit = onEdit,
                            onDrop = onDrop,
                            modifier = Modifier
                                .offset(x = cellW * item.col, y = cellHeight * item.row)
                                .size(cellW, cellHeight),
                        )
                    }
                }
            }
        }
    }
}

/** Una app o carpeta (inicio o dock) con su menú. */
@Composable
private fun ItemCell(
    item: HomeItem,
    vm: LauncherViewModel,
    appsByKey: Map<String, AppInfo>,
    drag: DragController,
    shape: Shape,
    iconDp: Dp,
    showLabel: Boolean,
    locked: Boolean,
    onOpenFolder: (HomeItem, Offset) -> Unit,
    onOpen: (AppInfo, Offset?) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onEdit: (AppInfo) -> Unit,
    onDrop: () -> Unit,
    modifier: Modifier,
) {
    val context = LocalContext.current
    val where = if (item.isDock) "del dock" else "de inicio"
    val showBadges = vm.settings.showBadges
    if (item.type == ItemType.FOLDER) {
        val kids = item.children.mapNotNull { appsByKey[it] }
        val badge = if (showBadges) kids.sumOf { BadgeStore.counts[it.packageName] ?: 0 } else 0
        HomeCell(
            item = item,
            label = item.title.ifBlank { "Carpeta" },
            showLabel = showLabel,
            menu = {
                buildList {
                    add(MenuAction("Abrir") { onOpenFolder(item, Offset.Zero) })
                    if (!locked) {
                        add(MenuAction("Deshacer carpeta") { vm.dissolveFolder(item.id) })
                        add(MenuAction("Quitar carpeta $where") { vm.removeItem(item.id) })
                    }
                }
            },
            onClick = { center -> onOpenFolder(item, center) },
            drag = drag,
            locked = locked,
            iconSize = iconDp,
            onDrop = onDrop,
            modifier = modifier,
        ) { size ->
            Box(Modifier.size(size)) {
                FolderIcon(apps = kids, size = size, shape = shape)
                if (badge > 0) BadgeDot(badge, Modifier.align(Alignment.TopEnd))
            }
        }
    } else {
        val app = appsByKey[item.appKey ?: ""] ?: return
        val badge = if (showBadges) (BadgeStore.counts[app.packageName] ?: 0) else 0
        HomeCell(
            item = item,
            label = app.label,
            showLabel = showLabel,
            menu = {
                buildList {
                    addAll(shortcutMenu(context, app))
                    if (!locked) add(MenuAction("Quitar $where") { vm.removeItem(item.id) })
                    add(MenuAction("Nombre e icono") { onEdit(app) })
                    add(MenuAction("Info de la app") { onInfo(app) })
                    add(MenuAction("Desinstalar") { onUninstall(app) })
                }
            },
            onClick = { center -> onOpen(app, center) },
            drag = drag,
            locked = locked,
            iconSize = iconDp,
            onDrop = onDrop,
            modifier = modifier,
        ) { size ->
            Box(Modifier.size(size)) {
                Image(
                    bitmap = app.icon,
                    contentDescription = if (showLabel) null else app.label,
                    modifier = Modifier
                        .size(size)
                        .clip(shape),
                )
                if (badge > 0) BadgeDot(badge, Modifier.align(Alignment.TopEnd))
            }
        }
    }
}

/** Barra de búsqueda del inicio: al tocarla se abre el cajón con el teclado. */
@Composable
private fun HomeSearchBar(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Color.White.copy(alpha = 0.16f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.8f),
            modifier = Modifier.size(22.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text("Buscar", color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp)
    }
}

/** Hueco vacío del dock: se ilumina cuando se arrastra algo encima. */
@Composable
private fun DockEmptySlot(slot: Int, drag: DragController, modifier: Modifier) {
    val isTarget by remember(slot) {
        derivedStateOf {
            val h = drag.hover
            h != null && h.page == DOCK_PAGE && h.col == slot
        }
    }
    Box(
        modifier = modifier
            .padding(2.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (isTarget) Color.White.copy(alpha = 0.22f) else Color.Transparent),
    )
}

/** Resalta la celda (o el rectángulo del widget) sobre la que está el dedo al arrastrar. */
@Composable
private fun HoverHighlight(
    page: Int,
    drag: DragController,
    pageItems: List<HomeItem>,
    vm: LauncherViewModel,
    cellW: Dp,
    cellH: Dp,
) {
    val hover = drag.hover
    val dragged = drag.item
    if (dragged == null || hover == null || hover.page != page) return
    if (dragged.isBlock) {
        val ok = vm.canPlaceWidget(page, hover.row, hover.col, dragged.spanRows, dragged.spanCols, dragged.id)
        val tint = if (ok) Color(0xFF66BB6A) else Color(0xFFE53935)
        Box(
            Modifier
                .offset(x = cellW * hover.col, y = cellH * hover.row)
                .size(cellW * dragged.spanCols, cellH * dragged.spanRows)
                .padding(3.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(tint.copy(alpha = 0.35f)),
        )
    } else if (pageItems.none { it.covers(hover.row, hover.col) }) {
        Box(
            Modifier
                .offset(x = cellW * hover.col, y = cellH * hover.row)
                .size(cellW, cellH)
                .padding(4.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = 0.18f)),
        )
    }
}

/** Estado de un pellizco en curso: tamaño de partida y tamaño propuesto (en celdas). */
private data class PinchInfo(
    val itemId: String,
    val baseC: Int,
    val baseR: Int,
    val c: Int,
    val r: Int,
    /** false si el tamaño pedido no entra y se muestra el máximo posible. */
    val exact: Boolean,
)
