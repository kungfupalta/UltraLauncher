package com.marcos.ultralauncher.ui

import android.app.Activity
import android.app.ActivityOptions
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.Flashlight
import com.marcos.ultralauncher.GestureAction
import com.marcos.ultralauncher.GestureBinding
import com.marcos.ultralauncher.GestureType
import com.marcos.ultralauncher.LockAccess
import com.marcos.ultralauncher.expandQuickSettings
import com.marcos.ultralauncher.openAccessibilitySettings
import com.marcos.ultralauncher.LauncherViewModel
import com.marcos.ultralauncher.expandNotifications
import com.marcos.ultralauncher.openAppInfo
import com.marcos.ultralauncher.openSystemSettings
import com.marcos.ultralauncher.openWallpaperPicker
import com.marcos.ultralauncher.uninstallApp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Raíz del launcher: pantalla de inicio + cajón de apps (se abre deslizando hacia arriba,
 * deslizar hacia abajo en el inicio abre las notificaciones), igual que One UI.
 */
@Composable
fun LauncherApp(vm: LauncherViewModel, onAddWidget: (AppWidgetProviderInfo) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // 0f = cajón cerrado, 1f = cajón abierto.
    var progress by remember { mutableFloatStateOf(0f) }
    var settleJob by remember { mutableStateOf<Job?>(null) }
    var showEditMenu by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showWidgetPicker by remember { mutableStateOf(false) }
    var editingApp by remember { mutableStateOf<AppInfo?>(null) }
    var focusSearch by remember { mutableStateOf(false) }
    val drawerVisible by remember { derivedStateOf { progress > 0.001f } }

    fun settle(target: Float) {
        settleJob?.cancel()
        settleJob = scope.launch {
            animate(
                initialValue = progress,
                targetValue = target,
                animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing),
            ) { value, _ ->
                progress = value
            }
        }
    }

    fun closeNow() {
        settleJob?.cancel()
        progress = 0f
    }

    val appsByKey = remember(vm.apps) { vm.apps.associateBy { it.key } }
    val view = LocalView.current

    // Abre la app; si está activado, con animación que crece desde el icono.
    fun launchWithAnim(app: AppInfo, origin: Offset?) {
        var opts: Bundle? = null
        if (vm.settings.openAnim && origin != null) {
            try {
                opts = ActivityOptions.makeScaleUpAnimation(view, origin.x.toInt(), origin.y.toInt(), 1, 1).toBundle()
            } catch (e: Exception) {
            }
        }
        vm.openApp(app, opts)
    }

    // Ejecuta la acción asignada a un gesto.
    fun perform(b: GestureBinding?) {
        if (b == null) return
        when (b.action) {
            GestureAction.NONE -> {}
            GestureAction.NOTIFICATIONS -> context.expandNotifications()
            GestureAction.QUICK_SETTINGS -> context.expandQuickSettings()
            GestureAction.DRAWER -> settle(1f)
            GestureAction.SEARCH -> {
                focusSearch = true
                settle(1f)
            }
            GestureAction.FLASHLIGHT -> Flashlight.toggle(context)
            GestureAction.LOCK_SCREEN -> {
                if (!LockAccess.lock()) {
                    Toast.makeText(context, "Activá el servicio de accesibilidad de Ultra Launcher", Toast.LENGTH_LONG).show()
                    context.openAccessibilitySettings()
                }
            }
            GestureAction.OPEN_APP -> {
                val app = appsByKey[b.appKey]
                if (app != null) {
                    vm.openApp(app)
                } else {
                    Toast.makeText(context, "Elegí una app en Ajustes > Gestos", Toast.LENGTH_SHORT).show()
                }
            }
            GestureAction.LAUNCHER_SETTINGS -> showSettings = true
        }
    }

    // Desenfoque del fondo mientras el cajón está abierto (Android 12+, según el dispositivo).
    val activity = remember(context) { context.findActivity() }
    val blurPx = (vm.settings.drawerBlur * 60f * LocalDensity.current.density).toInt()
    LaunchedEffect(drawerVisible, blurPx) {
        applyWindowBlur(activity, if (drawerVisible) blurPx else 0)
    }
    val multiFlag = remember { BooleanArray(1) }

    LaunchedEffect(vm.homeSignal) {
        if (vm.homeSignal > 0) settle(0f)
    }

    // El foco automático en la búsqueda solo vale mientras dura esa apertura del cajón.
    LaunchedEffect(drawerVisible) {
        if (!drawerVisible) focusSearch = false
    }

    // En un launcher "atrás" nunca debe cerrar la pantalla de inicio.
    BackHandler(enabled = true) {
        if (drawerVisible) settle(0f)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val heightPx = with(density) { maxHeight.toPx() }
        val notifyThresholdPx = with(density) { 90.dp.toPx() }

        // Permite arrastrar el cajón hacia abajo cuando la lista ya está arriba del todo.
        val connection = remember(heightPx) {
            object : NestedScrollConnection {
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    if (available.y < 0f && progress < 1f) {
                        progress = (progress - available.y / (heightPx * 0.8f)).coerceIn(0f, 1f)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }

                override fun onPostScroll(
                    consumed: Offset,
                    available: Offset,
                    source: NestedScrollSource,
                ): Offset {
                    if (available.y > 0f && source == NestedScrollSource.Drag) {
                        settleJob?.cancel()
                        progress = (progress - available.y / (heightPx * 0.8f)).coerceIn(0f, 1f)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }

                override suspend fun onPreFling(available: Velocity): Velocity {
                    if (progress > 0.001f && progress < 0.999f) {
                        val target = when {
                            available.y > 1200f -> 0f
                            available.y < -1200f -> 1f
                            progress > 0.5f -> 1f
                            else -> 0f
                        }
                        settle(target)
                        return available
                    }
                    return Velocity.Zero
                }
            }
        }

        // Pantalla de inicio
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    drawRect(Color.Black.copy(alpha = vm.settings.homeDim))
                }
                .graphicsLayer {
                    alpha = 1f - progress
                    scaleX = 1f - 0.06f * progress
                    scaleY = 1f - 0.06f * progress
                }
                .pointerInput(heightPx) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = {
                            total = 0f
                            settleJob?.cancel()
                        },
                        onVerticalDrag = { change, dy ->
                            change.consume()
                            total += dy
                            val upIsDrawer = vm.settings.gestures[GestureType.SWIPE_UP]?.action == GestureAction.DRAWER
                            if ((dy < 0f && upIsDrawer) || progress > 0f) {
                                progress = (progress - dy / (heightPx * 0.8f)).coerceIn(0f, 1f)
                            }
                        },
                        onDragEnd = {
                            val g = vm.settings.gestures
                            when {
                                multiFlag[0] -> settle(0f)
                                progress > 0.1f -> settle(1f)
                                total > notifyThresholdPx -> {
                                    settle(0f)
                                    perform(g[GestureType.SWIPE_DOWN])
                                }
                                total < -notifyThresholdPx -> {
                                    settle(0f)
                                    perform(g[GestureType.SWIPE_UP])
                                }
                                else -> settle(0f)
                            }
                        },
                        onDragCancel = { settle(0f) },
                    )
                }
                .pointerInput(Unit) {
                    // Gestos de dos dedos: pellizco y deslizar arriba/abajo. Solo observa; no consume.
                    val actionThresholdPx = 90.dp.toPx()
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        multiFlag[0] = false
                        var multi = false
                        var startDist = 0f
                        var startY = 0f
                        var lastDist = 0f
                        var lastY = 0f
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val down = event.changes.filter { it.pressed }
                            if (down.size >= 2) {
                                val a = down[0].position
                                val b = down[1].position
                                val dist = (a - b).getDistance()
                                val y = (a.y + b.y) / 2f
                                if (!multi) {
                                    multi = true
                                    multiFlag[0] = true
                                    startDist = dist
                                    startY = y
                                }
                                lastDist = dist
                                lastY = y
                            }
                        } while (event.changes.any { it.pressed })
                        if (multi && startDist > 0f) {
                            val g = vm.settings.gestures
                            val dy = lastY - startY
                            when {
                                lastDist < startDist * 0.7f -> perform(g[GestureType.PINCH])
                                dy < -actionThresholdPx -> perform(g[GestureType.TWO_UP])
                                dy > actionThresholdPx -> perform(g[GestureType.TWO_DOWN])
                            }
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            if (!vm.widgetTouchActive) perform(vm.settings.gestures[GestureType.DOUBLE_TAP])
                        },
                        onLongPress = { if (!vm.widgetTouchActive) showEditMenu = true },
                    )
                },
        ) {
            HomeScreen(
                vm = vm,
                appsByKey = appsByKey,
                onOpen = { app, origin -> launchWithAnim(app, origin) },
                onInfo = { context.openAppInfo(it.packageName) },
                onUninstall = { context.uninstallApp(it.packageName) },
                onEdit = { editingApp = it },
                onSearch = {
                    focusSearch = true
                    settle(1f)
                },
            )
        }

        // Cajón de apps
        if (drawerVisible) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        drawRect(Color.Black.copy(alpha = vm.settings.drawerDim * progress))
                    }
                    .pointerInput(Unit) {
                        // Evita que los toques en huecos del cajón lleguen al inicio.
                        detectTapGestures(onTap = { })
                    },
            ) {
                AppDrawer(
                    vm = vm,
                    connection = connection,
                    focusSearch = focusSearch,
                    onOpen = { app, origin ->
                        launchWithAnim(app, origin)
                        closeNow()
                    },
                    onAddHome = { vm.addToHome(it) },
                    onAddDock = { vm.addToDock(it) },
                    onInfo = { context.openAppInfo(it.packageName) },
                    onUninstall = { context.uninstallApp(it.packageName) },
                    onEdit = { editingApp = it },
                    modifier = Modifier.graphicsLayer {
                        translationY = (1f - progress) * heightPx
                    },
                )
            }
        }

        if (showEditMenu) {
            EditMenuDialog(
                person = vm.clockPerson,
                onPersonSelected = { vm.selectPerson(it) },
                locked = vm.settings.layoutLocked,
                onToggleLock = {
                    showEditMenu = false
                    vm.setLocked(!vm.settings.layoutLocked)
                },
                onWidgets = {
                    showEditMenu = false
                    if (vm.settings.layoutLocked) {
                        Toast.makeText(context, "Desbloqueá el layout para añadir widgets", Toast.LENGTH_SHORT).show()
                    } else {
                        showWidgetPicker = true
                    }
                },
                onCustomize = {
                    showEditMenu = false
                    showSettings = true
                },
                onWallpaper = {
                    showEditMenu = false
                    context.openWallpaperPicker()
                },
                onSettings = {
                    showEditMenu = false
                    context.openSystemSettings()
                },
                onDismiss = { showEditMenu = false },
            )
        }

        if (showWidgetPicker) {
            WidgetPickerDialog(
                vm = vm,
                onPick = {
                    showWidgetPicker = false
                    onAddWidget(it)
                },
                onDismiss = { showWidgetPicker = false },
            )
        }

        val appToEdit = editingApp
        if (appToEdit != null) {
            AppEditDialog(vm = vm, app = appToEdit, onDismiss = { editingApp = null })
        }

        if (showSettings) {
            SettingsScreen(
                vm = vm,
                onClose = { showSettings = false },
                onShowWelcome = {
                    showSettings = false
                    vm.showOnboardingAgain()
                },
            )
        }

        if (!vm.onboardingDone) {
            OnboardingScreen(vm = vm, onDone = { vm.finishOnboarding() })
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Desenfoca lo que hay detrás de la ventana (Android 12+). Por reflexión: si no existe, no hace nada. */
@Suppress("DEPRECATION")
private fun applyWindowBlur(activity: Activity?, px: Int) {
    if (activity == null || Build.VERSION.SDK_INT < 31) return
    try {
        val w: Window = activity.window
        try {
            Window::class.java.getMethod("setBackgroundBlurRadius", Int::class.javaPrimitiveType).invoke(w, px)
        } catch (e: Exception) {
        }
        if (px > 0) {
            w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
        } else {
            w.clearFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
        }
        val lp = w.attributes
        try {
            lp.javaClass.getField("blurBehindRadius").setInt(lp, px)
        } catch (e: Exception) {
        }
        w.attributes = lp
    } catch (e: Exception) {
    }
}
