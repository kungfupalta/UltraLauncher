package com.marcos.ultralauncher.ui

import android.appwidget.AppWidgetProviderInfo
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import com.marcos.ultralauncher.LauncherViewModel
import com.marcos.ultralauncher.expandNotifications
import com.marcos.ultralauncher.launchApp
import com.marcos.ultralauncher.openAppInfo
import com.marcos.ultralauncher.openSystemSettings
import com.marcos.ultralauncher.openWallpaperPicker
import com.marcos.ultralauncher.uninstallApp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Raíz del launcher: pantalla de inicio + cajón de apps (se abre deslizando hacia arriba,
 * deslizar hacia abajo en el inicio abre las notificaciones), igual que One UI.
 */
@Composable
fun LauncherApp(vm: LauncherViewModel, onAddWidget: (AppWidgetProviderInfo) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // 0f = cajón cerrado, 1f = cajón abierto.
    var progress by remember { mutableFloatStateOf(0f) }
    var settleJob by remember { mutableStateOf<Job?>(null) }
    var showEditMenu by remember { mutableStateOf(false) }
    var showCustomize by remember { mutableStateOf(false) }
    var showWidgetPicker by remember { mutableStateOf(false) }
    val drawerVisible by remember { derivedStateOf { progress > 0.001f } }

    fun settle(target: Float) {
        settleJob?.cancel()
        settleJob = scope.launch {
            animate(
                initialValue = progress,
                targetValue = target,
                animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing),
            ) { value, _ ->
                progress = value
            }
        }
    }

    fun closeNow() {
        settleJob?.cancel()
        progress = 0f
    }

    val appsByKey = remember(vm.apps) { vm.apps.associateBy { it.key } }

    LaunchedEffect(vm.homeSignal) {
        if (vm.homeSignal > 0) settle(0f)
    }

    // En un launcher "atrás" nunca debe cerrar la pantalla de inicio.
    BackHandler(enabled = true) {
        if (drawerVisible) settle(0f)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val heightPx = with(density) { maxHeight.toPx() }
        val notifyThresholdPx = with(density) { 90.dp.toPx() }

        // Permite arrastrar el cajón hacia abajo cuando la lista ya está arriba del todo.
        val connection = remember(heightPx) {
            object : NestedScrollConnection {
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    if (available.y < 0f && progress < 1f) {
                        progress = (progress - available.y / (heightPx * 0.8f)).coerceIn(0f, 1f)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }

                override fun onPostScroll(
                    consumed: Offset,
                    available: Offset,
                    source: NestedScrollSource,
                ): Offset {
                    if (available.y > 0f && source == NestedScrollSource.Drag) {
                        settleJob?.cancel()
                        progress = (progress - available.y / (heightPx * 0.8f)).coerceIn(0f, 1f)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }

                override suspend fun onPreFling(available: Velocity): Velocity {
                    if (progress > 0.001f && progress < 0.999f) {
                        val target = when {
                            available.y > 1200f -> 0f
                            available.y < -1200f -> 1f
                            progress > 0.5f -> 1f
                            else -> 0f
                        }
                        settle(target)
                        return available
                    }
                    return Velocity.Zero
                }
            }
        }

        // Pantalla de inicio
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    alpha = 1f - progress
                    scaleX = 1f - 0.06f * progress
                    scaleY = 1f - 0.06f * progress
                }
                .pointerInput(heightPx) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = {
                            total = 0f
                            settleJob?.cancel()
                        },
                        onVerticalDrag = { change, dy ->
                            change.consume()
                            total += dy
                            if (dy < 0f || progress > 0f) {
                                progress = (progress - dy / (heightPx * 0.8f)).coerceIn(0f, 1f)
                            }
                        },
                        onDragEnd = {
                            when {
                                progress > 0.1f -> settle(1f)
                                total > notifyThresholdPx -> {
                                    settle(0f)
                                    context.expandNotifications()
                                }
                                else -> settle(0f)
                            }
                        },
                        onDragCancel = { settle(0f) },
                    )
                }
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { if (!vm.widgetTouchActive) showEditMenu = true })
                },
        ) {
            HomeScreen(
                vm = vm,
                appsByKey = appsByKey,
                onOpen = { context.launchApp(it) },
                onInfo = { context.openAppInfo(it.packageName) },
                onUninstall = { context.uninstallApp(it.packageName) },
            )
        }

        // Cajón de apps
        if (drawerVisible) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        drawRect(Color.Black.copy(alpha = 0.78f * progress))
                    }
                    .pointerInput(Unit) {
                        // Evita que los toques en huecos del cajón lleguen al inicio.
                        detectTapGestures(onTap = { })
                    },
            ) {
                AppDrawer(
                    apps = vm.apps,
                    connection = connection,
                    onOpen = {
                        context.launchApp(it)
                        closeNow()
                    },
                    onAddHome = { vm.addToHome(it) },
                    onAddDock = { vm.addToDock(it) },
                    onInfo = { context.openAppInfo(it.packageName) },
                    onUninstall = { context.uninstallApp(it.packageName) },
                    columns = vm.settings.drawerColumns,
                    iconSize = vm.settings.iconDp.dp,
                    shape = vm.settings.shape.toShape(),
                    showLabels = vm.settings.showLabels,
                    modifier = Modifier.graphicsLayer {
                        translationY = (1f - progress) * heightPx
                    },
                )
            }
        }

        if (showEditMenu) {
            EditMenuDialog(
                person = vm.clockPerson,
                onPersonSelected = { vm.selectPerson(it) },
                locked = vm.settings.layoutLocked,
                onToggleLock = {
                    showEditMenu = false
                    vm.setLocked(!vm.settings.layoutLocked)
                },
                onWidgets = {
                    showEditMenu = false
                    if (vm.settings.layoutLocked) {
                        Toast.makeText(context, "Desbloqueá el layout para añadir widgets", Toast.LENGTH_SHORT).show()
                    } else {
                        showWidgetPicker = true
                    }
                },
                onCustomize = {
                    showEditMenu = false
                    showCustomize = true
                },
                onWallpaper = {
                    showEditMenu = false
                    context.openWallpaperPicker()
                },
                onSettings = {
                    showEditMenu = false
                    context.openSystemSettings()
                },
                onDismiss = { showEditMenu = false },
            )
        }

        if (showWidgetPicker) {
            WidgetPickerDialog(
                vm = vm,
                onPick = {
                    showWidgetPicker = false
                    onAddWidget(it)
                },
                onDismiss = { showWidgetPicker = false },
            )
        }

        if (showCustomize) {
            CustomizeDialog(
                settings = vm.settings,
                onChange = { vm.updateSettings(it) },
                onDismiss = { showCustomize = false },
            )
        }
    }
}
