package com.marcos.ultralauncher.ui

import android.content.Context
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.loadShortcuts
import com.marcos.ultralauncher.startAppShortcut

/** Atajos de la app como entradas de menú (vacío si este launcher no es el predeterminado). */
fun shortcutMenu(context: Context, app: AppInfo): List<MenuAction> =
    context.loadShortcuts(app.packageName, app.user).map { sc ->
        MenuAction("⋮  " + sc.label) { context.startAppShortcut(sc) }
    }
