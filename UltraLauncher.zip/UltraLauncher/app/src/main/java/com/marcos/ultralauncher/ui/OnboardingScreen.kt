package com.marcos.ultralauncher.ui

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marcos.ultralauncher.LauncherViewModel
import com.marcos.ultralauncher.LockAccess
import com.marcos.ultralauncher.defaultLauncherIntent
import com.marcos.ultralauncher.openAccessibilitySettings
import com.marcos.ultralauncher.openNotificationAccessSettings
import com.marcos.ultralauncher.openSystemSettings

/** Bienvenida: pide ser el launcher predeterminado y explica los permisos opcionales. */
@Composable
fun OnboardingScreen(vm: LauncherViewModel, onDone: () -> Unit) {
    val context = LocalContext.current
    var page by remember { mutableIntStateOf(0) }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        vm.refreshAccess()
    }
    val contactsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.refreshAccess()
        if (granted) vm.updateSettings(vm.settings.copy(searchContacts = true))
    }
    BackHandler(enabled = true) {
        if (page > 0) page-- else onDone()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
        ) {
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
            ) {
                if (page == 0) {
                    Spacer(Modifier.height(24.dp))
                    Text("Bienvenido a Ultra Launcher", fontSize = 28.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Para que sea tu pantalla de inicio tiene que ser el launcher predeterminado. " +
                            "Así el botón Inicio vuelve acá y los atajos de las apps funcionan.",
                        fontSize = 15.sp,
                    )
                    SAction(
                        if (vm.isDefaultLauncher) "✓ Ya es tu launcher predeterminado"
                        else "Establecer como launcher predeterminado",
                    ) {
                        if (!vm.isDefaultLauncher) {
                            try {
                                roleLauncher.launch(context.defaultLauncherIntent())
                            } catch (e: Exception) {
                                context.openSystemSettings()
                            }
                        }
                    }
                    SHint("Podés cambiarlo cuando quieras desde los ajustes de Android.")
                } else {
                    Spacer(Modifier.height(24.dp))
                    Text("Permisos opcionales", fontSize = 28.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Ninguno es obligatorio: el launcher funciona completo sin ellos. " +
                            "Activalos solo si querés esas funciones.",
                        fontSize = 15.sp,
                    )
                    SAction(
                        "Insignias de notificaciones: " + if (vm.notificationAccess) "activo" else "activar",
                        "Muestra un punto con la cantidad de notificaciones en cada icono. Solo cuenta; no guarda ni envía su contenido.",
                    ) { context.openNotificationAccessSettings() }
                    SAction(
                        "Buscar contactos: " + if (vm.contactsGranted) "activo" else "activar",
                        "Permite encontrar contactos desde el buscador del cajón.",
                    ) {
                        if (!vm.contactsGranted) contactsLauncher.launch(Manifest.permission.READ_CONTACTS)
                    }
                    SAction(
                        "Bloquear pantalla con un gesto: " + if (LockAccess.enabled) "activo" else "activar",
                        "Usa un servicio de accesibilidad solo para bloquear la pantalla (por ejemplo con doble toque). No lee lo que hay en pantalla.",
                    ) { context.openAccessibilitySettings() }
                    SHint("Más tarde los encontrás en Ajustes > Acerca de.")
                }
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                if (page == 0) {
                    TextButton(onClick = onDone) { Text("Omitir") }
                    Button(onClick = { page = 1 }) { Text("Siguiente") }
                } else {
                    TextButton(onClick = { page = 0 }) { Text("Atrás") }
                    Button(onClick = onDone) { Text("Empezar") }
                }
            }
        }
    }
}
