package com.marcos.ultralauncher.ui

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.marcos.ultralauncher.AppFont
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.DrawerSort
import com.marcos.ultralauncher.GestureAction
import com.marcos.ultralauncher.GestureBinding
import com.marcos.ultralauncher.GestureType
import com.marcos.ultralauncher.IconShapeOption
import com.marcos.ultralauncher.IconStyle
import com.marcos.ultralauncher.LauncherViewModel
import com.marcos.ultralauncher.LockAccess
import com.marcos.ultralauncher.SearchBarPos
import com.marcos.ultralauncher.ThemeMode
import com.marcos.ultralauncher.UiSettings
import com.marcos.ultralauncher.defaultLauncherIntent
import com.marcos.ultralauncher.openAccessibilitySettings
import com.marcos.ultralauncher.openNotificationAccessSettings
import com.marcos.ultralauncher.openSystemSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

enum class SettingsSection(val label: String, val subtitle: String) {
    HOME("Inicio", "Cuadrícula, reloj, búsqueda y layout"),
    DOCK("Dock", "Opacidad del dock"),
    DRAWER("Cajón de apps", "Orden, pestañas, búsqueda y apps ocultas"),
    ICONS("Iconos", "Tamaño, forma, estilo, packs e insignias"),
    GESTURES("Gestos", "Doble toque, deslizar, pellizco y dos dedos"),
    THEME("Tema", "Colores, fondo, fuente y animaciones"),
    BACKUP("Copia de seguridad", "Exportar, importar y restablecer"),
    ABOUT("Acerca de", "Versión, launcher predeterminado y permisos"),
}

/** Pantalla de ajustes completa (reemplaza al antiguo diálogo "Personalizar"). */
@Composable
fun SettingsScreen(vm: LauncherViewModel, onClose: () -> Unit, onShowWelcome: () -> Unit) {
    var section by remember { mutableStateOf<SettingsSection?>(null) }
    BackHandler(enabled = true) {
        if (section != null) section = null else onClose()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "←",
                    fontSize = 24.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable { if (section != null) section = null else onClose() }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                )
                Text(
                    text = section?.label ?: "Ajustes",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, end = 20.dp, bottom = 24.dp),
            ) {
                val sec = section
                if (sec == null) {
                    SettingsSection.entries.forEach { s ->
                        SAction(s.label, s.subtitle) { section = s }
                    }
                } else {
                    when (sec) {
                        SettingsSection.HOME -> HomeSection(vm)
                        SettingsSection.DOCK -> DockSection(vm)
                        SettingsSection.DRAWER -> DrawerSection(vm)
                        SettingsSection.ICONS -> IconsSection(vm)
                        SettingsSection.GESTURES -> GesturesSection(vm)
                        SettingsSection.THEME -> ThemeSection(vm)
                        SettingsSection.BACKUP -> BackupSection(vm)
                        SettingsSection.ABOUT -> AboutSection(vm, onShowWelcome)
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeSection(vm: LauncherViewModel) {
    val s = vm.settings
    val context = LocalContext.current
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        vm.refreshAccess()
    }
    SLabel("Columnas en inicio")
    SChoices(listOf("4", "5", "6", "7", "8"), s.columns - 4) { vm.updateSettings(s.copy(columns = it + 4)) }
    SToggle("Mostrar nombres de las apps", s.showLabels) { vm.updateSettings(s.copy(showLabels = it)) }
    SToggle("Mostrar reloj en inicio", s.showClock) { vm.updateSettings(s.copy(showClock = it)) }
    SHint("En pantallas anchas (tablet, plegable abierto, horizontal) se agregan columnas solas y, si la pantalla es baja, el reloj se oculta.")
    SToggle("Bloquear layout (evita mover por accidente)", s.layoutLocked) {
        vm.updateSettings(s.copy(layoutLocked = it))
    }
    SLabel("Barra de búsqueda en inicio")
    val bars = SearchBarPos.entries
    SChoices(bars.map { it.label }, bars.indexOf(s.searchBar)) { vm.updateSettings(s.copy(searchBar = bars[it])) }
    SLabel("Launcher predeterminado")
    SAction(
        if (vm.isDefaultLauncher) "✓ Ultra Launcher es tu launcher predeterminado"
        else "Establecer como launcher predeterminado",
    ) {
        if (!vm.isDefaultLauncher) {
            try {
                roleLauncher.launch(context.defaultLauncherIntent())
            } catch (e: Exception) {
                context.openSystemSettings()
            }
        }
    }
    SHint("Los atajos de las apps (mantener pulsado un icono) solo aparecen si es el launcher predeterminado.")
}

@Composable
private fun DockSection(vm: LauncherViewModel) {
    val s = vm.settings
    SSlider(
        "Opacidad del dock: ${(s.dockAlpha / 0.6f * 100).roundToInt()}%",
        s.dockAlpha,
        0f..0.6f,
    ) { vm.updateSettings(s.copy(dockAlpha = it)) }
    SHint("El dock tiene 4 huecos. Arrastrá apps o carpetas ahí; podés dejar huecos vacíos.")
}

@Composable
private fun rememberContactsRequest(vm: LauncherViewModel) =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.refreshAccess()
        vm.updateSettings(vm.settings.copy(searchContacts = granted))
    }

@Composable
private fun DrawerSection(vm: LauncherViewModel) {
    val s = vm.settings
    var showHidden by remember { mutableStateOf(false) }
    val contactsLauncher = rememberContactsRequest(vm)
    SLabel("Columnas en el cajón")
    SChoices(listOf("4", "5", "6", "7", "8"), s.drawerColumns - 4) { vm.updateSettings(s.copy(drawerColumns = it + 4)) }
    SLabel("Orden")
    val sorts = DrawerSort.entries
    SChoices(sorts.map { it.label }, sorts.indexOf(s.drawerSort)) { vm.updateSettings(s.copy(drawerSort = sorts[it])) }
    SToggle("Pestañas por categoría", s.drawerTabs) { vm.updateSettings(s.copy(drawerTabs = it)) }
    SHint("Las apps de tu perfil de trabajo (con el maletín) aparecen en la pestaña \"Trabajo\".")
    SToggle("Buscar en contactos", s.searchContacts) { on ->
        if (!on) {
            vm.updateSettings(s.copy(searchContacts = false))
        } else if (vm.contactsGranted) {
            vm.updateSettings(s.copy(searchContacts = true))
        } else {
            contactsLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }
    SHint("Permiso opcional: solo se usa para mostrar contactos cuando buscás en el cajón.")
    SAction("Apps ocultas (${vm.hiddenKeys.size})") { showHidden = true }
    if (showHidden) HiddenAppsDialog(vm = vm, onDismiss = { showHidden = false })
}

@Suppress("DEPRECATION")
@Composable
private fun IconsSection(vm: LauncherViewModel) {
    val s = vm.settings
    val context = LocalContext.current
    var showPacks by remember { mutableStateOf(false) }
    val packLabel = remember(s.iconPack) {
        if (s.iconPack.isEmpty()) {
            "Ninguno"
        } else {
            try {
                val info = context.packageManager.getApplicationInfo(s.iconPack, 0)
                context.packageManager.getApplicationLabel(info).toString()
            } catch (e: Exception) {
                s.iconPack
            }
        }
    }
    SSlider("Tamaño de iconos: ${s.iconDp.roundToInt()}", s.iconDp, 40f..80f) {
        vm.updateSettings(s.copy(iconDp = it))
    }
    SLabel("Forma de los iconos")
    val shapes = IconShapeOption.entries
    SChoices(shapes.map { it.label }, shapes.indexOf(s.shape)) { vm.updateSettings(s.copy(shape = shapes[it])) }
    SLabel("Estilo de iconos")
    val styles = IconStyle.entries
    SChoices(styles.map { it.label }, styles.indexOf(s.iconStyle)) { vm.updateSettings(s.copy(iconStyle = styles[it])) }
    if (s.iconStyle == IconStyle.THEMED) {
        SHint("Usa el dibujo monocromático de cada app (Android 13+). Las que no lo traen se ven en gris.")
    }
    SAction("Pack de iconos: $packLabel") { showPacks = true }
    SLabel("Insignias de notificaciones")
    SToggle("Mostrar insignias en los iconos", s.showBadges) { vm.updateSettings(s.copy(showBadges = it)) }
    SHint(
        if (vm.notificationAccess) {
            "Acceso a notificaciones activo. Solo se cuentan las notificaciones por app; no se guarda ni se envía su contenido."
        } else {
            "Permiso opcional: hace falta darle a Ultra Launcher acceso a notificaciones para contarlas. " +
                "Solo se cuenta cuántas hay por app; no se guarda ni se envía su contenido."
        },
    )
    if (!vm.notificationAccess) {
        SAction("Dar acceso a notificaciones") { context.openNotificationAccessSettings() }
    }
    if (showPacks) {
        IconPackDialog(
            current = s.iconPack,
            onPick = {
                showPacks = false
                vm.updateSettings(s.copy(iconPack = it))
            },
            onDismiss = { showPacks = false },
        )
    }
}

private fun bindingLabel(vm: LauncherViewModel, b: GestureBinding): String {
    if (b.action != GestureAction.OPEN_APP) return b.action.label
    val app = vm.apps.firstOrNull { it.key == b.appKey }
    return if (app != null) "Abrir " + app.label else "Abrir una app (sin elegir)"
}

@Composable
private fun GesturesSection(vm: LauncherViewModel) {
    val s = vm.settings
    var editing by remember { mutableStateOf<GestureType?>(null) }
    SHint("Elegí qué hace cada gesto en la pantalla de inicio. Por defecto: deslizar arriba abre el cajón y deslizar abajo abre las notificaciones.")
    GestureType.entries.forEach { g ->
        val b = s.gestures[g] ?: GestureBinding(GestureAction.NONE)
        SAction(g.label, bindingLabel(vm, b)) { editing = g }
    }
    val current = editing
    if (current != null) {
        GestureDialog(vm = vm, gesture = current, onDismiss = { editing = null })
    }
}

@Composable
private fun GestureDialog(vm: LauncherViewModel, gesture: GestureType, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val s = vm.settings
    var pickingApp by remember { mutableStateOf(false) }
    val current = s.gestures[gesture] ?: GestureBinding(GestureAction.NONE)

    fun applyBinding(b: GestureBinding) {
        vm.updateSettings(s.copy(gestures = s.gestures + (gesture to b)))
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ) {
            Column(Modifier.padding(vertical = 20.dp)) {
                Text(
                    gesture.label,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 24.dp),
                )
                Spacer(Modifier.height(8.dp))
                Column(
                    Modifier
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    GestureAction.entries.forEach { a ->
                        val selected = a == current.action
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (a == GestureAction.OPEN_APP) {
                                        pickingApp = true
                                    } else {
                                        applyBinding(GestureBinding(a))
                                        onDismiss()
                                    }
                                }
                                .background(
                                    if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                                    else androidx.compose.ui.graphics.Color.Transparent,
                                )
                                .padding(horizontal = 24.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(a.label, fontSize = 15.sp, modifier = Modifier.weight(1f))
                            if (selected) Text("✓", color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                if (current.action == GestureAction.LOCK_SCREEN) {
                    Text(
                        if (LockAccess.enabled) {
                            "Servicio de accesibilidad activo."
                        } else {
                            "Para bloquear la pantalla hay que activar el servicio opcional \"Ultra Launcher\" en Accesibilidad. " +
                                "Solo se usa para ese gesto: no lee lo que hay en pantalla."
                        },
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                    )
                    if (!LockAccess.enabled) {
                        TextButton(
                            onClick = { context.openAccessibilitySettings() },
                            modifier = Modifier.padding(horizontal = 12.dp),
                        ) { Text("Abrir ajustes de accesibilidad") }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cerrar") }
                }
            }
        }
    }

    if (pickingApp) {
        AppPickDialog(
            apps = vm.apps,
            onPick = {
                applyBinding(GestureBinding(GestureAction.OPEN_APP, it.key))
                pickingApp = false
                onDismiss()
            },
            onDismiss = { pickingApp = false },
        )
    }
}

@Composable
private fun AppPickDialog(apps: List<AppInfo>, onPick: (AppInfo) -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ) {
            Column(Modifier.padding(vertical = 20.dp)) {
                Text(
                    "Elegí una app",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 24.dp),
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(apps, key = { it.key }) { app ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onPick(app) }
                                .padding(horizontal = 24.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Image(
                                bitmap = app.icon,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(app.label, fontSize = 15.sp)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancelar") }
                }
            }
        }
    }
}

@Composable
private fun ThemeSection(vm: LauncherViewModel) {
    val s = vm.settings
    SLabel("Modo")
    val modes = ThemeMode.entries
    SChoices(modes.map { it.label }, modes.indexOf(s.themeMode)) { vm.updateSettings(s.copy(themeMode = modes[it])) }
    if (Build.VERSION.SDK_INT >= 31) {
        SToggle("Colores dinámicos (Material You)", s.dynamicColors) { vm.updateSettings(s.copy(dynamicColors = it)) }
        SHint("Toma los colores de tu fondo de pantalla para Ajustes y los diálogos.")
    } else {
        SHint("Los colores dinámicos necesitan Android 12 o superior.")
    }
    SSlider("Atenuado del fondo en inicio: ${(s.homeDim / 0.6f * 100).roundToInt()}%", s.homeDim, 0f..0.6f) {
        vm.updateSettings(s.copy(homeDim = it))
    }
    SSlider("Atenuado del fondo con el cajón: ${(s.drawerDim * 100).roundToInt()}%", s.drawerDim, 0.3f..0.95f) {
        vm.updateSettings(s.copy(drawerDim = it))
    }
    if (Build.VERSION.SDK_INT >= 31) {
        SSlider("Desenfoque del fondo con el cajón: ${(s.drawerBlur * 100).roundToInt()}%", s.drawerBlur, 0f..1f) {
            vm.updateSettings(s.copy(drawerBlur = it))
        }
        SHint("Depende del dispositivo: algunos no permiten desenfocar el fondo de pantalla.")
    } else {
        SHint("El desenfoque necesita Android 12 o superior.")
    }
    SLabel("Fuente")
    val fonts = AppFont.entries
    SChoices(fonts.map { it.label }, fonts.indexOf(s.font)) { vm.updateSettings(s.copy(font = fonts[it])) }
    SSlider("Tamaño del texto: ${(s.textScale * 100).roundToInt()}%", s.textScale, 0.8f..1.4f) {
        vm.updateSettings(s.copy(textScale = it))
    }
    SToggle("Abrir apps con animación desde el icono", s.openAnim) { vm.updateSettings(s.copy(openAnim = it)) }
}

@Composable
private fun BackupSection(vm: LauncherViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirm by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch {
                val text = vm.exportBackup()
                val ok = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                Toast.makeText(context, if (ok) "Copia guardada" else "No se pudo guardar", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    } catch (e: Exception) {
                        null
                    }
                }
                val ok = text != null && vm.importBackup(text)
                Toast.makeText(
                    context,
                    if (ok) "Copia importada" else "El archivo no es una copia válida",
                    Toast.LENGTH_SHORT,
                ).show()
            }
        }
    }

    SHint(
        "La copia incluye ajustes, layout, carpetas, nombres, apps ocultas y gestos. " +
            "No incluye los widgets (hay que volver a añadirlos) ni las imágenes de iconos propios.",
    )
    SAction("Exportar copia de seguridad", "Guarda un archivo JSON donde quieras") {
        exportLauncher.launch("UltraLauncher-copia.json")
    }
    SAction("Importar copia de seguridad", "Reemplaza tus ajustes y layout actuales") { confirm = "import" }
    SAction("Restablecer ajustes", "Vuelve los ajustes a los valores originales (no toca el layout)") {
        confirm = "reset"
    }

    val c = confirm
    if (c != null) {
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (c == "import") "¿Importar copia?" else "¿Restablecer ajustes?") },
            text = {
                Text(
                    if (c == "import") "Se reemplazarán tus ajustes y tu layout actuales por los de la copia."
                    else "Los ajustes volverán a sus valores originales.",
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirm = null
                        if (c == "import") {
                            importLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream"))
                        } else {
                            vm.resetSettings()
                        }
                    },
                ) { Text("Continuar") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancelar") } },
        )
    }
}

@Suppress("DEPRECATION")
@Composable
private fun AboutSection(vm: LauncherViewModel, onShowWelcome: () -> Unit) {
    val context = LocalContext.current
    val contactsLauncher = rememberContactsRequest(vm)
    val version = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    Text("Ultra Launcher $version", fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 12.dp))
    SHint("Launcher de Marcos · Kotlin + Jetpack Compose")

    SLabel("Launcher predeterminado")
    SHint(if (vm.isDefaultLauncher) "Sí, es tu launcher predeterminado." else "No es el predeterminado todavía (Ajustes > Inicio).")

    SLabel("Permisos opcionales")
    SHint("Ninguno es obligatorio. Podés activarlos o quitarlos cuando quieras.")
    SAction(
        "Notificaciones (insignias): " + if (vm.notificationAccess) "activo" else "desactivado",
        "Cuenta cuántas notificaciones tiene cada app. No guarda ni envía su contenido.",
    ) { context.openNotificationAccessSettings() }
    SAction(
        "Contactos (búsqueda): " + if (vm.contactsGranted) "activo" else "desactivado",
        "Permite encontrar contactos desde el buscador del cajón.",
    ) {
        if (vm.contactsGranted) {
            context.openSystemSettings()
        } else {
            contactsLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }
    SAction(
        "Accesibilidad (bloquear pantalla): " + if (LockAccess.enabled) "activo" else "desactivado",
        "Solo se usa para el gesto \"Bloquear pantalla\". No lee el contenido de la pantalla.",
    ) { context.openAccessibilitySettings() }

    SLabel("Bienvenida")
    SAction("Ver la bienvenida otra vez") { onShowWelcome() }
}
