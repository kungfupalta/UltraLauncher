package com.marcos.ultralauncher.ui

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape
import com.marcos.ultralauncher.IconShapeOption

fun IconShapeOption.toShape(): Shape = when (this) {
    IconShapeOption.SQUIRCLE -> SquircleShape
    IconShapeOption.CIRCLE -> CircleShape
    IconShapeOption.ROUNDED -> RoundedCornerShape(percent = 26)
    IconShapeOption.SQUARE -> RoundedCornerShape(percent = 8)
}
