package com.marcos.ultralauncher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val UltraColors = darkColorScheme(
    primary = Color(0xFF8AB4FF),
    surface = Color(0xFF26262B),
    onSurface = Color.White,
)

@Composable
fun UltraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = UltraColors, content = content)
}
