package com.marcos.ultralauncher.ui

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.abs
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.marcos.ultralauncher.HomeItem
import com.marcos.ultralauncher.ItemType
import com.marcos.ultralauncher.LauncherViewModel
import com.marcos.ultralauncher.SpanLimits
import com.marcos.ultralauncher.UltraWidgetHost
import com.marcos.ultralauncher.WidgetEntry
import com.marcos.ultralauncher.toPreviewBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Un widget de Android dentro del inicio (ver [EditableBlock] para la edición).
 */
@Composable
fun WidgetCell(
    item: HomeItem,
    host: UltraWidgetHost,
    widthDp: Float,
    heightDp: Float,
    locked: Boolean,
    editing: Boolean,
    dragging: Boolean,
    canResize: Boolean,
    onTouchActive: (Boolean) -> Unit,
    onLongPress: () -> Unit,
    onExitEdit: () -> Unit,
    onRemove: () -> Unit,
    onResizeStep: (Int) -> Unit,
    onPinchStart: () -> Unit,
    onPinch: (Float, Float) -> Unit,
    onPinchEnd: () -> Unit,
    onDragStart: (Offset, Offset) -> Unit,
    onDragMove: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val info = remember(item.widgetId) { host.infoFor(item.widgetId) }
    val frameRef = remember { arrayOfNulls<FrameLayout>(1) }

    EditableBlock(
        blockKey = item.id,
        locked = locked,
        editing = editing,
        dragging = dragging,
        canResize = canResize,
        cancelChildTouch = {
            val frame = frameRef[0]
            if (frame != null) {
                val now = SystemClock.uptimeMillis()
                val cancel = MotionEvent.obtain(now, now, MotionEvent.ACTION_CANCEL, 0f, 0f, 0)
                frame.dispatchTouchEvent(cancel)
                cancel.recycle()
            }
        },
        onTouchActive = onTouchActive,
        onLongPress = onLongPress,
        onExitEdit = onExitEdit,
        onRemove = onRemove,
        onResizeStep = onResizeStep,
        onPinchStart = onPinchStart,
        onPinch = onPinch,
        onPinchEnd = onPinchEnd,
        onDragStart = onDragStart,
        onDragMove = onDragMove,
        onDragEnd = onDragEnd,
        onDragCancel = onDragCancel,
        modifier = modifier,
    ) {
        if (info == null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Text("Widget no disponible", color = Color.White, fontSize = 13.sp)
            }
        } else {
            AndroidView(
                factory = { ctx ->
                    FrameLayout(ctx).also { frame ->
                        frameRef[0] = frame
                        try {
                            val hv = host.createView(ctx, item.widgetId, info)
                            frame.addView(
                                hv,
                                FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                ),
                            )
                        } catch (e: Exception) {
                        }
                    }
                },
                update = { frame ->
                    val hv = frame.getChildAt(0) as? AppWidgetHostView
                    try {
                        val w = widthDp.toInt()
                        val h = heightDp.toInt()
                        hv?.updateAppWidgetSize(Bundle(), w, h, w, h)
                    } catch (e: Exception) {
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(22.dp)),
            )
        }
    }
}

/**
 * Bloque editable del inicio (widget de Android, reloj u hora de una persona). Mantener pulsado
 * (sin mover) entra en modo edición: aparece un marco con "Tamaño" y "Quitar", y se puede arrastrar
 * para moverlo. La detección de la pulsación larga mira los toques sin consumirlos, para que el
 * contenido siga funcionando y se pueda cambiar de página deslizando sobre él.
 */
@Composable
fun EditableBlock(
    blockKey: String,
    locked: Boolean,
    editing: Boolean,
    dragging: Boolean,
    canResize: Boolean,
    cancelChildTouch: (() -> Unit)?,
    onTouchActive: (Boolean) -> Unit,
    onLongPress: () -> Unit,
    onExitEdit: () -> Unit,
    onRemove: () -> Unit,
    onResizeStep: (Int) -> Unit,
    onPinchStart: () -> Unit,
    onPinch: (Float, Float) -> Unit,
    onPinchEnd: () -> Unit,
    onDragStart: (Offset, Offset) -> Unit,
    onDragMove: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val currentLong by rememberUpdatedState(onLongPress)
    val currentTouch by rememberUpdatedState(onTouchActive)
    val currentCancel by rememberUpdatedState(cancelChildTouch)

    Box(
        modifier = modifier
            .graphicsLayer { alpha = if (dragging) 0.25f else 1f }
            .semantics {
                // Alternativa para TalkBack: cambiar el tamaño y quitar sin gestos de dos dedos.
                customActions = listOf(
                    CustomAccessibilityAction("Agrandar") {
                        onResizeStep(1)
                        true
                    },
                    CustomAccessibilityAction("Achicar") {
                        onResizeStep(-1)
                        true
                    },
                    CustomAccessibilityAction("Quitar") {
                        onRemove()
                        true
                    },
                )
            }
            .pointerInput(locked, editing, blockKey) {
                if (locked || editing) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    currentTouch(true)
                    var abort = false
                    val result = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                        while (!abort) {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val change = event.changes.firstOrNull { it.id == down.id }
                            if (change == null || !change.pressed ||
                                (change.position - down.position).getDistance() > viewConfiguration.touchSlop
                            ) {
                                abort = true
                            }
                        }
                    }
                    if (result == null && !abort) {
                        // Pulsación larga: se cancela el toque del contenido y se entra en edición.
                        currentCancel?.invoke()
                        currentLong()
                        // El resto del gesto se consume para que no llegue al contenido ni al pager.
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            event.changes.forEach { it.consume() }
                        } while (event.changes.any { it.pressed })
                    }
                    currentTouch(false)
                }
            },
    ) {
        content()

        if (editing) {
            WidgetEditOverlay(
                canResize = canResize,
                onExit = onExitEdit,
                onRemove = onRemove,
                onPinchStart = onPinchStart,
                onPinch = onPinch,
                onPinchEnd = onPinchEnd,
                onDragStart = onDragStart,
                onDragMove = onDragMove,
                onDragEnd = onDragEnd,
                onDragCancel = onDragCancel,
            )
        }
    }
}

@Composable
private fun WidgetEditOverlay(
    canResize: Boolean,
    onExit: () -> Unit,
    onRemove: () -> Unit,
    onPinchStart: () -> Unit,
    onPinch: (Float, Float) -> Unit,
    onPinchEnd: () -> Unit,
    onDragStart: (Offset, Offset) -> Unit,
    onDragMove: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit,
) {
    val holder = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val curExit by rememberUpdatedState(onExit)
    val curStart by rememberUpdatedState(onDragStart)
    val curMove by rememberUpdatedState(onDragMove)
    val curEnd by rememberUpdatedState(onDragEnd)
    val curCancel by rememberUpdatedState(onDragCancel)
    val curPinchStart by rememberUpdatedState(onPinchStart)
    val curPinch by rememberUpdatedState(onPinch)
    val curPinchEnd by rememberUpdatedState(onPinchEnd)
    val pinchEnabled by rememberUpdatedState(canResize)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onGloballyPositioned { holder[0] = it }
            .clip(RoundedCornerShape(22.dp))
            .background(Color.Black.copy(alpha = 0.30f))
            .border(2.dp, Color.White.copy(alpha = 0.9f), RoundedCornerShape(22.dp))
            .pointerInput(Unit) {
                // Pellizco: separar o juntar los dedos cambia columnas (horizontal) y filas (vertical).
                // Se mira antes que los demás gestos; al empezar se cancela cualquier arrastre.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    var pinching = false
                    var dx0 = 0f
                    var dy0 = 0f
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val down = event.changes.filter { it.pressed }
                        if (down.size >= 2 && pinchEnabled) {
                            val a = down[0].position
                            val b = down[1].position
                            val dx = abs(a.x - b.x)
                            val dy = abs(a.y - b.y)
                            if (!pinching) {
                                pinching = true
                                dx0 = dx
                                dy0 = dy
                                curCancel()
                                curPinchStart()
                            }
                            event.changes.forEach { it.consume() }
                            curPinch(dx - dx0, dy - dy0)
                        } else if (pinching) {
                            event.changes.forEach { it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                    if (pinching) curPinchEnd()
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onTap = { curExit() })
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val root = holder[0]?.localToRoot(offset) ?: Offset.Zero
                        curStart(offset, root)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val c = holder[0]
                        if (c != null) curMove(c.localToRoot(change.position))
                    },
                    onDragEnd = { curEnd() },
                    onDragCancel = { curCancel() },
                )
            },
        contentAlignment = Alignment.BottomCenter,
    ) {
        if (canResize) {
            Text(
                text = "Pellizcá con dos dedos para el tamaño · arrastrá para mover",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )
        }
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Pill("Quitar", onRemove)
        }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        color = Color.Black,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0xFF8AB4FF))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

/** Selector de widgets instalados (los agrupa por app). */
@Composable
fun WidgetPickerDialog(
    vm: LauncherViewModel,
    onPick: (AppWidgetProviderInfo) -> Unit,
    onPickBuiltin: (ItemType) -> Unit,
    onDismiss: () -> Unit,
) {
    val entries by produceState<List<WidgetEntry>?>(initialValue = null) {
        value = withContext(Dispatchers.Default) { vm.loadWidgetEntries() }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.8f),
        ) {
            Column(Modifier.padding(vertical = 16.dp)) {
                Text(
                    "Widgets",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 24.dp),
                )
                val list = entries
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    item(key = "h:ultra") {
                        Text(
                            "Ultra Launcher",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 4.dp),
                        )
                    }
                    item(key = "b:clock") {
                        BuiltinRow("Reloj", "Hora y fecha · tamaño a gusto") { onPickBuiltin(ItemType.CLOCK) }
                    }
                    item(key = "b:person") {
                        BuiltinRow("Hora de Marcos / Arianna", "Elegís cuál mostrar tocándola") {
                            onPickBuiltin(ItemType.PERSON)
                        }
                    }
                    if (list == null) {
                        item(key = "loading") {
                            Text(
                                "Cargando widgets…",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(24.dp),
                            )
                        }
                    } else {
                        val grouped = list.groupBy { it.appLabel }
                        grouped.forEach { (appLabel, group) ->
                            item(key = "h:$appLabel") {
                                Text(
                                    appLabel,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 14.sp,
                                    modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 4.dp),
                                )
                            }
                            items(group, key = { it.info.provider.flattenToString() }) { entry ->
                                WidgetRow(entry) { onPick(entry.info) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BuiltinRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 10.dp),
    ) {
        Text(title, fontSize = 15.sp)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), fontSize = 12.sp)
    }
}

@Composable
private fun WidgetRow(entry: WidgetEntry, onClick: () -> Unit) {
    val context = LocalContext.current
    val preview by produceState<ImageBitmap?>(null, entry) {
        value = withContext(Dispatchers.Default) {
            try {
                val d = entry.info.loadPreviewImage(context, 0) ?: entry.info.loadIcon(context, 0)
                d?.toPreviewBitmap(320)?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(88.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center,
        ) {
            val bmp = preview
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(4.dp),
                )
            }
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(entry.label.ifBlank { entry.appLabel }, fontSize = 15.sp)
            Text(
                "${entry.spanCols} × ${entry.spanRows}",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                fontSize = 12.sp,
            )
        }
    }
}

/** Cambiar el tamaño (en celdas) de un widget; los cambios se aplican al instante. */
@Composable
fun WidgetResizeDialog(
    item: HomeItem,
    limits: SpanLimits,
    onChange: (Int, Int) -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ) {
            Column(Modifier.padding(horizontal = 24.dp, vertical = 20.dp)) {
                Text("Tamaño del widget", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.size(12.dp))
                Stepper(
                    label = "Ancho (columnas)",
                    value = item.spanCols,
                    min = limits.minCols,
                    max = limits.maxCols,
                ) { onChange(it, item.spanRows) }
                Stepper(
                    label = "Alto (filas)",
                    value = item.spanRows,
                    min = limits.minRows,
                    max = limits.maxRows,
                ) { onChange(item.spanCols, it) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Listo") }
                }
            }
        }
    }
}

@Composable
private fun Stepper(label: String, value: Int, min: Int, max: Int, onValue: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, fontSize = 15.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = { onValue(value - 1) }, enabled = value > min) { Text("−") }
        Text("$value", fontSize = 16.sp, modifier = Modifier.padding(horizontal = 6.dp))
        TextButton(onClick = { onValue(value + 1) }, enabled = value < max) { Text("+") }
    }
}
